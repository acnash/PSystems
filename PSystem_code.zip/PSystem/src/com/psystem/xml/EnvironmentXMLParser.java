/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.xml;

import com.psystem.entities.EnvironmentObject;
import java.io.File;

/**
 *
 * @author Anthony
 */
public class EnvironmentXMLParser {

    public EnvironmentObject parseFile(File environmentFile) throws Exception {
        return new EnvironmentObject();
    }

}
