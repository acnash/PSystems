/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.entities;

import java.util.List;
import javax.swing.JList;

/**
 *
 * @author Anthony
 */
public class EnvironmentObject {

    public static final int INFINITE_BOUNDS = 0;
    public static final int CLOSED_BOUNDS = 2;
    public static final int OPEN_BOUNDS = 1;
    
    public static final int MOORE_NEIGHBOURHOOD = 0;
    public static final int VON_NEUMMAN_NEIGHBOURHOOD = 1;  

    private List ruleList;

    private int width;
    private int height;
    private int bounds;
    private int neighbourhood;

    private double nProbability;
    private double neProbability;
    private double eProbability;
    private double seProbability;
    private double sProbability;
    private double swProbability;
    private double wProbability;
    private double nwProbability;

    private String title;
    private int environmentType;

    public EnvironmentObject() {

    }

    public int getEnvironmentType() {
        return environmentType;
    }

    public void setEnvironmentType(int environmentType) {
        this.environmentType = environmentType;
    }

    public List getRuleList() {
        return ruleList;
    }

    public void setRuleList(List ruleList) {
        this.ruleList = ruleList;
    }

    public double getNProbability() {
        return this.nProbability;
    }

    public double getNEProbability() {
        return this.neProbability;
    }

    public double getEProbability() {
        return this.eProbability;
    }

    public double getSEProbability() {
        return this.seProbability;
    }

    public double getSProbability() {
        return this.sProbability;
    }

    public double getSWProbability() {
        return this.swProbability;
    }

    public double getWProbability() {
        return this.wProbability;
    }

    public double getNWProbability() {
        return this.nwProbability;
    }

    public void setNProbability(double nProbability) {
        this.nProbability = nProbability;
    }

    public void setNEProbability(double neProbability) {
        this.neProbability = neProbability;
    }

    public void setEProbability(double eProbability) {
        this.eProbability = eProbability;
    }

    public void setSEProbability(double seProbability) {
        this.seProbability = seProbability;
    }

    public void setSProbability(double sProbability) {
        this.sProbability = sProbability;
    }

    public void setSWProbability(double swProbability) {
        this.swProbability = swProbability;
    }

    public void setWProbability(double wProbability) {
        this.wProbability = wProbability;
    }

    public void setNWProbability(double nwProbability) {
        this.nwProbability = nwProbability;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getWidth() {
        return this.width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getHeight() {
        return this.height;
    }

    public void setNeighbourhood(int neighbourhood) {
        this.neighbourhood = neighbourhood;
    }

    public int getNeighbourhood() {
        return this.neighbourhood;
    }

    public void setBounds(int bounds) {
        this.bounds = bounds;
    }

    public int getBounds() {
        return bounds;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

}
