/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.entities;

/**
 *
 * @author Anthony
 */
public class JustMyxo extends InitialData {

    public static final String NUMBER_OF_CELLS = "number_of_cells";
    public static final String INITIAL_CONFIGURATION = "initial_configuration";

    public void addMetaData(String key, String data) {
        super.metaData.put(key, data);
    }

    public String getMetaData(String key) {
        return super.metaData.get(key);
    }

}
