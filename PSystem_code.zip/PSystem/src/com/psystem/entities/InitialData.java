/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.entities;

import java.util.Hashtable;

/**
 *
 * @author Anthony
 */
public abstract class InitialData {

    protected Hashtable<String,String> metaData = new Hashtable<String,String>();

    public abstract void addMetaData(String key, String data);

    public abstract String getMetaData(String key);
}
