/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import com.psystem.common.RuleList;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author Anthony
 */
public abstract class MyxoRule extends Rule {

    double currentDirectionBias = 2;
    protected Membrane bacteriaMembrane = null;
    protected ArrayList<NeighbourMembrane> neighbourhood = null;

    public abstract double getStochasticValue();
    public abstract void membraneOfInterest(Membrane membraneOfInterest);
    public abstract boolean checkRule(Membrane membraneOfInterest);
    public abstract int getOffSet(int totalInvasion, int invadingPopulation);


    @Override
    public void defineNeighbours() {
        if(neighbourhood == null) {
            neighbourhood = membrane.getNeighbourhood();
        }
        neighbourList = this.membrane.getNeighbourhood();
        for(int i=0; i<neighbourList.size(); i++) {
            neighbourTable.put(neighbourList.get(i).getRelativePosition(), neighbourList.get(i).getMembrane());
        }
    }

    @Override
    public void setDiffusionProbabilities(Hashtable<String, Double> diffusionProbabilities) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * This method is designed for rules which need to know whether there is a neighbour
     * in a given direction to act on e.g., for slime detection, for movement etc...
     * @param direction of the facing bacteria P System
     * @return true if you are facing a boundary otherwise false
     */
    protected boolean facingBoundary(String direction) {
        //just check if there is a neighbour in the direction facing
        for(int i=0; i<neighbourhood.size(); i++) {
            NeighbourMembrane neighbourMembrane = neighbourhood.get(i);
            if(neighbourMembrane.getRelativePosition().equals(direction)) {
                return false;
            }
        }
        return true;
    }

    private boolean lookingForSlime(String direction, NeighbourMembrane neighbour) {
        if(neighbour.getRelativePosition().equals(direction)) {
            Membrane neighbourMembrane = neighbour.getMembrane();
            MultiSetObject slimeObject = neighbourMembrane.getMultiSetObject(RuleList.SLIME);
            if(slimeObject == null) {
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    private boolean lookingForSameBacteriaAhead(String direction, NeighbourMembrane neighbour) {
        if(neighbour.getRelativePosition().equals(direction)) {
            //lets now and try and get the next neighbour from here.... a bit like an extended moore neighbourhood.
            Membrane neighbourMembrane = neighbour.getMembrane();
            ArrayList<NeighbourMembrane> neighboursNeighbours = neighbourMembrane.getNeighbourhood();
            for(int i=0; i<neighboursNeighbours.size(); i++) {
                NeighbourMembrane nnMembrane = neighboursNeighbours.get(i);
                if(nnMembrane.getRelativePosition().equals(direction)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * At the moment this will only hand Just Myxo - not e.coli too - labeling needs to be done on the membranes
     * @param direction
     * @param neighbour
     * @return
     */
    private boolean lookingForSameBacteria(String direction, NeighbourMembrane neighbour) {
        if(neighbour.getRelativePosition().equals(direction)) {
            Membrane neighbourMembrane = neighbour.getMembrane();
            boolean isEmpty = neighbourMembrane.isEmpty();
            if(isEmpty) {
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    protected boolean checkDirection(String directionFacing, String lookingForWhat) {
        for(int i=0; i<neighbourhood.size(); i++) {
            if(lookingForWhat.equals(RuleList.SLIME)) {
                boolean found = lookingForSlime(directionFacing, neighbourhood.get(i));
                if(found) {
                    return true;
                }
            }
            if(lookingForWhat.equals(RuleList.SAME_BACTERIA)) {
                boolean found = lookingForSameBacteria(directionFacing, neighbourhood.get(i));
                if(found) {
                    return true;
                }
            }
            if(lookingForWhat.equals(RuleList.SAME_BACTERIA_AHEAD)) {
                boolean found = lookingForSameBacteriaAhead(directionFacing, neighbourhood.get(i));
                if(found) {
                    return true;
                }
            }
        }
        //get neighbours
        //remove membranes for north, northeast and northwest
        return false;
    }

    /**
     * This should never return null as the software would never have got this far in the first place
     * @param directionOfNeighbour
     * @return
     */
    protected Membrane getNeighbourToUse(String directionOfNeighbour) {
        Membrane neighbourToUse = null;
        for(int i=0; i<neighbourhood.size(); i++) {
            if(neighbourhood.get(i).getRelativePosition().equals(directionOfNeighbour)) {
                neighbourToUse = neighbourhood.get(i).getMembrane();
            }
        }
        return neighbourToUse;
    }

    protected String reverseDirection(String currentDirection) {
        String direction = null;
        if(currentDirection.equals(RuleList.getDirection(RuleList.NORTH))) {
            direction = RuleList.getDirection(RuleList.SOUTH);
        }
        if(currentDirection.equals(RuleList.getDirection(RuleList.SOUTH))) {
            direction = RuleList.getDirection(RuleList.NORTH);
        }
        if(currentDirection.equals(RuleList.getDirection(RuleList.EAST))) {
            direction = RuleList.getDirection(RuleList.WEST);
        }
        if(currentDirection.equals(RuleList.getDirection(RuleList.WEST))) {
            direction = RuleList.getDirection(RuleList.EAST);
        }
        if(currentDirection.equals(RuleList.getDirection(RuleList.NORTH_EAST))) {
            direction = RuleList.getDirection(RuleList.SOUTH_WEST);
        }
        if(currentDirection.equals(RuleList.getDirection(RuleList.NORTH_WEST))) {
            direction = RuleList.getDirection(RuleList.SOUTH_EAST);
        }
        if(currentDirection.equals(RuleList.getDirection(RuleList.SOUTH_EAST))) {
            direction = RuleList.getDirection(RuleList.NORTH_WEST);
        }
        if(currentDirection.equals(RuleList.getDirection(RuleList.SOUTH_WEST))) {
            direction = RuleList.getDirection(RuleList.NORTH_EAST);
        }
        return direction;
    }


}
