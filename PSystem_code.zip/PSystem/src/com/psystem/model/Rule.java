/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author Anthony
 */
public abstract class Rule {

    protected Membrane membrane;
    protected ArrayList<NeighbourMembrane> neighbourList;
    protected Hashtable<String,Membrane> neighbourTable = new Hashtable<String,Membrane>();

    public abstract void defineNeighbours();

    public abstract void setDiffusionProbabilities(Hashtable<String,Double> diffusionProbabilities);

    public abstract ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception;

}
