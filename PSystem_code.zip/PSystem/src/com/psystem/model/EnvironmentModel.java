/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import com.psystem.common.BubbleSort;
import com.psystem.ui.MyxoPaintPanel;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

/**
 *
 * @author Anthony
 */
public class EnvironmentModel {

    public static final int STOCHASTIC = 0;
    private int ruleType;
    private String dateFolder = null;
    private String folder = null;
    private ArrayList<Membrane> environmentStructure;
    private int maxX;
    private int totalCells;
    private ArrayList<String> environmentData = new ArrayList<String>();
    private int environmentHeight;
    private int environmentWidth;
    //private Hashtable<Membrane,Integer> occupiedTable = null;
    private ArrayList<Membrane> occupiedList = null;

    private static boolean readyToUpdate = true;

    //private static boolean readyToUpdate = true;

    //public synchronized void readyToUpdate(boolean readyToUpdate) {
    //    this.readyToUpdate = readyToUpdate;
    //}

    public static void setReadyToUpdate(boolean state) {
        EnvironmentModel.readyToUpdate = state;
        //System.out.println("setting EnvironmentModel to " + state);
    }

//    public void setOccupiedTable(Hashtable<Membrane, Integer> occupiedTable) {
//        this.occupiedTable = occupiedTable;
//    }

    public void setOccupiedList(ArrayList<Membrane> occupiedList) {
        this.occupiedList = occupiedList;
    }

    public EnvironmentModel(int environmentWidth, int environmentHeight, int totalCells) {
        this.maxX = environmentWidth;
        this.totalCells = totalCells;
        environmentStructure = new ArrayList<Membrane>(this.totalCells);
        this.environmentWidth = environmentWidth;
        this.environmentHeight = environmentHeight;
        Date date = new Date();
        dateFolder = String.valueOf(date.getTime());
        folder = "PSystem_" + dateFolder;
        //File folderFile = new File("/Users/Anthony/Documents/" + folder);
        File folderFile = new File("/Users/acnash/Documents/P-SYSTEM/" + folder);
        if(!folderFile.exists()) {
            folderFile.mkdir();
        }

    }

    public EnvironmentModel() {}

    public int getHeight() {
        return environmentHeight;
    }

    public int getWidth() {
        return environmentWidth;
    }

    public void addEnvironmentData(String data) {
        environmentData.add(data);
    }

    public ArrayList<String> getEnvironmentData() {
        return environmentData;
    }

    public void addEnvironmentRules(ArrayList<Rule> ruleList) {
        for(int i=0; i<environmentStructure.size(); i++) {
            ((Membrane)environmentStructure.get(i)).addRuleList(ruleList);
        }
    }

    
    public void addEnvironmentMembrane(Membrane membrane, int x, int y) {
        int index = (x*maxX) + y;
        environmentStructure.add(index,membrane);
    }

    /**
     * This is also being used to get the neighbourhood membranes, which is why
     * when in debug mode it does not return the membranes in a sequential order.
     * @param x
     * @param y
     * @return
     */
    public Membrane getEnvironmentMembrane(int x, int y) {
        int index = (x*maxX) + y;
        try {
            return environmentStructure.get(index);
        } catch(IndexOutOfBoundsException exp) {
            exp.printStackTrace();
        }
        return null;
    }

    public Membrane getEnvironmentMembrane(int index) {
        return environmentStructure.get(index);
    }

    public int getRuleType() {
        return this.ruleType;
    }

    public void setRuleType(int type) {
        this.ruleType = type;
    }

    public synchronized void executeRules() throws Exception {

        while(readyToUpdate == false) {
            try {
                //System.out.println("EnvironmentModel is sleeping using thread: " + Thread.currentThread().getName());
                Thread.currentThread().sleep(30);
            } catch(Exception exp) {
                exp.printStackTrace();
            }
        }
        //System.out.println("I am updating " + Thread.currentThread().getName());

        //in every membrane there should be a method which executes its own rules
        //and then calls its inner membranes to call their rules
        int size = environmentStructure.size();
        //I need someway of defining how this is executed.
        if(getRuleType() == (EnvironmentModel.STOCHASTIC)) {
            //executeStochasticRules(size);
            executeStochasticMonteCarloRules();
        } else {
            for(int i=0; i<size; i++) {
                environmentStructure.get(i).executeRules(occupiedList);
            }
        }
        //moved
        
        for(int i=0; i<size; i++) {
            mergeInternalMembranes(i);
        }

        for(int i=0; i<size; i++) {
            environmentStructure.get(i).updatePositionValue();
        }
        /*
        for(int i=0; i<size; i++) {
            updateEnvironmentMembrane(i);
        }
        for(int i=0; i<size; i++) {
            updateInternalMembranes(i);
        }
        for(int i=0; i<size; i++) {
            updateInternalMembraneMultiSet(i);
        }
        

        for(int i=0; i<size; i++) {
            updateCollisions(i);
        }
        for(int i=0; i<size; i++) {
            mergeInternalMembranes(i);
        }

        //I need to update for any invalid changes caused by collisions
//        for(int i=0; i<size; i++) {
//            updateEnvironmentMembrane(i);
//        }
        for(int i=0; i<size; i++) {
            updateInternalMembranes(i);
        }
        for(int i=0; i<size; i++) {
            updateInternalMembraneMultiSet(i);
        }
        
        for(int i=0; i<size; i++) {
            updateParent(i);
            updateOccupation(i);
        }

        for(int i=0; i<size; i++) {
            killDuplicates(i);
        }

        */

        synchronized(this) {
            MyxoPaintPanel.setReadyToPaint(true);
            EnvironmentModel.setReadyToUpdate(false);
        };

    }

//    private void killDuplicates(int index) {
//
//        Membrane em = environmentStructure.get(index);
//
////        if(!(em.getMembraneList().size() == em.getTempMembraneList().size())) {
////            System.out.println("Temp and original membrane lists are different");
////        }
//
//        ArrayList<Membrane> membraneList = em.getMembraneList();
//        ArrayList<Membrane> newMembraneList = new ArrayList<Membrane>();
//        Hashtable floatTable = new Hashtable();
//        for(int i=0; i<membraneList.size(); i++) {
//            Membrane currentMembrane = membraneList.get(i);
//            float id = currentMembrane.getID();
//            if(!floatTable.containsKey(id)) {
//                newMembraneList.add(currentMembrane);
//                floatTable.put(id, currentMembrane);
//            } else {
//                System.out.println("WOW! I have duplicates... ");
//            }
//        }
//        em.setInternalMembraneList(newMembraneList);
//        //em.setTempInternalMembraneList(newMembraneList);
//    }


    private void executeStochasticMonteCarloRules() {
//        int count = 0;

//        int cellTotal = 0;
//        for(int i=0; i<occupiedList.size(); i++) {
//            ArrayList<Membrane> internalList = occupiedList.get(i).getMembraneList();
//            for(int j=0; j<internalList.size(); j++) {
//                cellTotal += (Integer)internalList.get(j).getMultiSetObject(RuleList.POPULATION).getObject();
//            }
//        }
//        System.out.println(cellTotal);
//        cellTotal = 0;

        //we use the size as the stochastic distribution of the cells...
        Membrane selectedEnvMembrane = null;
        Random randomSelection = new Random();
       // boolean isAvailable = false;
        //while(!isAvailable) {
        int selectedMembraneIndex = randomSelection.nextInt(occupiedList.size());
        //selectedEnvMembrane = occupiedTable.get(selectedMembraneIndex);
        selectedEnvMembrane = occupiedList.get(selectedMembraneIndex);

//            if(!selectedEnvMembrane.isEmpty()) {
//                isAvailable = true;
//            }
        //}



        ArrayList<Rule> ruleList = selectedEnvMembrane.getRuleList();

        //get the individual internal membranes here and execute for each
        ArrayList<Membrane> internalMembranes = selectedEnvMembrane.getMembraneList();
        for(int n=0; n<internalMembranes.size(); n++) {


            ArrayList<Rule> acceptedRule = new ArrayList<Rule>();
            ArrayList<Double> stochasticValue = new ArrayList<Double>();
            //get out the valid rules
            for(int j=0; j<ruleList.size(); j++) {
                //I add the internal bacteria membrane i am interested in at this point
                if(((MyxoRule)ruleList.get(j)).checkRule(internalMembranes.get(n))) {
                    //ruleTable.put(ruleList.get(n),((MyxoRule)ruleList.get(n)).getStochasticValue());
                    acceptedRule.add(ruleList.get(j));
                    stochasticValue.add(((MyxoRule)ruleList.get(j)).getStochasticValue());
                }
            }
            //get a stochastic total for all the valid rules
//            double stochasticTotal = 0;
//            for(int j=0; j<stochasticValue.size(); j++) {
//                stochasticTotal += stochasticValue.get(j);
//            }
            //using the stochastic total and stochastic values generate new values

//            ArrayList<Double> newStochasticValues = new ArrayList<Double>();

            //double current = 0;
//            for(int j=0; j<stochasticValue.size(); j++) {
//                double newValue = stochasticValue.get(j)/stochasticTotal;
//                newStochasticValues.add(newValue);
//            }
            BubbleSort bs = new BubbleSort();
            bs.setRuleList(acceptedRule);
//            bs.setStochasticList(newStochasticValues);
            bs.setStochasticList(stochasticValue);
            bs.sort();

            ArrayList<Rule> sortedRules = bs.getRuleList();
            ArrayList<Double> sortedStochasticValues = bs.getStochasticList();
            for(int i=1; i<sortedStochasticValues.size(); i++) {
                sortedStochasticValues.set(i, sortedStochasticValues.get(i-1)+sortedStochasticValues.get(i));
            }
//          
            Random rand = new Random();
            //double randomValue = rand.nextDouble();

            int base = rand.nextInt(4);
            double offset = rand.nextDouble();
            double roleValue = (double)base + offset;

            Rule ruleToUse = null;
            for(int i=0; i<sortedStochasticValues.size(); i++) {
                double currentValue = sortedStochasticValues.get(i);
                if(roleValue <= currentValue) {
                    ruleToUse = sortedRules.get(i);
                    break;
                }
            }
//            if(ruleToUse == null) {
//                try {
//                    if(sortedRules.size() == 1) {
//                        ruleToUse = sortedRules.get(0);
//                    }
//                } catch(IndexOutOfBoundsException exp) {
//                    exp.printStackTrace();
//                }
//                if(ruleToUse == null) {
//                    continue;
//                }
//            }

            try {
                //((MyxoRule)ruleToUse).membraneOfInterest(internalMembranes.get(n));
                try {
                    if(ruleToUse != null) {
                        occupiedList = ruleToUse.executeRule(occupiedList);
                    }
                } catch(NullPointerException exp) {
                    exp.printStackTrace();
                }
            } catch(Exception exp) {
                exp.printStackTrace();
            }
        }
        
//        count = 0;
    }

//    private void executeStochasticRules(int size) {
////        int count = 0;
//        for(int i=0; i<size; i++) {
////            Hashtable<Double,Rule> ruleTable = new Hashtable<Double,Rule>();
////            ArrayList<Rule> acceptedRule = new ArrayList<Rule>();
////            ArrayList<Double> stochasticValue = new ArrayList<Double>();
//
//            Membrane membrane = getEnvironmentMembrane(i);
//            //Membrane membrane = environmentStructure.get(i);
//            if(membrane.isEmpty()) {
//                continue;
//            }
//
//            /**DEBUG**/
////            count++;
////            if(count > 1) {
////                System.out.println("ERROR: Discovered multiple membranes");
////                System.out.println(membrane.getName() + " at index " + i);
////            }
////            System.out.println(membrane.getName() + " at index " + i);
//
//
//            ArrayList<Rule> ruleList = membrane.getRuleList();
//
//            //get the individual internal membranes here and execute for each
//            ArrayList<Membrane> internalMembranes = membrane.getMembraneList();
//            for(int n=0; n<internalMembranes.size(); n++) {
//
//                Hashtable<Double,Rule> ruleTable = new Hashtable<Double,Rule>();
//
//                ArrayList<Rule> acceptedRule = new ArrayList<Rule>();
//                ArrayList<Double> stochasticValue = new ArrayList<Double>();
//                //get out the valid rules
//                for(int j=0; j<ruleList.size(); j++) {
//                    //I add the internal bacteria membrane i am interested in at this point
//                    if(((MyxoRule)ruleList.get(j)).checkRule(internalMembranes.get(n))) {
//                        //ruleTable.put(ruleList.get(n),((MyxoRule)ruleList.get(n)).getStochasticValue());
//                        acceptedRule.add(ruleList.get(j));
//                        stochasticValue.add(((MyxoRule)ruleList.get(j)).getStochasticValue());
//                    }
//                }
//                //get a stochastic total for all the valid rules
//                double stochasticTotal = 0;
//                for(int j=0; j<stochasticValue.size(); j++) {
//                    stochasticTotal += stochasticValue.get(j);
//                }
//                //using the stochastic total and stochastic values generate new values
//                double current = 0;
//                for(int j=0; j<stochasticValue.size(); j++) {
//                    double newValue = stochasticValue.get(j)/stochasticTotal;
//                    current += newValue;
//                    ruleTable.put(current,(Rule)acceptedRule.get(j));
//                }
//
//                //now that we have a list of acceptable rules along with their
//                //stochastic values, we need to decide which one to use.
//                //environmentStructure.get(i).executeRules();
//                Random rand = new Random();
//                double randomValue = rand.nextDouble();
//
//                //I need to get the rule out of the ruleTable.
//                Rule ruleToUse = null;
//                Enumeration eKeys = ruleTable.keys();
//                while(eKeys.hasMoreElements()) {
//                    double key = (Double)eKeys.nextElement();
//                    if(randomValue <= key) {
//                        ruleToUse = ruleTable.get(key);
//                        break;
//                    }
//                }
//                if(ruleToUse == null) {
//                    System.out.println("Serious Problem! No rule to use!");
//                }
//
//                try {
//                    //((MyxoRule)ruleToUse).membraneOfInterest(internalMembranes.get(n));
//                    ruleToUse.executeRule(occupiedList);
//                } catch(Exception exp) {
//                    exp.printStackTrace();
//                }
//            }
//        }
////        count = 0;
//    }
//
//    private void updateAllMembranes(int index) throws Exception {
//        //the membrane structure needs changing
//        //the multisets needs changing
//        environmentStructure.get(index).updateMembrane();
//    }

//    private void updateEnvironmentMembrane(int index) {
//        Membrane em = environmentStructure.get(index);
//        Hashtable<String,MultiSetObject> hashtable = em.getTempMultiSetObjectList();
//        Enumeration<String> keyEnum = hashtable.keys();
//        while(keyEnum.hasMoreElements()) {
//            String key = keyEnum.nextElement();
//            MultiSetObject object = (MultiSetObject)hashtable.get(key);
//            em.addMultiSetObject(key, object);
//        }
//    }

    private void mergeInternalMembranes(int index) {
        
        Membrane em = environmentStructure.get(index);
        em.mergeInternalMembranes();
    }

//    private void updateInternalMembranes(int index) {
//        Membrane em = environmentStructure.get(index);
//        ArrayList<Membrane> tempMembranes = em.getTempMembraneList();
//        //ArrayList<Membrane> originalMembranes = em.getMembraneList(); //not used.. i don't think
//        em.updateInternalMembranes(tempMembranes);
//    }

//    private void updateInternalMembraneMultiSet(int index) {
//        Membrane em = environmentStructure.get(index);
//        ArrayList<Membrane> membraneList = em.getMembraneList();
//        for(int i=0; i<membraneList.size(); i++) {
//            Membrane innerMembrane = membraneList.get(i);
//            //Hashtable originalTable = innerMembrane.getMultiSetList();
//            Hashtable tempTable = null;
//            try {
//                tempTable = innerMembrane.getTempMultiSetObjectList();
//            } catch(NullPointerException exp) {
//                exp.printStackTrace();
//            }
//
//            Enumeration keyEnum = tempTable.keys();
//            while(keyEnum.hasMoreElements()) {
//                String key = (String)keyEnum.nextElement();
//                MultiSetObject object = (MultiSetObject)tempTable.get(key);
//                innerMembrane.addMultiSetObject(key, object);
//            }
//        }
//    }
//
//    private void updateParent(int index) {
//        Membrane em = environmentStructure.get(index);
//        ArrayList<Membrane> membraneList = em.getMembraneList();
//        for(int i=0; i<membraneList.size(); i++) {
//            Membrane innerMembrane = membraneList.get(i);
//            innerMembrane.setParentMembrane(em);
//        }
//    }

//    private void updateOccupation(int index) {
//        Membrane em = environmentStructure.get(index);
//        if(em.isEmpty()) {
//            em.wasCellEmpty();
//        } else {
//            em.wasCellOccupied();
//        }
//    }


    /**
     * There is a slight flaw with this design...
     *
     * @param index
//     */
//    private void updateCollisions(int index) {
//        Membrane em = environmentStructure.get(index);
//        Hashtable<String, Membrane> collisionTable = new Hashtable<String, Membrane>();
//        ArrayList<String> directionList = new ArrayList<String>();
//        ArrayList<Integer> populationList = new ArrayList<Integer>();
//
//        //get the environment's internal membranes
//        ArrayList<Membrane> membraneList = em.getMembraneList();
//
//        //if there are multiple membranes in the single multi-environment region
//        if(membraneList.size() > 1) {
//            if(em.isEmpty()) {
//            //go through each membrane and put them into data structures
//                for(int i=0; i<membraneList.size(); i++) {
//                    Membrane membrane = membraneList.get(i);
//                    String direction = (String)membrane.getMultiSetObject(RuleList.DIRECTION).getObject();
//                    directionList.add(direction);
//                    Integer population = (Integer)membrane.getMultiSetObject(RuleList.POPULATION).getObject();
//                    populationList.add(population);
//                }
//                //get the total size of the invading population
//                int totalInvadingSize = 0;
//                for(int i=0; i<membraneList.size(); i++) {
//                    collisionTable.put(directionList.get(i), membraneList.get(i));
//                    totalInvadingSize += populationList.get(i);
//                }
//                //1a. check if anyone is applicable for collision, do not actually execute yet, just get the potential
//                //as they may not reverse, instead they might climb together
//                if(collisionTable.containsKey(RuleList.getDirection(RuleList.NORTH)) && collisionTable.containsKey(RuleList.getDirection(RuleList.SOUTH))) {
//                    String dir1 = RuleList.getDirection(RuleList.NORTH);
//                    String dir2 = RuleList.getDirection(RuleList.SOUTH);
//                    totalInvadingSize = totalInvadingSize - determineHeadOnCollisions(em, totalInvadingSize, dir1, dir2, collisionTable);
//                }
//                if(collisionTable.containsKey(RuleList.getDirection(RuleList.EAST)) && collisionTable.containsKey(RuleList.getDirection(RuleList.WEST))) {
//                    String dir1 = RuleList.getDirection(RuleList.EAST);
//                    String dir2 = RuleList.getDirection(RuleList.WEST);
//                    totalInvadingSize = totalInvadingSize - determineHeadOnCollisions(em, totalInvadingSize, dir1, dir2, collisionTable);
//                }
//                if(collisionTable.containsKey(RuleList.getDirection(RuleList.NORTH_WEST)) && collisionTable.containsKey(RuleList.getDirection(RuleList.SOUTH_EAST))) {
//                    String dir1 = RuleList.getDirection(RuleList.NORTH_WEST);
//                    String dir2 = RuleList.getDirection(RuleList.SOUTH_EAST);
//                    totalInvadingSize = totalInvadingSize - determineHeadOnCollisions(em, totalInvadingSize, dir1, dir2, collisionTable);
//                }
//                if(collisionTable.containsKey(RuleList.getDirection(RuleList.SOUTH_WEST)) && collisionTable.containsKey(RuleList.getDirection(RuleList.NORTH_EAST))) {
//                    String dir1 = RuleList.getDirection(RuleList.SOUTH_WEST);
//                    String dir2 = RuleList.getDirection(RuleList.NORTH_EAST);
//                    totalInvadingSize = totalInvadingSize - determineHeadOnCollisions(em, totalInvadingSize, dir1, dir2, collisionTable);
//                }
//
//                //now that head to head collision has been calculated cycle through
//                //what is left
//                if(totalInvadingSize > 400) {
//                    System.out.println("Over 400 pop, environment cell: " + em.getID());
//                    Enumeration enumeration = collisionTable.keys();
//                    while(enumeration.hasMoreElements()) {
//                        String invadingDirection = (String)enumeration.nextElement();
//                        Membrane invadingMembrane = (Membrane)collisionTable.get(invadingDirection);
//                        Rule13 invadingRule = new Rule13(em);
//                        //FIND OUT HOW MUCH IS BEING REMOVED
//                        try {
//                            MultiSetObject popObject = invadingMembrane.getMultiSetObject(RuleList.POPULATION);
//                            int population = (Integer)popObject.getObject();
//                            invadingRule.membraneOfInterest(invadingMembrane);
//                            invadingRule.getOffSet(totalInvadingSize, population);
//                            invadingRule.executeRule(null);
//                        } catch(Exception exp) {
//                            exp.printStackTrace();
//                        }
//                        //EXECUTE THIS RULE FOR EACH MEMBRANE
//
//                    }
//                }
////
//            } else {
//
//                //assume for isOccupied == true, i.e, multiple invasions of an occupied cell
//                updatePopulatedCollisions(em);
//            }
//
//        } //end of >1 if
//
//    }

//    private void updatePopulatedCollisions(Membrane em) {
//        int totalPopulation = 0;
//        ArrayList<Membrane> nativeMembranes = new ArrayList<Membrane>();
//        ArrayList<Membrane> invadingMembranes = new ArrayList<Membrane>();
//
//        ArrayList<Membrane> membraneList = em.getMembraneList();
//        //0. calculate the total cell population (native and invading)
//        //and work out who is invading and who is native.
//        for(int i=0; i<membraneList.size(); i++) {
//            Membrane membrane = membraneList.get(i);
//            if(membrane.getParentMembrane() == em) {
//                nativeMembranes.add(membrane);
//            } else {
//                invadingMembranes.add(membrane);
//            }
//            MultiSetObject popObject = membrane.getMultiSetObject(RuleList.POPULATION);
//            totalPopulation += (Integer)popObject.getObject();
//        }
//
//
//        //1. go through each invading population and see if any of them collide head-to-head with the native population
//        //we determine if any of the invaders collide with the native bacteria
//        Hashtable<Membrane,Membrane> collisionTable = new Hashtable<Membrane,Membrane>();
//        for(int i=0; i<nativeMembranes.size(); i++) {
//            MultiSetObject nativeObject = nativeMembranes.get(i).getMultiSetObject(RuleList.DIRECTION);
//            String nativeDirection = (String)nativeObject.getObject();
//            for(int n=0; n<invadingMembranes.size(); n++) {
//                MultiSetObject invadingObject = invadingMembranes.get(i).getMultiSetObject(RuleList.DIRECTION);
//                String invadingDirection = (String)invadingObject.getObject();
//                if(directionsAreOpposite(invadingDirection,nativeDirection)) {
//                    if(!collisionTable.containsKey(invadingMembranes.get(n))) {
//                        collisionTable.put(invadingMembranes.get(n), nativeMembranes.get(i));
//                    }
//                    totalPopulation += executePopulatedHeadtoHeadCollision(invadingMembranes.get(n),nativeMembranes.get(i), em, totalPopulation);
//                }
//            }
//        }
//
//        //I need to work out what membranes I MUST not operate on (as they have already executed some rules)
//
//        //execute modified invasion rules for all membranes not involved in head-head collisions
//        if(totalPopulation > 400) {
//            //so long as the invading membrane is not part of the collision table then we can execute a rule
//            for(int i=0; i<invadingMembranes.size(); i++) {
//                Membrane invadingMembrane = invadingMembranes.get(i);
//                //if the invadingMembrane hasn't been involved in head-head collision then work on executing the invasion rule
//                if(!collisionTable.containsKey(invadingMembrane)) {
//                    Rule13 invadingRule = new Rule13(em);
//                    try {
//                        MultiSetObject popObject = invadingMembrane.getMultiSetObject(RuleList.POPULATION);
//                        int population = (Integer)popObject.getObject();
//                        invadingRule.membraneOfInterest(invadingMembrane);
//                        invadingRule.getOffSet(totalPopulation, population);
//                        invadingRule.executeRule(null);
//                    } catch(Exception exp) {
//                        exp.printStackTrace();
//                    }
//                }
//            }
//        }
//
//    }

    /**
     * This is used when a population invaded a populated cell to find that the population in the invaded cell is facing into
     * the population of the invading force.
     * @param invadingMembrane
     * @param nativeMembrane
     * @param em
     * @param totalPopulation
     * @return
     */
//    private int executePopulatedHeadtoHeadCollision(Membrane invadingMembrane, Membrane nativeMembrane, Membrane em, int totalPopulation) {
//        int invadingPopulation = 0;
//        MultiSetObject invadingPopulationObj = invadingMembrane.getMultiSetObject(RuleList.POPULATION);
//        invadingPopulation = (Integer)invadingPopulationObj.getObject();
//
//        MyxoRule ruleToUse = null;
//
//        Rule14 reversalRule = new Rule14(em);
//        reversalRule.setCollidingMembrane(invadingMembrane, nativeMembrane);
//        double reversalStochastic = reversalRule.getStochasticValue();
//
//        Rule13 invadingRule = new Rule13(em);
//        invadingRule.membraneOfInterest(invadingMembrane);
//        int fractionOfInvading = invadingRule.getOffSet(totalPopulation, invadingPopulation);
//        double invadingStochastic = invadingRule.getStochasticValue();
//
//        double totalStochastic = reversalStochastic + invadingStochastic;
//        Hashtable<Double,MyxoRule> ruleTable = new Hashtable<Double,MyxoRule>();
//
//        double modifiedStochasticInvading = invadingStochastic/totalStochastic;
//        double modifiedStochasticReversal = reversalStochastic/totalStochastic;
//
//        ruleTable.put(modifiedStochasticInvading, invadingRule);
//        ruleTable.put(modifiedStochasticInvading+modifiedStochasticReversal, reversalRule);
//
//        Random rand = new Random();
//        double randomRoll = rand.nextDouble();
//        Enumeration enumRule = ruleTable.keys();
//        while(enumRule.hasMoreElements()) {
//            double stochasticValue = (Double)enumRule.nextElement();
//            if(randomRoll <= stochasticValue) {
//                ruleToUse = ruleTable.get(stochasticValue);
//            }
//        }
//
//        try {
//            ruleToUse.executeRule(null);
//            if(ruleToUse.getClass() == Class.forName("com.psystem.model.justmyxo.Rule14")) {
//                return invadingPopulation;
//            }
//            if(ruleToUse.getClass() == Class.forName("com.psystem.model.justmyxo.Rule13")) {
//                return fractionOfInvading;
//            }
//        } catch(Exception exp) {
//            exp.printStackTrace();
//        }
//
//        return 0;
//    }

//
//    private boolean directionsAreOpposite(String invadingDirection, String nativeDirection) {
//        if(invadingDirection.equals(RuleList.getDirection(RuleList.NORTH)) && nativeDirection.equals(RuleList.getDirection(RuleList.SOUTH))) {
//            return true;
//        }
//        if(invadingDirection.equals(RuleList.getDirection(RuleList.NORTH_EAST)) && nativeDirection.equals(RuleList.getDirection(RuleList.SOUTH_WEST))) {
//            return true;
//        }
//        if(invadingDirection.equals(RuleList.getDirection(RuleList.EAST)) && nativeDirection.equals(RuleList.getDirection(RuleList.WEST))) {
//            return true;
//        }
//        if(invadingDirection.equals(RuleList.getDirection(RuleList.NORTH_WEST)) && nativeDirection.equals(RuleList.getDirection(RuleList.SOUTH_EAST))) {
//            return true;
//        }
//
//        return false;
//    }

    /**
     * Once a head on head collision has been detected, this method is executed
     * as a preliminary to the rules involved.
     *
     * @param em
     * @param totalInvadingSize
     * @param direction1
     * @param direction2
     * @param collisionTable
     * @return
     */
//    private int determineHeadOnCollisions(Membrane em, int totalInvadingSize, String direction1, String direction2, Hashtable<String, Membrane> collisionTable) {
//        Hashtable<Double, MyxoRule> ruleTable = new Hashtable<Double, MyxoRule>();
//        Rule9 collisionRule = new Rule9(em);
//        //assign the colliding directions
//        //collisionRule.assignDirections(direction1, direction2);
//        //assign the colliding membranes
//        //collisionRule.setCollidingMembrane(collisionTable.get(direction1),collisionTable.get(direction2));
//        //store the liklihood of cell reversal
//        double stocasticConstant = collisionRule.getStochasticValue();
//        ruleTable.put(stocasticConstant, collisionRule);
//
//        //generate the invading rule and then store it's stochastic value
//        Rule13 invadingRule = new Rule13(em);
//        ruleTable.put(invadingRule.getStochasticValue(),invadingRule);
//
//        int forceSize = executeHeadOnCollisions(ruleTable, totalInvadingSize, collisionTable.get(direction1), collisionTable.get(direction2));
//        //int forceSize1 = executeHeadOnCollisions(ruleTable, totalInvadingSize, collisionTable.get(direction1));
//        //int forceSize2 = executeHeadOnCollisions(ruleTable, totalInvadingSize, collisionTable.get(direction2));
//
//        //remove the membranes involved from the collisionTable
//        collisionTable.remove(direction1);
//        collisionTable.remove(direction2);
//
//        //determine the size to reduce by
//        //if it is invasion rule then it shouldn't reduce the total population
//        //if it is reversal then both cell pops should be deducted
//        //int size = totalInvadingSize - (forceSize1+forceSize2);
//
//        int size = totalInvadingSize - forceSize;
//        //return the new total population size
//        return size;
//    }

    /**
     * For Rule13, i.e., head on collision - there is either invasion or the
     * swap their motors around. 
     * @param ruleTable
     * @param totalInvasion
     * @param membrane
     * @return
     */
//    private int executeHeadOnCollisions(Hashtable<Double, MyxoRule> ruleTable, int totalInvasion,
//            Membrane membraneInvaded, Membrane membraneInvaded2) {
//
//        int deducedValue = 0;
//        MyxoRule ruleToUse1 = null;
//        MyxoRule ruleToUse2 = null;
//        //get the stochastic values
//        Hashtable<Double, MyxoRule> organisedRuleTable = new Hashtable<Double, MyxoRule>();
//        Enumeration ruleEnumerate = ruleTable.keys();
//        double totalStochastic =0;
//        while(ruleEnumerate.hasMoreElements()) {
//            totalStochastic += (Double)ruleEnumerate.nextElement();
//        }
//        //assign new stochastic values to use in a random number generate [0,1]
//        ruleEnumerate = ruleTable.keys();
//        double currentKey = 0;
//        while(ruleEnumerate.hasMoreElements()) {
//            double key = (Double)ruleEnumerate.nextElement();
//            double newStochastic = key/totalStochastic;
//            currentKey += newStochastic;
//            //organisedRuleTable.put(newStochastic, ruleTable.get(currentKey));
//            organisedRuleTable.put(currentKey, ruleTable.get(key));
//        }
//        //determine who executes
//        Random rand = new Random();
//        double randValue = rand.nextDouble();
//
//        Enumeration randomEnumeration = organisedRuleTable.keys();
//        while(randomEnumeration.hasMoreElements()) {
//            Double stochasticValue = (Double)randomEnumeration.nextElement();
//            if(randValue < stochasticValue) {
//                ruleToUse1 = organisedRuleTable.get(stochasticValue);
//                ruleToUse2 = organisedRuleTable.get(stochasticValue);
//                break;
//            }
//        }
//        try {
//            MultiSetObject populationObject = membraneInvaded.getMultiSetObject(RuleList.POPULATION);
//            Integer population = (Integer)populationObject.getObject();
//            deducedValue = ruleToUse1.getOffSet(totalInvasion, population);
//            MultiSetObject populationObject2 = membraneInvaded2.getMultiSetObject(RuleList.POPULATION);
//            Integer population2 = (Integer)populationObject2.getObject();
//            deducedValue += ruleToUse2.getOffSet(totalInvasion, population2);
//
//            if(ruleToUse1.getClass() == Class.forName("com.psystem.model.justmyxo.Rule9")) {
//                ruleToUse1.executeRule(null);
//                //full value
//                return totalInvasion;
//            } else {
//                ruleToUse1.membraneOfInterest(membraneInvaded);
//                ruleToUse1.executeRule(null);
//                ruleToUse2.membraneOfInterest(membraneInvaded2);
//                ruleToUse2.executeRule(null);
//            }
//
//        } catch(Exception exp) {
//            exp.printStackTrace();
//        }
//
//        //how do I know which rule I have just executed? Then to be able to recalculate or not?
//
//        //determine how many cells did invade, return that value to then subtract/calculate from the total
//        return 0;
//    }

    public ArrayList<Membrane> getEnvironmentStructure() {
        return this.environmentStructure;
    }


    public void recordPositions(int count) {
        try {
            
            //File newFile = new File("/Users/Anthony/Documents/" + folder + "/position" + count + ".txt");
            File newFile = new File("/Users/acnash/Documents/P-SYSTEM/" + folder + "/position" + count + ".txt");
            //System.out.println(newFile.getCanonicalPath());
            BufferedWriter out = new BufferedWriter(new FileWriter(newFile));
            for(int x=0; x<environmentWidth; x++) {
                for(int y=0; y<environmentHeight; y++) {
                    int index = (x*maxX) + y;
                    Membrane meRegion = environmentStructure.get(index);
                    int cellPopulation = 0;

                    if(!meRegion.isInternalEcoliEmpty()) {
                        ArrayList<Membrane> ecoliMembranes = meRegion.getInternalEcoli();
                        for(int i=0; i<ecoliMembranes.size(); i++) {
                            Membrane tempMembrane = ecoliMembranes.get(i);
                            cellPopulation += tempMembrane.getPopulation();
                        }
                    }
                    if(!meRegion.isInternalMembraneEmpty()) {
                        ArrayList<Membrane> myxoMembranes = meRegion.getMembraneList();
                        for(int i=0; i<myxoMembranes.size(); i++) {
                            Membrane tempMembrane = myxoMembranes.get(i);
                            cellPopulation += tempMembrane.getPopulation();
                        }
                    }
                    //double positionValue = meRegion.getPositionValue();
                    String positionValueString = String.valueOf(cellPopulation);
                    out.write(positionValueString + ", ");
                }
                out.newLine();
            }
            out.close();
        } catch(IOException exp) {
            exp.printStackTrace();
        }
    }

}
