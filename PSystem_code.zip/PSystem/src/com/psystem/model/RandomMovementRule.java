/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;

/**
 *
 * @author Anthony
 *
 * Recall that this is for an environment, so it is ok to have environment data in here
 */
public class RandomMovementRule extends Rule {

    
    private Hashtable<String,Double> diffusionProbabilities;
    private Hashtable<String,Double> tempDiffusionPercentages = new Hashtable<String,Double>();
    private Hashtable<String,Double> diffusionPercentages = new Hashtable<String,Double>();
    

    public RandomMovementRule(Membrane membrane) {
        this.membrane = membrane;

    }

    //the neighbourhood should not be directly put into the rule - it must be put in through the membrane
    //only call this once the membrane neighbours have been added
    public void defineNeighbours() {
        neighbourList = this.membrane.getNeighbourhood();
        for(int i=0; i<neighbourList.size(); i++) {
            neighbourTable.put(neighbourList.get(i).getRelativePosition(), neighbourList.get(i).getMembrane());
        }
        calculateDiffusionProbabilities();
    }

    public void setDiffusionProbabilities(Hashtable<String,Double> diffusionProbabilities) {
        this.diffusionProbabilities = diffusionProbabilities;
       
        
//        calculateDiffusionProbabilities();
    }

    private void calculateDiffusionProbabilities() {
        //TO REMOVE NEIGHBOURS THAT SHOULD NOT EXIST!
        ArrayList<String> toRemove = new ArrayList<String>();
        Enumeration keyEnum = this.diffusionProbabilities.keys();
        while(keyEnum.hasMoreElements()) {
            String key = (String)keyEnum.nextElement();
            if(!neighbourTable.containsKey(key)) {
                toRemove.add(key);
            }
        }
        for(int i=0; i<toRemove.size(); i++) {
            String key = toRemove.get(i);
            diffusionProbabilities.remove(key);
        }


        double rawTotal = 0;
        //enumerate through the raw data and calculate the total
        Enumeration<String> enumKeys = diffusionProbabilities.keys();
        while(enumKeys.hasMoreElements()) {
            String key = enumKeys.nextElement();
            rawTotal += diffusionProbabilities.get(key);
        }
        //then calculate the percentages of these values and put them in abother hashtable
        enumKeys = diffusionProbabilities.keys();
        while(enumKeys.hasMoreElements()) {
            String key = enumKeys.nextElement();
            double rawValue = diffusionProbabilities.get(key);
            double percentage = (rawValue/rawTotal)*100;
            tempDiffusionPercentages.put(key, new Double(percentage));
        }
        sortPercentages();

    }

    private void sortPercentages() {
        ArrayList<String> tempKeys = new ArrayList<String>(tempDiffusionPercentages.size());
        ArrayList<Double> tempValues = new ArrayList<Double>(tempDiffusionPercentages.size());
        Enumeration<String> enumKeys = tempDiffusionPercentages.keys();
        
        while(enumKeys.hasMoreElements()) {
            String key = enumKeys.nextElement();
            double rawValue = tempDiffusionPercentages.get(key);
            tempKeys.add(key);
            tempValues.add(rawValue);
        }
        int n = tempKeys.size();
        for (int pass=1; pass < n; pass++) {  // count how many times
            // This next loop becomes shorter and shorter
            for (int i=0; i < n-pass; i++) {
                if (tempValues.get(i) > tempValues.get(i+1)) {
                    // exchange elements
                    Double tempValue = tempValues.get(i);
                    String tempKey = tempKeys.get(i);

                    tempValues.set(i, tempValues.get(i+1));
                    tempKeys.set(i, tempKeys.get(i+1));

                    tempValues.set(i+1,tempValue);
                    tempKeys.set(i+1,tempKey);
                }
            }
        }
        double currentValue = 0;
        for(int i=0; i<tempKeys.size(); i++) {
            String tempKey = tempKeys.get(i);
            double tempValue = tempValues.get(i);
            currentValue += tempValue;
            //diffusionPercentages.put(tempKeys.get(i), tempValues.get(i));
            diffusionPercentages.put(tempKey,currentValue);
        }

    }
    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //is the membrane empty?
        boolean isEmpty = membrane.isEmpty();
        Membrane particleMembrane = null;
        if(isEmpty == false) {
//                System.out.println("I am a rule that is executing");
                //if it isn't then randomly select a direction according to the
                //diffusion direction
                String neighbourToUse = null;
                Random rand = new Random();
                double roll = rand.nextDouble() * 100;
                Enumeration<String> enumKeys = diffusionPercentages.keys();
                while(enumKeys.hasMoreElements()) {
                    String key = enumKeys.nextElement();
                    double upperRange = diffusionPercentages.get(key);
                    if(roll < upperRange) {
                        neighbourToUse = key;
                        break;
                    }
                    //what happens if the roll is greater than the last value
                }
                if(neighbourToUse == null) {
                    int randInt = rand.nextInt(diffusionPercentages.size());
                    int i=0;
                    Enumeration<String> randomKeys = diffusionPercentages.keys();
                    while(randomKeys.hasMoreElements()) {
                        if(i == randInt) {
                            neighbourToUse = randomKeys.toString();
                            break;
                        }
                        i++;
                    }
                }

                //then move to another neighbour (the one which was selected)
                particleMembrane = membrane.getMembraneList().get(0);
                Membrane targetMembrane = neighbourTable.get(neighbourToUse);

                //THIS IS NOT IN TIME STEP!!!!!! only effect the ones you are making modifications too
                //membrane.removeTempMembrane(0);
                membrane.removeMembrane(0);
                //signal that the original membrane has changed its internal structure
                //membrane.internalMembraneHasChanged();
                //signal that the neighbour now has a changed internal membrane structure
                //targetMembrane.internalMembraneHasChanged();
                //targetMembrane.addTempMembrane(particleMembrane);
                targetMembrane.addMembrane(particleMembrane);
                //recall that we must move to a templocation - otherwise we get a strange
                //time streaming effect

        }
        return null;
    }

}
