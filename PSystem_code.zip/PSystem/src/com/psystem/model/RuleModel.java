/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public abstract class RuleModel {

    public abstract ArrayList<Rule> getEnvironmentRuleList();

}
