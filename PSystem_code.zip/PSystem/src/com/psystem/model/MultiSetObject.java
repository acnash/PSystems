/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

/**
 *
 * @author Anthony
 */
public class MultiSetObject {

    private Object symbol = null;

    public void setObject(Object object) {
        this.symbol = object;
    }

    public Object getObject() {
        return symbol;
    }

}
