/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 *
 * This is for a straight detection (i.e., not on an angle)
 * This particular straight rule is if the slime is directly infront of the cell,
 * i.e., it doesn't require turning. Therefore it has a bias of x2
 *
 * @author Anthony
 */
public class Rule3a extends MyxoRule {

    private String bacteriaDirection;
    private String slimeDirection;
    private Membrane neighbourToUse = null;
    private boolean useBias = false;
    

    public Rule3a(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 5;
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        this.bacteriaMembrane = membraneOfInterest;

        //1. Is this in the right motility i.e., it must be adventurous motility
        String motility = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.MOTILITY).getObject();
        if(motility.equals(RuleList.S_MOTILITY)) {
            return false;
        }

        bacteriaDirection = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION).getObject();
        //2 preliminary boundary condition check to see if there is a neighbour in my direction
        if(facingBoundary(bacteriaDirection)) {
            return false;
        }

        //3 is the slime in the same direction that the bacteria is facing?
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.NORTH))) {
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.NORTH),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.NORTH),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.NORTH));
                return true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.SOUTH))) {
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.SOUTH),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.SOUTH),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.SOUTH));
                return true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.EAST))) {
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.EAST),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.EAST),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.EAST));
                return true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.WEST))) {
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.WEST),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.WEST),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.WEST));
                return true;
            }
        }

        return false;
    }


    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //System.out.println("Rule3a: Slime directed adventurous movement");
        //1. if there is no slime then leave some, else dont
        MultiSetObject slimeObject = this.membrane.getMultiSetObject(RuleList.SLIME);
        if(slimeObject == null) {
            //leave slime
            slimeObject = new MultiSetObject();
            slimeObject.setObject(RuleList.SLIME);
            //membrane.addTempMultiSetObject(RuleList.SLIME, slimeObject);
            membrane.addMultiSetObject(RuleList.SLIME, slimeObject);
//            membrane.multisetHasChanged();
        }

        //2. move the membraneOfInterest in the direction it is facing
        //membrane.removeTempMembrane(bacteriaMembrane.getID());
        membrane.removeMembrane(bacteriaMembrane.getID());
//        membrane.internalMembraneHasChanged();
        //neighbourToUse.addTempMembrane(bacteriaMembrane);
        neighbourToUse.addMembrane(bacteriaMembrane);
//        neighbourToUse.internalMembraneHasChanged();
//        membrane.wasCellEmpty();
        //(in rules 3b and 3c this will also change the direction of the bacteria as slime
        //is on an angle)

        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        if(!occupiedList.contains(neighbourToUse)) {
            occupiedList.add(neighbourToUse);
        }
        return occupiedList;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    

}
