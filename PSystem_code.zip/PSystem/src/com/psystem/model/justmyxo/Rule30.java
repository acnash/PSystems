/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class Rule30 extends MyxoRule {

    private String bacteriaDirection = null;
    private Membrane neighbourToUse = null;

    public Rule30(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.8;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;

        bacteriaDirection = bacteriaMembrane.getDirection();
        neighbourToUse = super.getNeighbourToUse(bacteriaDirection);

        if(super.facingBoundary(bacteriaDirection)) {
            return false;
        }

        //i.e., you can not move forward into more ecoli if you are already on an
        //ecoli spot. You must first lyse it. 
        if(membrane.isInternalEcoliEmpty() == false) {
            return false;
        }

        try {
            if(neighbourToUse.isInternalEcoliEmpty() == false && neighbourToUse.isInternalMembraneEmpty() == true) {
                return true;
            }
        }catch(Exception exp) {
           exp.printStackTrace();
        }

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {

        membrane.removeMembrane(bacteriaMembrane.getID());
        neighbourToUse.addMembrane(bacteriaMembrane);

        if(neighbourToUse.isInternalMembraneEmpty()) {
            occupiedList.remove(membrane);
        }

        occupiedList.add(neighbourToUse);

        return occupiedList;
    }

}
