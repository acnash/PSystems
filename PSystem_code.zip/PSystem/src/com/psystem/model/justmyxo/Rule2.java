/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import com.psystem.model.NeighbourMembrane;
import java.util.ArrayList;

/**
 * Movement using A-motility into an empty cell.
 * @author Anthony
 */
public class Rule2 extends MyxoRule {

    private String direction;
    private Membrane neighbourToUse = null;

    public Rule2(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //System.out.println("Rule2: adventurous movement");
        //add the bacteria membrane to the neighbourcell
        //neighbourToUse.addTempMembrane(this.bacteriaMembrane);
        neighbourToUse.addMembrane(this.bacteriaMembrane);

//        neighbourToUse.internalMembraneHasChanged();

        //remove the bacteria from the current environment membrane
        float tempId = bacteriaMembrane.getID();
        //membrane.removeTempMembrane(tempId);
        membrane.removeMembrane(tempId);
//        membrane.internalMembraneHasChanged();


        //1. if there is no slime then leave some, else dont
        MultiSetObject slimeObject = this.membrane.getMultiSetObject(RuleList.SLIME);
        if(slimeObject == null) {
            //leave slime
            slimeObject = new MultiSetObject();
            slimeObject.setObject(RuleList.SLIME);
            //membrane.addTempMultiSetObject(RuleList.SLIME, slimeObject);
            membrane.addMultiSetObject(RuleList.SLIME, slimeObject);
//            membrane.multisetHasChanged();
        }
//        membrane.wasCellEmpty();

        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        if(!occupiedList.contains(neighbourToUse)) {
            occupiedList.add(neighbourToUse);
        }

        return occupiedList;
    }

    @Override
    public double getStochasticValue() {
        return 5;
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        this.bacteriaMembrane = membraneOfInterest;
        String motility = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.MOTILITY).getObject();
        if(motility.equals(RuleList.S_MOTILITY)) {
            return false;
        }
        direction = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION).getObject();
        for(int i=0; i<this.neighbourList.size(); i++) {
            NeighbourMembrane neighbour = neighbourList.get(i);
            if(neighbour.getRelativePosition().equals(direction)) {
                if(neighbour.getMembrane().isEmpty()) {
                    neighbourToUse = neighbour.getMembrane();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
