/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import com.psystem.model.NeighbourMembrane;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * This rule is for invasion into an empty cell which is also about to be invaded
 * by another cell....
 *
 *
 * DO NOT USE
 *
 * @author Anthony
 */
public class Rule13 extends MyxoRule {

    private int cellsToRemain = 0;
    private int cellsToInvade = 0;
    private Membrane invadedMembrane;
    private String direction = null;
    private String motility = null;

    public Rule13(Membrane membrane) {
        this.membrane = membrane;
    }

    // returns the noninvading population i.e., a x% of the invasion
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        //I need the population of the invading membrane
        int offset = totalInvasion-400;
        if(offset <= 0) {
            
            return 0;
        }
        double contributingPercentage = (((double)invadingPopulation)/((double)totalInvasion))*100;
        double toReturn = (((double)offset)/100)*contributingPercentage;
        toReturn = Math.ceil(toReturn);
        cellsToInvade = (int)invadingPopulation - (int)toReturn;
        cellsToRemain = (int)toReturn;


        return (int)toReturn;
    }

    @Override
    public double getStochasticValue() {
        return 0.5;
    }

    /**
     * Identifies which membrane has invaded this particular environment
     * @param membraneOfInterest
     */
    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        invadedMembrane = membraneOfInterest;
        MultiSetObject directionObject = membraneOfInterest.getMultiSetObject(RuleList.DIRECTION);
        direction = (String)directionObject.getObject();
        MultiSetObject motilityObject = membraneOfInterest.getMultiSetObject(RuleList.MOTILITY);
        motility = (String)motilityObject.getObject();
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //if there has been a split I need to make a new membrane object
        if(cellsToRemain > 0) {
            Membrane laggingMembrane = new Membrane();
            MultiSetObject populationObject = new MultiSetObject();
            populationObject.setObject(cellsToRemain);
            laggingMembrane.addMultiSetObject(RuleList.POPULATION, populationObject);
//            laggingMembrane.addTempMultiSetObject(RuleList.POPULATION, populationObject);

            MultiSetObject directionObject = new MultiSetObject();
            directionObject.setObject(direction);
            laggingMembrane.addMultiSetObject(RuleList.DIRECTION, directionObject);
//            laggingMembrane.addTempMultiSetObject(RuleList.DIRECTION, directionObject);

            MultiSetObject motilityObject = new MultiSetObject();
            motilityObject.setObject(motility);
            laggingMembrane.addMultiSetObject(RuleList.MOTILITY, motilityObject);
//            laggingMembrane.addTempMultiSetObject(RuleList.MOTILITY, motilityObject);
        
            ArrayList<NeighbourMembrane> neighbours = membrane.getNeighbourhood();
            Hashtable<String, Membrane> table = getNeighbourTable(neighbours);

            //this is getting the environment from where the lag must go
            Membrane directionMembrane = null;

            //add the lagging membrane back to where it came from
            try {
                directionMembrane = invadedMembrane.getParentMembrane();
                laggingMembrane.setParentMembrane(directionMembrane);
                laggingMembrane.setTempParentMembrane(directionMembrane);
//                directionMembrane.addTempMembrane(laggingMembrane);
                directionMembrane.addMembrane(laggingMembrane);
                //directionMembrane.internalMembraneHasChanged();
            } catch(NullPointerException exp) {
                if(directionMembrane == null) {
                    System.out.println("DIRECTION MEMBRANE IS NULL");
                }
                if(laggingMembrane == null) {
                    System.out.println("LAGGINGMEMBRANE IS NULL");
                }
                exp.printStackTrace();
            }

            if(cellsToInvade == 0) {
                float id = invadedMembrane.getID();
//                membrane.removeTempMembrane(id);
                membrane.removeMembrane(id);
                //membrane.internalMembraneHasChanged();
            } else {
                //we now need to modify how much of this population remains
//                invadedMembrane.removeTempMultiSetObjct(RuleList.POPULATION);
                invadedMembrane.removeMultiSetObject(RuleList.POPULATION);
                MultiSetObject invadingPopulationObject = new MultiSetObject();
                invadingPopulationObject.setObject(cellsToInvade);
//                invadedMembrane.addTempMultiSetObject(RuleList.POPULATION, invadingPopulationObject);
                invadedMembrane.addMultiSetObject(RuleList.POPULATION, invadingPopulationObject);
                //invadedMembrane.multisetHasChanged();
                //not sure if I need this!
                //membrane.internalMembraneHasChanged();
            }
        }
        return occupiedList;
    }

    private Hashtable<String, Membrane> getNeighbourTable(ArrayList<NeighbourMembrane> neighbours) {
        Hashtable<String, Membrane> table = new Hashtable<String, Membrane>();
        for(int i=0; i<neighbours.size(); i++) {
            NeighbourMembrane currentNeighbour = neighbours.get(i);
            String relativePosition = currentNeighbour.getRelativePosition();
            Membrane relativeMembrane = currentNeighbour.getMembrane();
            table.put(relativePosition, relativeMembrane);
        }
        return table;
    }

}
