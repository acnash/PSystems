/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * Binding to a neighbour directly in front, facing in that direction i.e., RULE 3A
 *
 * @author Anthony
 */
public class Rule20a extends MyxoRule {

    private String facingDirection = null;
    private Membrane neighbourMembraneEnv = null;
    private Membrane membraneToBindTo;

    public Rule20a(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.8;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;
        //facingDirection = (String)bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION).getObject();
        facingDirection = bacteriaMembrane.getDirection();

        if(bacteriaMembrane.getBoundToID() != 0) {
            return false;
        }

        if(super.facingBoundary(facingDirection)) {
            return false;
        }

        neighbourMembraneEnv = super.getNeighbourToUse(facingDirection);
        if(neighbourMembraneEnv == null) {
            return false;
        }
        Hashtable<String, Membrane> neighbourInternalMembranes = new Hashtable<String, Membrane>();
        ArrayList<Membrane> internalMembranes = neighbourMembraneEnv.getMembraneList();
        for(int i=0; i<internalMembranes.size(); i++) {
            Membrane tempMembrane = internalMembranes.get(i);
            String tempDirection = tempMembrane.getDirection();
            //String tempDirection = (String)tempMembrane.getMultiSetObject(RuleList.DIRECTION).getObject();
            neighbourInternalMembranes.put(tempDirection, tempMembrane);
        }

        if(facingDirection.equals(RuleList.NORTH_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.NORTH_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.NORTH_STR);
                return true;
            }
        }
        if(facingDirection.equals(RuleList.SOUTH_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.SOUTH_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.SOUTH_STR);
                return true;
            }
        }
        if(facingDirection.equals(RuleList.EAST_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.EAST_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.EAST_STR);
                return true;
            }
        }
        if(facingDirection.equals(RuleList.WEST_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.WEST_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.WEST_STR);
                return true;
            }
        }
        if(facingDirection.equals(RuleList.NORTH_EAST_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.NORTH_EAST_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.NORTH_EAST_STR);
                return true;
            }
        }
        if(facingDirection.equals(RuleList.NORTH_WEST_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.NORTH_WEST_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.NORTH_WEST_STR);
                return true;
            }
        }
        if(facingDirection.equals(RuleList.SOUTH_EAST_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.SOUTH_EAST_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.SOUTH_EAST_STR);
                return true;
            }
        }
        if(facingDirection.equals(RuleList.SOUTH_WEST_STR)) {
            if(neighbourInternalMembranes.containsKey(RuleList.SOUTH_WEST_STR)) {
                this.membraneToBindTo = neighbourInternalMembranes.get(RuleList.SOUTH_WEST_STR);
                return true;
            }
        }


        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
//        System.out.println("Rule 20a executing");
        super.bacteriaMembrane.setBoundToID(this.membraneToBindTo.getID());
        return occupiedList;
    }

}
