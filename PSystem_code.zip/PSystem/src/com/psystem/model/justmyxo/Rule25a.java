package com.psystem.model.justmyxo;


import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Move forward into an empty cell which has slime
 *
 * @author Anthony
 */
public class Rule25a extends MyxoRule {

    private Membrane neighbourToUse = null;
    private String facingDirection = null;

    public Rule25a(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.35;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;
        neighbourToUse = null;
        facingDirection = null;

        facingDirection = bacteriaMembrane.getDirection();
        if(super.facingBoundary(facingDirection)) {
            return false;
        }
        neighbourToUse = super.getNeighbourToUse(facingDirection);
        if(neighbourToUse.isEmpty() && neighbourToUse.hasSlime()) {
            return true;
        }

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        if(!membrane.hasSlime()) {
            membrane.leaveSlime();
        }
        membrane.removeMembrane(bacteriaMembrane.getID());
        neighbourToUse.addMembrane(bacteriaMembrane);

        occupiedList.add(neighbourToUse);
        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }

        return occupiedList;
    }

}
