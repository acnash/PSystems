package com.psystem.model.justmyxo;


import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Move forward into an empty cell which is to the left and has slime.. it also turns that direction
 *
 * @author Anthony
 */
public class Rule25b extends MyxoRule {

    private Membrane neighbourToUse = null;
    private String facingDirection = null;
    private String newDirection = null;

    public Rule25b(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.1;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;
        neighbourToUse = null;
        facingDirection = null;
        newDirection = null;

        facingDirection = bacteriaMembrane.getDirection();
        
        if(facingDirection.equals(RuleList.NORTH_STR)) {
            newDirection = RuleList.NORTH_WEST_STR;
        } else if(facingDirection.equals(RuleList.NORTH_WEST_STR)) {
            newDirection = RuleList.WEST_STR;
        } else if(facingDirection.equals(RuleList.WEST_STR)) {
            newDirection = RuleList.SOUTH_WEST_STR;
        } else if(facingDirection.equals(RuleList.SOUTH_WEST_STR)) {
            newDirection = RuleList.SOUTH_STR;
        } else if(facingDirection.equals(RuleList.SOUTH_STR)) {
            newDirection = RuleList.SOUTH_EAST_STR;
        } else if(facingDirection.equals(RuleList.SOUTH_EAST_STR)) {
            newDirection = RuleList.EAST_STR;
        } else if(facingDirection.equals(RuleList.EAST_STR)) {
            newDirection = RuleList.NORTH_EAST_STR;
        } else {
            newDirection = RuleList.NORTH_STR;
        }

        if(super.facingBoundary(newDirection)) {
            return false;
        }

        neighbourToUse = super.getNeighbourToUse(newDirection);
        if(neighbourToUse.isEmpty() && neighbourToUse.hasSlime()) {
            return true;
        }

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        if(!membrane.hasSlime()) {
            membrane.leaveSlime();
        }
        membrane.removeMembrane(bacteriaMembrane.getID());
        bacteriaMembrane.changeDirection(newDirection);
        neighbourToUse.addMembrane(bacteriaMembrane);


        occupiedList.add(neighbourToUse);
        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }

        return occupiedList;
    }

}
