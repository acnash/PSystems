/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class Rule15b extends MyxoRule {

    private Membrane invadingMembrane;
    private String bacteriaDirection;
    private Membrane neighbourToInvade;
    private int totalNeighbourPopulation =0;
    private int invadingPopulation;
    private int populationToInvade;
    private boolean hasChangedDirection = false;

    public Rule15b(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
//        ArrayList<Membrane> innerNeighbourMembranes = neighbourToInvade.getMembraneList();
//        for(int i=0; i<innerNeighbourMembranes.size(); i++) {
//            MultiSetObject popObj = innerNeighbourMembranes.get(i).getMultiSetObject(RuleList.POPULATION);
//            totalNeighbourPopulation += (Integer)popObj.getObject();
//        }
        return (double)totalNeighbourPopulation/400;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private double calculateInvadingPopulation(int concentration) {
        double unbind = 0.4;
        double bind = 0.05;
        double bound = 0.2;
        double vMax = 1;
        double kM = (unbind + bound)/(bind);
        return (vMax*(concentration))/(kM + concentration);

    }


    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        this.invadingMembrane = membraneOfInterest;
        totalNeighbourPopulation = 0;
        invadingPopulation = 0;
        populationToInvade = 0;
        hasChangedDirection = false;
//        MultiSetObject invadingPopObj = invadingMembrane.getMultiSetObject(RuleList.POPULATION);
//        invadingPopulation = (Integer)invadingPopObj.getObject();

        MultiSetObject invadingPopObj = invadingMembrane.getMultiSetObject(RuleList.POPULATION);
        int potentialInvasion = (Integer)invadingPopObj.getObject();
        double percentToInvade = calculateInvadingPopulation(potentialInvasion);

        //double rawInvasion = ((double)(potentialInvasion/100)*(percentToInvade*100));
        double top = (double)potentialInvasion/100;
        double fullerPercent = (double)percentToInvade*100;
        double rawInvasion = top * fullerPercent;

        invadingPopulation = (int)Math.round(rawInvasion);

        //1. Is this in the right motility i.e., it must be adventurous motility
        String motility = (String)this.invadingMembrane.getMultiSetObject(RuleList.MOTILITY).getObject();
        if(motility.equals(RuleList.A_MOTILITY)) {
            return false;
        }

        bacteriaDirection = (String)this.invadingMembrane.getMultiSetObject(RuleList.DIRECTION).getObject();
        //2 preliminary boundary condition check to see if there is a neighbour in my direction
        if(facingBoundary(bacteriaDirection)) {
            return false;
        }

        //3 is the slime in the same direction that the bacteria is facing?
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.NORTH_EAST))) {
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.EAST),RuleList.SAME_BACTERIA);
            if(isInFrontOccupied) {
                neighbourToInvade = getNeighbourToUse(RuleList.getDirection(RuleList.EAST));
                hasChangedDirection = true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.NORTH_WEST))) {
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.NORTH),RuleList.SAME_BACTERIA);
            if(isInFrontOccupied) {
                neighbourToInvade = getNeighbourToUse(RuleList.getDirection(RuleList.NORTH));
                hasChangedDirection = true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.SOUTH_WEST))) {
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.WEST),RuleList.SAME_BACTERIA);
            if(isInFrontOccupied) {
                neighbourToInvade = getNeighbourToUse(RuleList.getDirection(RuleList.WEST));
                hasChangedDirection = true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.SOUTH_EAST))) {
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.SOUTH),RuleList.SAME_BACTERIA);
            if(isInFrontOccupied) {
                neighbourToInvade = getNeighbourToUse(RuleList.getDirection(RuleList.SOUTH));
                hasChangedDirection = true;
            }
        }

        if(hasChangedDirection == false) {
            return false;
        }

        ArrayList<Membrane> innerNeighbourMembranes = neighbourToInvade.getMembraneList();
        for(int i=0; i<innerNeighbourMembranes.size(); i++) {
            MultiSetObject popObj = innerNeighbourMembranes.get(i).getMultiSetObject(RuleList.POPULATION);
            totalNeighbourPopulation += (Integer)popObj.getObject();
        }
        if(totalNeighbourPopulation < 400) {
            int populationAllowedToInvade = 400-totalNeighbourPopulation;
            if(populationAllowedToInvade > invadingPopulation) {
                populationToInvade = invadingPopulation;
            } else {
                populationToInvade = populationAllowedToInvade;
            }
        } else {
            hasChangedDirection = false;
        }

        return hasChangedDirection;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        Membrane newMembrane = new Membrane();
        //this will get updated thankfully
        //newMembrane.setParentMembrane(invadingMembrane.getParentMembrane());

        //give it all the same properties
        MultiSetObject directionObject = new MultiSetObject();
        directionObject.setObject(invadingMembrane.getMultiSetObject(RuleList.DIRECTION).getObject());
        MultiSetObject motilityObject = new MultiSetObject();
        motilityObject.setObject(invadingMembrane.getMultiSetObject(RuleList.MOTILITY).getObject());
        MultiSetObject populationObject = new MultiSetObject();
        populationObject.setObject(populationToInvade);


        newMembrane.addMultiSetObject(RuleList.DIRECTION, directionObject);
        newMembrane.addMultiSetObject(RuleList.MOTILITY, motilityObject);
        newMembrane.addMultiSetObject(RuleList.POPULATION, populationObject);

        //i really need to modify the original cell i.e.,
        int remainingPopulation = invadingPopulation - populationToInvade;
        if(remainingPopulation == 0) {
            //we must remove the cell...
            membrane.removeMembrane(invadingMembrane.getID());
        } else {
            MultiSetObject originalPopulationObject = new MultiSetObject();
            originalPopulationObject.setObject(remainingPopulation);
            invadingMembrane.removeMultiSetObject(RuleList.POPULATION);
            invadingMembrane.addMultiSetObject(RuleList.POPULATION,originalPopulationObject);
            MultiSetObject originalDirectionObject = new MultiSetObject();
            originalDirectionObject.setObject((String)directionObject.getObject());
            invadingMembrane.removeMultiSetObject(RuleList.DIRECTION);
            invadingMembrane.addMultiSetObject(RuleList.DIRECTION, originalDirectionObject);
        }

        neighbourToInvade.addMembrane(newMembrane);

        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        if(!occupiedList.contains(neighbourToInvade)) {
            occupiedList.add(neighbourToInvade);
        }


        return occupiedList;
    }

}
