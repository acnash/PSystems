/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class Rule3b extends MyxoRule {

    private String bacteriaDirection;
    private String slimeDirection;
    private Membrane neighbourToUse = null;
    private String newDirection = null;

    public Rule3b(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 5;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        this.bacteriaMembrane = membraneOfInterest;

        //1. Is this in the right motility i.e., it must be adventurous motility
        String motility = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.MOTILITY).getObject();
        if(motility.equals(RuleList.S_MOTILITY)) {
            return false;
        }

        bacteriaDirection = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION).getObject();

        //for each slime direction determine the left turn conditions
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.NORTH))) {
            //0. is it a brickwall?
            if(facingBoundary(RuleList.getDirection(RuleList.NORTH_WEST))) {
                return false;
            }
            //1. does it have slime?
            //2. is it free?
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.NORTH_WEST),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.NORTH_WEST),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.NORTH_WEST));
                newDirection = RuleList.getDirection(RuleList.NORTH_WEST);
                return true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.SOUTH))) {
            if(facingBoundary(RuleList.getDirection(RuleList.SOUTH_EAST))) {
                return false;
            }
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.SOUTH_EAST),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.SOUTH_EAST),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.SOUTH_EAST));
                newDirection = RuleList.getDirection(RuleList.SOUTH_EAST);
                return true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.EAST))) {
            if(facingBoundary(RuleList.getDirection(RuleList.NORTH_EAST))) {
                return false;
            }
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.NORTH_EAST),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.NORTH_EAST),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.NORTH_EAST));
                newDirection = RuleList.getDirection(RuleList.NORTH_EAST);
                return true;
            }
        }
        if(bacteriaDirection.equals(RuleList.getDirection(RuleList.WEST))) {
            if(facingBoundary(RuleList.getDirection(RuleList.SOUTH_WEST))) {
                return false;
            }
            boolean isInFrontSlime = checkDirection(RuleList.getDirection(RuleList.SOUTH_WEST),RuleList.SLIME);
            boolean isInFrontOccupied = checkDirection(RuleList.getDirection(RuleList.SOUTH_WEST),RuleList.SAME_BACTERIA);
            if(isInFrontSlime && !isInFrontOccupied) {
                neighbourToUse = getNeighbourToUse(RuleList.getDirection(RuleList.SOUTH_WEST));
                newDirection = RuleList.getDirection(RuleList.SOUTH_WEST);
                return true;
            }
        }

        return false;


    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //System.out.println("Rule3b: Slime directed adventurous movement");
         //1. if there is no slime then leave some, else dont
        MultiSetObject slimeObject = this.membrane.getMultiSetObject(RuleList.SLIME);
        if(slimeObject == null) {
            //leave slime
            slimeObject = new MultiSetObject();
            slimeObject.setObject(RuleList.SLIME);
            //membrane.addTempMultiSetObject(RuleList.SLIME, slimeObject);
            membrane.addMultiSetObject(RuleList.SLIME, slimeObject);
//            membrane.multisetHasChanged();
        }

        //2. must change the direction of the bacterium
        //bacteriaMembrane.removeTempMultiSetObjct(RuleList.DIRECTION);
        bacteriaMembrane.removeMultiSetObject(RuleList.DIRECTION);
        MultiSetObject newDirectionObject = new MultiSetObject();
        newDirectionObject.setObject(this.newDirection);
        //bacteriaMembrane.addTempMultiSetObject(RuleList.DIRECTION, newDirectionObject);
        bacteriaMembrane.addMultiSetObject(RuleList.DIRECTION, newDirectionObject);
//        bacteriaMembrane.multisetHasChanged();

        //3. move the membraneOfInterest in the direction picked earlier
        //membrane.removeTempMembrane(bacteriaMembrane.getID());
        membrane.removeMembrane(bacteriaMembrane.getID());
//        membrane.internalMembraneHasChanged();
        //neighbourToUse.addTempMembrane(bacteriaMembrane);
        neighbourToUse.addMembrane(bacteriaMembrane);
//        neighbourToUse.internalMembraneHasChanged();
//        membrane.wasCellEmpty();

        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        if(!occupiedList.contains(neighbourToUse)) {
            occupiedList.add(neighbourToUse);
        }
        return occupiedList;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
