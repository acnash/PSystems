/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 * Changing from A-motility to S-motility
 * This will depend a lot on the population denstiy of itself and 
 * facing neighbours
 *
 *
 * @author Anthony
 */
public class Rule10 extends MyxoRule {

    private Membrane bacteriaMembrane;
    private Membrane neighbourEnvironmentMembrane;

    private int bacteriaPopulation = 0;
    private int totalNeighbourPopulation = 0;

    private double unbind = 0.4;
    private double bind = 0.05;
    private double bound = 0.2;
    private double vMax = 1;

    private double stochasticValue = 0;

    public Rule10(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        //first check if you are actually in Am mode to start
        bacteriaMembrane = membraneOfInterest;
        stochasticValue = 0;

        MultiSetObject motilityObject = bacteriaMembrane.getMultiSetObject(RuleList.MOTILITY);
        String motility = (String)motilityObject.getObject();
        if(motility.equals(RuleList.S_MOTILITY)) {
            return false;
        }

        MultiSetObject bacteriaPopObj = bacteriaMembrane.getMultiSetObject(RuleList.POPULATION);
        bacteriaPopulation = (Integer)bacteriaPopObj.getObject();
        MultiSetObject bacteriaDirection = bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION);
        String bacteriaDirectionString = (String)bacteriaDirection.getObject();

        neighbourEnvironmentMembrane = super.getNeighbourToUse(bacteriaDirectionString);
        if(neighbourEnvironmentMembrane != null) {
            ArrayList<Membrane> neighbourInternal = neighbourEnvironmentMembrane.getMembraneList();
            for(int i=0; i<neighbourInternal.size(); i++) {
                MultiSetObject internalMembrane = neighbourInternal.get(i).getMultiSetObject(RuleList.POPULATION);
                totalNeighbourPopulation += (Integer)internalMembrane.getObject();
            }
        }
        int totalConcentration = bacteriaPopulation + totalNeighbourPopulation;
        double kM = (unbind + bound)/(bind);
        stochasticValue = (vMax*(totalConcentration))/(kM + totalConcentration);

        return true;
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        bacteriaMembrane.removeMultiSetObject(RuleList.MOTILITY);

        MultiSetObject motilityObject = new MultiSetObject();
        motilityObject.setObject(RuleList.S_MOTILITY);
        bacteriaMembrane.addMultiSetObject(RuleList.MOTILITY, motilityObject);

        return occupiedList;
    }

    @Override
    public double getStochasticValue() {
        return stochasticValue;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
