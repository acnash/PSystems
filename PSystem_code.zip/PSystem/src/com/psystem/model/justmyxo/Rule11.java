/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 * The reversal of S-motility into A-motility. This will depend on its
 * own population and the population of the cells around it
 *
 *
 * @author Anthony
 */
public class Rule11 extends MyxoRule {

    private Membrane bacteriaMembrane;
    private Membrane neighbourEnvironmentMembrane;

    private int bacteriaPopulation = 0;
    private int totalNeighbourPopulation = 0;

    private double stochasticValue = 0;

    public Rule11(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return stochasticValue;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        //first check if you are actually in Mm mode to start
        bacteriaMembrane = membraneOfInterest;
        stochasticValue = 0;

        MultiSetObject motilityObject = bacteriaMembrane.getMultiSetObject(RuleList.MOTILITY);
        String motility = (String)motilityObject.getObject();
        if(motility.equals(RuleList.A_MOTILITY)) {
            return false;
        }

        MultiSetObject bacteriaPopObj = bacteriaMembrane.getMultiSetObject(RuleList.POPULATION);
        bacteriaPopulation = (Integer)bacteriaPopObj.getObject();
        MultiSetObject bacteriaDirection = bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION);
        String bacteriaDirectionString = (String)bacteriaDirection.getObject();

        neighbourEnvironmentMembrane = super.getNeighbourToUse(bacteriaDirectionString);
        if(neighbourEnvironmentMembrane != null) {
            ArrayList<Membrane> neighbourInternal = neighbourEnvironmentMembrane.getMembraneList();
            for(int i=0; i<neighbourInternal.size(); i++) {
                MultiSetObject internalMembrane = neighbourInternal.get(i).getMultiSetObject(RuleList.POPULATION);
                totalNeighbourPopulation += (Integer)internalMembrane.getObject();
            }
        }
        int totalConcentration = bacteriaPopulation + totalNeighbourPopulation;
        stochasticValue = 1/(1+Math.exp((totalConcentration/2)-10));

        stochasticValue += 0.05;

        return true;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        bacteriaMembrane.removeMultiSetObject(RuleList.MOTILITY);

        MultiSetObject motilityObject = new MultiSetObject();
        motilityObject.setObject(RuleList.A_MOTILITY);
        bacteriaMembrane.addMultiSetObject(RuleList.MOTILITY, motilityObject);

        return occupiedList;
    }

}
