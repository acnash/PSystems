/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 * Move forward into an empty cell and leave slime behind
 *
 * @author Anthony
 */
public class Rule22 extends MyxoRule {

    private String facingDirection = null;
    private Membrane neighbourToMoveTo = null;

    public Rule22(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 2.5;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;
        facingDirection = null;
        neighbourToMoveTo = null;

        facingDirection = (String)membraneOfInterest.getMultiSetObject(RuleList.DIRECTION).getObject();
        if(super.facingBoundary(facingDirection)) {
            return false;
        }

        neighbourToMoveTo = super.getNeighbourToUse(facingDirection);

        if(neighbourToMoveTo.isInternalEcoliEmpty() == false) {
            return false;
        }

        if(neighbourToMoveTo.isEmpty()) {
            return true;
        }

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {

        neighbourToMoveTo.addMembrane(bacteriaMembrane);
        membrane.removeMembrane(bacteriaMembrane.getID());

        //this is a bit of a problem...... I need to work on this....
        //you should check whether you can repair the connection - if not then
        //you should move forward
        if(bacteriaMembrane.getBoundToID() == 0) {
            MultiSetObject currentSlime = membrane.getMultiSetObject(RuleList.SLIME);
            if(currentSlime == null) {
                currentSlime = new MultiSetObject();
                currentSlime.setObject(RuleList.SLIME);
                membrane.addMultiSetObject(RuleList.SLIME, currentSlime);
            }
        }


        occupiedList.add(neighbourToMoveTo);
        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        return occupiedList;
    }

}
