/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 * REVERSAL
 * Specifically for head on collision with one cell invading a populated cell. 
 *
 * DO NOT USE
 *
 * @author Anthony
 */
public class Rule14 extends MyxoRule {

    private Membrane invadingMembrane;
    private Membrane nativeMembrane;

    public Rule14(Membrane membrane) {
        this.membrane = membrane;
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //we need the direction out of both membranes
//        MultiSetObject invadingObj = invadingMembrane.getTempMultiSetObject(RuleList.DIRECTION);
//        MultiSetObject nativeObj = nativeMembrane.getTempMultiSetObject(RuleList.DIRECTION);
        MultiSetObject invadingObj = invadingMembrane.getMultiSetObject(RuleList.DIRECTION);
        MultiSetObject nativeObj = nativeMembrane.getMultiSetObject(RuleList.DIRECTION);
        String invadingDirection = (String)invadingObj.getObject();
        String nativeDirection = (String)nativeObj.getObject();
        String reversedInvadingDirection = super.reverseDirection(invadingDirection);
        String reversedNativeDirection = super.reverseDirection(nativeDirection);

        //we need the neighbour who is the parent of the invading membrane
        Membrane parentNeighbour = invadingMembrane.getParentMembrane();

        //both membranes change direction
//        invadingMembrane.removeTempMultiSetObjct(RuleList.DIRECTION);
//        nativeMembrane.removeTempMultiSetObjct(RuleList.DIRECTION);
        invadingMembrane.removeMultiSetObject(RuleList.DIRECTION);
        nativeMembrane.removeMultiSetObject(RuleList.DIRECTION);
        MultiSetObject reversedInvadingObj = new MultiSetObject();
        MultiSetObject reversedNativeObj = new MultiSetObject();
        reversedInvadingObj.setObject(reversedInvadingDirection);
        reversedNativeObj.setObject(reversedNativeDirection);
//        invadingMembrane.addTempMultiSetObject(RuleList.DIRECTION, reversedInvadingObj);
//        nativeMembrane.addTempMultiSetObject(RuleList.DIRECTION, reversedNativeObj);
        invadingMembrane.addMultiSetObject(RuleList.DIRECTION, reversedInvadingObj);
        nativeMembrane.addMultiSetObject(RuleList.DIRECTION, reversedNativeObj);

        //the invading membrane is removed from 'membrane'
//        membrane.removeTempMembrane(invadingMembrane.getID());
        membrane.removeMembrane(invadingMembrane.getID());

        //the invading membrane is added back into the neighbour
//        parentNeighbour.addTempMembrane(invadingMembrane);
        parentNeighbour.addMembrane(invadingMembrane);

        return occupiedList;
    }

    @Override
    public double getStochasticValue() {
        return 0.8;
    }

    /**
     * These membranes already exist in the environment we are fighting over.
     * @param membrane1
     * @param membrane2
     */
    public void setCollidingMembrane(Membrane invadingMembrane, Membrane nativeMembrane) {
        this.invadingMembrane = invadingMembrane;
        this.nativeMembrane = nativeMembrane;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * There should be no need to check the rule as this is only executed under
     * special circumstances.
     *
     * @param membraneOfInterest
     * @return
     */
    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        return invadingPopulation;
    }

    

}
