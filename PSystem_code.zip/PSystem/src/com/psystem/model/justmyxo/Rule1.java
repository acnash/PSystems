/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import com.psystem.model.NeighbourMembrane;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class Rule1 extends MyxoRule {

    private String direction;
    private Membrane neighbourToUse = null;

    /**
     * This is the movement via social motility
     *
     * Recall that the Membrane is actually the environment membrane
     * @param membrane
     */
    public Rule1(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //System.out.println("Rule1: Forward social");
        //add the bacteria membrane to the neighbourcell

        //neighbourToUse.addTempMembrane(this.bacteriaMembrane);
        neighbourToUse.addMembrane(this.bacteriaMembrane);
        //neighbourToUse.internalMembraneHasChanged();

        //remove the bacteria from the current environment membrane
        float tempId = bacteriaMembrane.getID();
        //membrane.removeTempMembrane(tempId);
        membrane.removeMembrane(tempId);
        //membrane.internalMembraneHasChanged();
        //membrane.wasCellEmpty();

        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        if(!occupiedList.contains(neighbourToUse)) {
            occupiedList.add(neighbourToUse);
        }

        return occupiedList;
    }

    @Override
    public double getStochasticValue() {
        return 0.05;
    }

    /**
     * Check that the neighbouring bacteria is:
     * a)empty
     * b)not a wall.
     * Must use the bacterium P System's direction
     * @return
     */
    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        this.bacteriaMembrane = membraneOfInterest;
        String motility = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.MOTILITY).getObject();
        if(motility == null) {
            System.out.println("I am missing a motility from somewhere....");
        }
        if(motility.equals("ERROR!")) {
            System.out.println("I created the error");
        }
        if(motility.equals(RuleList.A_MOTILITY)) {
            return false;
        }
        direction = (String)this.bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION).getObject();
        for(int i=0; i<this.neighbourList.size(); i++) {
            NeighbourMembrane neighbour = neighbourList.get(i);
            if(neighbour.getRelativePosition().equals(direction)) {
                if(neighbour.getMembrane().isEmpty()) {
                    neighbourToUse = neighbour.getMembrane();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
