/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import com.psystem.model.NeighbourMembrane;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * This is adventuruous movement into an occupied cell
 *
 * @author Anthony
 */
public class Rule5 extends MyxoRule {

    private Membrane membraneToInvade = null;
    private Membrane invadingMembrane = null;
    private String directionFacing = null;
    private int neighbourPopulation;
    private int invadingPopulation;
    private int populationToInvade;

    public Rule5(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.8;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        invadingMembrane = membraneOfInterest;
        neighbourPopulation = 0;
        invadingPopulation = 0;
        populationToInvade = 0;

        String motility = (String)this.invadingMembrane.getMultiSetObject(RuleList.MOTILITY).getObject();
        if(motility.equals(RuleList.S_MOTILITY)) {
            return false;
        }

        //get the direction you are facing
        MultiSetObject directionObject = invadingMembrane.getMultiSetObject(RuleList.DIRECTION);
        MultiSetObject populationObject = invadingMembrane.getMultiSetObject(RuleList.POPULATION);
        directionFacing = (String)directionObject.getObject();
        invadingPopulation = (Integer)populationObject.getObject();
        
        //look at that neighbour
        //ArrayList<NeighbourMembrane> neighbours = invadingMembrane.getNeighbourhood();
        for(int i=0; i<neighbourhood.size(); i++) {
            NeighbourMembrane neighbour = neighbourhood.get(i);
            if(neighbour.getRelativePosition().equals(directionFacing)) {
                membraneToInvade = neighbour.getMembrane();
                break;
            }
        }
        if(membraneToInvade == null) {
            return false; //I may be facing a boundary
        }

        //if there is nobody there then result false, else
        if(membraneToInvade.isEmpty()) {
            return false;
        }

        ArrayList<Membrane> internalMembranes = membraneToInvade.getMembraneList();
        for(int n=0; n<internalMembranes.size(); n++) {
            MultiSetObject neighbourPopObject = internalMembranes.get(n).getMultiSetObject(RuleList.POPULATION);
            neighbourPopulation += (Integer)neighbourPopObject.getObject();
        }

        if(neighbourPopulation < 400) {
            int populationAllowedToInvade = 400-neighbourPopulation;
            if(populationAllowedToInvade > invadingPopulation) {
                populationToInvade = invadingPopulation;
                return true;
            } else {
                populationToInvade = populationAllowedToInvade;
                return true;
            }
        }

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    //4 membranes
    //the environment "membrane"
    //the invading membrane "invadingMembrane"
    //the environment to invade "membraneToInvade"
    //the new membrane that splits of "newMembrane", it goes into "membraneToInvade"

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //System.out.println("I am Rule5");
        //make a new membrane
        Membrane newMembrane = new Membrane();
        //this will get updated thankfully
        newMembrane.setParentMembrane(invadingMembrane.getParentMembrane());
        
        //give it all the same properties
        MultiSetObject directionObject = new MultiSetObject();
        directionObject.setObject(invadingMembrane.getMultiSetObject(RuleList.DIRECTION).getObject());
        MultiSetObject motilityObject = new MultiSetObject();
        motilityObject.setObject(invadingMembrane.getMultiSetObject(RuleList.MOTILITY).getObject());
        MultiSetObject populationObject = new MultiSetObject();
        populationObject.setObject(populationToInvade);

        
        newMembrane.addMultiSetObject(RuleList.DIRECTION, directionObject);
        newMembrane.addMultiSetObject(RuleList.MOTILITY, motilityObject);
        newMembrane.addMultiSetObject(RuleList.POPULATION, populationObject);
        
        MultiSetObject slimeObject = this.membrane.getMultiSetObject(RuleList.SLIME);
        if(slimeObject == null) {
            //leave slime
            slimeObject = new MultiSetObject();
            slimeObject.setObject(RuleList.SLIME);
            membrane.addMultiSetObject(RuleList.SLIME, slimeObject);
//            membrane.multisetHasChanged();
        }

        //i really need to modify the original cell i.e.,
        int remainingPopulation = invadingPopulation - populationToInvade;
        if(remainingPopulation == 0) {
            //we must remove the cell...
            membrane.removeMembrane(invadingMembrane.getID());
        } else {
            MultiSetObject originalPopulationObject = new MultiSetObject();
            originalPopulationObject.setObject(remainingPopulation);
            invadingMembrane.removeMultiSetObject(RuleList.POPULATION);
            invadingMembrane.addMultiSetObject(RuleList.POPULATION,originalPopulationObject);
            MultiSetObject originalDirectionObject = new MultiSetObject();
            originalDirectionObject.setObject((String)directionObject.getObject());
            invadingMembrane.removeMultiSetObject(RuleList.DIRECTION);
            invadingMembrane.addMultiSetObject(RuleList.DIRECTION, originalDirectionObject);
        }

        membraneToInvade.addMembrane(newMembrane);

        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        if(!occupiedList.contains(membraneToInvade)) {
            occupiedList.add(membraneToInvade);
        }
        //membraneToInvade.addTempMembrane(newMembrane);
        
        //the population in this membrane is populationToInvade
        
        //add it into the neighbourMembrane tempinternalmembranes
        return occupiedList;

    }

}
