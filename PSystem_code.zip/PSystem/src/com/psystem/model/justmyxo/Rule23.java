/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 *
 * Spontaneuous reversal
 *
 * @author Anthony
 */
public class Rule23 extends MyxoRule {

    private boolean canReverse = true;

    public Rule23(Membrane membrane) {
        this.membrane = membrane;

    }


    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //System.out.println("Rule11: Reversal");
        MultiSetObject directionObject = bacteriaMembrane.getMultiSetObject(RuleList.DIRECTION);
        String direction = (String)directionObject.getObject();

        MultiSetObject newDirectionObject = new MultiSetObject();

        if(direction.equals(RuleList.getDirection(RuleList.NORTH))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.SOUTH));
        }
        if(direction.equals(RuleList.getDirection(RuleList.NORTH_EAST))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.SOUTH_WEST));
        }
        if(direction.equals(RuleList.getDirection(RuleList.EAST))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.WEST));
        }
        if(direction.equals(RuleList.getDirection(RuleList.SOUTH_EAST))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.NORTH_WEST));
        }
        if(direction.equals(RuleList.getDirection(RuleList.SOUTH))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.NORTH));
        }
        if(direction.equals(RuleList.getDirection(RuleList.SOUTH_WEST))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.NORTH_EAST));
        }
        if(direction.equals(RuleList.getDirection(RuleList.WEST))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.EAST));
        }
        if(direction.equals(RuleList.getDirection(RuleList.NORTH_WEST))) {
            newDirectionObject.setObject(RuleList.getDirection(RuleList.SOUTH_EAST));
        }

        //bacteriaMembrane.removeTempMultiSetObjct(RuleList.DIRECTION);
        bacteriaMembrane.removeMultiSetObject(RuleList.DIRECTION);
        //bacteriaMembrane.addTempMultiSetObject(RuleList.DIRECTION, newDirectionObject);
        bacteriaMembrane.addMultiSetObject(RuleList.DIRECTION, newDirectionObject);
        //bacteriaMembrane.multisetHasChanged();
        canReverse = false;

        bacteriaMembrane.setBoundToID(0);

        return occupiedList;
    }



    @Override
    public double getStochasticValue() {
        return 0.01;
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;

        if(canReverse == false) {
            canReverse = true;
            return false;
        }

        MultiSetObject populationObject = bacteriaMembrane.getMultiSetObject(RuleList.POPULATION);
        if(populationObject != null) {
            if(((Integer)populationObject.getObject()) > 0) {
                return true;
            } else {
                return false;
            }
        }

        return false;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {

    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}