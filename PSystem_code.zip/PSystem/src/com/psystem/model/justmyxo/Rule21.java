/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import com.psystem.model.NeighbourMembrane;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Random;

/**
 *
 * Searches for the missing bindID and then moves in that direction
 *
 * @author Anthony
 */
public class Rule21 extends MyxoRule {

    private String facingDirection = null;
    private String newDirection = null;
    private boolean mustMove = false;
    private Membrane membraneToMoveTo = null;

    public Rule21(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 2.0;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;
        float boundToID = 0;
        facingDirection = null;
        newDirection = null;
        mustMove = false;
        membraneToMoveTo = null;

        //get your direction
        facingDirection = (String)membraneOfInterest.getMultiSetObject(RuleList.DIRECTION).getObject();
        boundToID = bacteriaMembrane.getBoundToID();

        if(boundToID == 0) {
            return false;
        }

        //is there a membrane in front of you who has this direction?
        if(super.facingBoundary(facingDirection)) {
            return false;
        }

        //is there a neighbour with this ID, if there is return false, else continue looking
        Membrane neighbourMembrane = super.getNeighbourToUse(facingDirection);
        ArrayList<Membrane> internalList = neighbourMembrane.getMembraneList();
        for(int i=0; i<internalList.size(); i++) {
            Membrane tempMembrane = internalList.get(i);
            //float neighbourID = tempMembrane.getBoundToID();
            float neighbourID = tempMembrane.getID();
            if(neighbourID == boundToID) {
                return false;
            }
        }

        //if I am only using straight rules, then this should never happen as the
        //bound to membrane should always be infront
        //go through the local neighbours
        Enumeration neighbourEnum = super.neighbourTable.keys();
        while(neighbourEnum.hasMoreElements()) {
            String relativeDirection = (String)neighbourEnum.nextElement();
            Membrane tempMembrane = neighbourTable.get(relativeDirection);
            ArrayList<Membrane> internals = tempMembrane.getMembraneList();
            for(int i=0; i<internals.size(); i++) {
                Membrane internal = internals.get(i);
                //if(internal.getBoundToID() == boundToID) {
                if(internal.getID() == boundToID) {
                    newDirection = relativeDirection;
                    return true;
                }
            }
        }

        

        if(checkExtendedDirection(RuleList.NORTH_STR, boundToID)) {
            return true;
        }
        if(checkExtendedDirection(RuleList.NORTH_EAST_STR, boundToID)) {
            return true;
        }
        if(checkExtendedDirection(RuleList.EAST_STR, boundToID)) {
            return true;
        }
        if(checkExtendedDirection(RuleList.SOUTH_EAST_STR, boundToID)) {
            return true;
        }
        if(checkExtendedDirection(RuleList.SOUTH_STR, boundToID)) {
            return true;
        }
        if(checkExtendedDirection(RuleList.SOUTH_WEST_STR, boundToID)) {
            return true;
        }
        if(checkExtendedDirection(RuleList.WEST_STR, boundToID)) {
            return true;
        }
        if(checkExtendedDirection(RuleList.NORTH_WEST_STR, boundToID)) {
            return true;
        }

        //I think I need to remove the ID i.e., set it to zero, as there is no population to move to...
        bacteriaMembrane.setBoundToID(0);
        return false;

    }

    private boolean checkExtendedDirection(String direction, float boundToID) {
        if(facingDirection.equals(direction)) {
            Membrane facingMembrane = neighbourTable.get(direction);
            ArrayList<NeighbourMembrane> extendedMembrane = facingMembrane.getNeighbourhood();
            for(int i=0; i<extendedMembrane.size(); i++) {
                NeighbourMembrane neighbour = extendedMembrane.get(i);
                if(neighbour.getRelativePosition().equals(direction)) {
                    ArrayList<Membrane> internalMembranes = neighbour.getMembrane().getMembraneList();
                    for(int n=0; n<internalMembranes.size(); n++) {
                        Membrane tempMembrane = internalMembranes.get(n);
                        //if(tempMembrane.getBoundToID() == boundToID) {
                        if(tempMembrane.getID() == boundToID) {
                            membraneToMoveTo = facingMembrane;
                            mustMove = true;
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        //execute direction change
        System.out.println("Rule21 executes NOW!");
        int invadingPopulation = (Integer)bacteriaMembrane.getMultiSetObject(RuleList.POPULATION).getObject();
        if(mustMove) {

            //1, get the population of the neighbour in front
            int totalPopulation = 0;
            ArrayList<Membrane> population = membraneToMoveTo.getMembraneList();
            for(int i=0; i<population.size(); i++) {
                Membrane tempMembrane = population.get(i);
                totalPopulation += (Integer)tempMembrane.getMultiSetObject(RuleList.POPULATION).getObject();
            }
            if(totalPopulation + invadingPopulation > 400) {
                //move only a portion
                int populationToMove = 400 - totalPopulation;
                int populationToRetain = totalPopulation - populationToMove;
                Membrane newMembrane = new Membrane();
                newMembrane.changeDirection(facingDirection);
                newMembrane.changePopulation(populationToMove);
                newMembrane.setBoundToID(bacteriaMembrane.getBoundToID());
                if(membraneToMoveTo.isEmpty()) {
                    occupiedList.add(membraneToMoveTo);
                }
                membraneToMoveTo.addMembrane(newMembrane);
                bacteriaMembrane.changeDirection(facingDirection);
                bacteriaMembrane.changePopulation(populationToRetain);

            } else {
                //move all of it
                membraneToMoveTo.addMembrane(bacteriaMembrane);
                membrane.removeMembrane(bacteriaMembrane.getID());
                if(membrane.isEmpty()) {
                    occupiedList.remove(membrane);
                }
            }
            //2, calculate how much I can move across
        } else {
            bacteriaMembrane.changeDirection(newDirection);
        }

        return occupiedList;
    }

}
