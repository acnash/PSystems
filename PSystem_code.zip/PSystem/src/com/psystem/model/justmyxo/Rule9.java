/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 *
 * This is reversal. When a cell is a neighbour to another cell (both populated)
 * in addition to trying to invade into that cell, it can actually hit and then
 * cause reversal in this cell and the neighbour population it hit.
 *
 * At the moment this has code that was from the awful correction mode - this needs to be taken
 * out and swapped with real time code.
 *
 * @author Anthony
 */
public class Rule9 extends MyxoRule {

    private Membrane invadingMembrane = null;
    private Membrane neighbourMembrane = null;

    private String newInvadingDirection = null;
    private String newNeighbourDirection = null;
    private Membrane neighbourInternalMembrane = null;

//    private String direction1 = null;
//    private String direction2 = null;
//    private String newDirection1 = null;
//    private String newDirection2 = null;
//    private Membrane membraneBacteria1 = null;
//    private Membrane membraneBacteria2 = null;
//
//    private Membrane neighbour1 = null;
//    private Membrane neighbour2 = null;

    public Rule9(Membrane membrane) {
        this.membrane = membrane;
        this.neighbourhood = membrane.getNeighbourhood();
        super.defineNeighbours();
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        neighbourInternalMembrane.removeMultiSetObject(RuleList.DIRECTION);
        MultiSetObject directionNeighbourObj = new MultiSetObject();
        directionNeighbourObj.setObject(newNeighbourDirection);
        neighbourInternalMembrane.addMultiSetObject(RuleList.DIRECTION, directionNeighbourObj);

        invadingMembrane.removeMultiSetObject(RuleList.DIRECTION);
        MultiSetObject directionInvadingObj = new MultiSetObject();
        directionInvadingObj.setObject(newInvadingDirection);
        invadingMembrane.addMultiSetObject(RuleList.DIRECTION, directionInvadingObj);


        return occupiedList;
    }

    

    /**
     * If there is a collision then there is a great potential to reverse the polarity of the cell. 
     * @return
     */
    @Override
    public double getStochasticValue() {
        return 0.02;
    }



    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        invadingMembrane = membraneOfInterest;
        MultiSetObject directionObject = invadingMembrane.getMultiSetObject(RuleList.DIRECTION);
        String invadingDirection = (String)directionObject.getObject();
        
        if(facingBoundary(invadingDirection)) {
            return false;
        }
        
        this.neighbourMembrane = super.getNeighbourToUse(invadingDirection);
        if(neighbourMembrane == null) {
            return false;
        }
        String opposingDirection = super.reverseDirection(invadingDirection);
        ArrayList<Membrane> internalNeighbours = neighbourMembrane.getMembraneList();
        for(int i=0; i<internalNeighbours.size(); i++) {
            MultiSetObject obj = internalNeighbours.get(i).getMultiSetObject(RuleList.DIRECTION);
            String neighbourDirection = (String)obj.getObject();
            if(neighbourDirection.equals(opposingDirection)) {
                newInvadingDirection = super.reverseDirection(invadingDirection);
                newNeighbourDirection = super.reverseDirection(neighbourDirection);
                neighbourInternalMembrane = internalNeighbours.get(i);
                return true;
            }
            
        }

        return false;
    }

    /**
     * These membranes already exist in the environment we are fighting over.
     * @param membrane1
     * @param membrane2
     */
//    public void setCollidingMembrane(Membrane membrane1, Membrane membrane2) {
//        this.membraneBacteria1 = membrane1;
//        this.membraneBacteria2 = membrane2;
//    }

//    public void assignDirections(String direction1, String direction2) {
//        this.direction1 = direction1;
//        this.direction2 = direction2;

        //get the neighbours for each of the directions

    //first off I need to get all the membranes thst match the above direction
    //they will be inside this enviornment membrane

//    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
        //NOT REQUIRED
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        //the whole population of this particular set of bacteria are returned
        //as they are all about to reverse.
        return invadingPopulation;
    }

}
