/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class Rule31 extends MyxoRule {

    public Rule31(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.8;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;

        if(membrane.isInternalEcoliEmpty() == false) {
            return true;
        }

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        membrane.killEcoli();

        String newDirection = super.reverseDirection(bacteriaMembrane.getDirection());
        bacteriaMembrane.changeDirection(newDirection);

        return occupiedList;
    }

}
