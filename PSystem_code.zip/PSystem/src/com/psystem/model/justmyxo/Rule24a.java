/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;

/**
 * Clambering over the tagged neighbour infront
 *
 * @author Anthony
 */
public class Rule24a extends MyxoRule {

    private int bacteriaToInvade = 0;
    private int bacteriaToRemain = 0;
    private Membrane neighbourToInvade = null;
    private String directionFacing = null;

    public Rule24a(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.05;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;
        bacteriaToInvade = 0;
        bacteriaToRemain = 0;
        directionFacing = null;

        directionFacing = bacteriaMembrane.getDirection();

        if(super.facingBoundary(directionFacing)) {
            return false;
        }

        if(bacteriaMembrane.getBoundToID() == 0) {
            return false;
        }

        neighbourToInvade = super.getNeighbourToUse(directionFacing);
        int neighbourPopulation = 0;
        ArrayList<Membrane> neighbourBacteria = neighbourToInvade.getMembraneList();
        for(int i=0; i<neighbourBacteria.size(); i++) {
            Membrane tempBacteria = neighbourBacteria.get(i);
            neighbourPopulation += tempBacteria.getPopulation();
        }

        if(neighbourPopulation == 400) {
            return false;
        }

        //otherwise find out how many bacteria can invade.
        int bacteriaWantingToInvade = bacteriaMembrane.getPopulation();
        int potentialInvasion = 400-neighbourPopulation;
        if(potentialInvasion >= bacteriaWantingToInvade) {
            bacteriaToInvade = bacteriaWantingToInvade;
            bacteriaToRemain = 0;
        } else {
            bacteriaToRemain = bacteriaWantingToInvade - potentialInvasion;
            bacteriaToInvade = bacteriaWantingToInvade - bacteriaToRemain;
        }

        return true;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        System.out.println("Rule24a is being executed");
        String opposingDirection = super.reverseDirection(directionFacing);
        ArrayList<Membrane> neighbourBacteria = neighbourToInvade.getMembraneList();
        for(int i=0; i<neighbourBacteria.size(); i++) {
            Membrane tempMembrane = neighbourBacteria.get(i);
            if(opposingDirection.equals(tempMembrane.getDirection())) {
                String newBacteriaDirection = opposingDirection;
                String newNeighbourDirection = bacteriaMembrane.getDirection();
                tempMembrane.changeDirection(newNeighbourDirection);
                bacteriaMembrane.changeDirection(newBacteriaDirection);
                return occupiedList;
            }
        }

        if(bacteriaToRemain == 0) {
            membrane.removeMembrane(bacteriaMembrane.getID());
            bacteriaMembrane.setBoundToID(0);
            neighbourToInvade.addMembrane(bacteriaMembrane);
            if(membrane.isEmpty()) {
                occupiedList.remove(membrane);
            }
        } else {
            //set the population of the existing bacteria membrane
            bacteriaMembrane.changePopulation(bacteriaToRemain);
            //make a new membrane
            Membrane invadingMembrane = new Membrane();
            invadingMembrane.setBoundToID(0);
            invadingMembrane.changeDirection(directionFacing);
            invadingMembrane.changePopulation(bacteriaToInvade);
            neighbourToInvade.addMembrane(invadingMembrane);
            
        }
        
        //do i wait for the cell to make connections on its own - this is possible, yet I have
        //the problem of possible merge issues

        return occupiedList;
    }

}
