/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

/**
 *
 * @author Anthony
 */
public class NeighbourMembrane {

    /**
    public static final String NORTH = "n";
    public static final String NORTH_EAST = "ne";
    public static final String EAST = "e";
    public static final String SOUTH_EAST = "se";
    public static final String SOUTH = "s";
    public static final String SOUTH_WEST = "sw";
    public static final String WEST = "w";
    public static final String NORTH_WEST = "nw";
     */

    private Membrane membrane;
    private String relativePosition;

    public NeighbourMembrane(Membrane membrane, String relativePosition) {
        this.membrane = membrane;
        this.relativePosition = relativePosition;
    }

    public void setRelativePosition(String relativePosition) {
        this.relativePosition = relativePosition;
    }

    public void setMembrane(Membrane membrane) {
        this.membrane = membrane;
    }

    public Membrane getMembrane() {
        return membrane;
    }

    public String getRelativePosition() {
        return relativePosition;
    }

}
