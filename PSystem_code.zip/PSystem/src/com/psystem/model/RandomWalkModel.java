/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import com.psystem.model.Rule;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class RandomWalkModel extends RuleModel {

    private ArrayList<Rule> environmentRuleList;
    private ArrayList<Rule> otherRules;

    public RandomWalkModel() {
        environmentRuleList = new ArrayList<Rule>();
        otherRules = new ArrayList<Rule>();
    }

    public ArrayList<Rule> getEnvironmentRuleList() {
        return environmentRuleList;
    }

    public ArrayList<Rule> getOtherRules() {
        return otherRules;
    }

}
