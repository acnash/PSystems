/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.singleswarm;

import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Anthony
 */
public class Rule40 extends MyxoRule {

    private Membrane environmentToUse = null;
    private Membrane membraneToGripTo = null;

    public Rule40(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 10;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        bacteriaMembrane = membraneOfInterest;

        String facingDirection = bacteriaMembrane.getDirection();
        environmentToUse = super.getNeighbourToUse(facingDirection);
        if(environmentToUse.isEmpty()) {
            return false;
        }

        ArrayList<Membrane> myxoBacteria = environmentToUse.getMembraneList();
        Random rand = new Random();
        int randomSelection = rand.nextInt(myxoBacteria.size());
        membraneToGripTo = myxoBacteria.get(randomSelection);

        String directionOfNeighbouringMembrane = membraneToGripTo.getDirection();
        String reversedDirection = super.reverseDirection(directionOfNeighbouringMembrane);
        if(facingDirection.equals(reversedDirection)) {
            //this is a head on collision and it can not grip, it should cause a reversal
            return false;
        }

        if(bacteriaMembrane.getBoundToID() == 0) {
            return true;
        }

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        System.out.println("I am executing");
        float bindToValue = membraneToGripTo.getID();
        bacteriaMembrane.setBoundToID(bindToValue);

        return occupiedList;
    }

}
