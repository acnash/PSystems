/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.singleswarm;

import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import com.psystem.model.NeighbourMembrane;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class Rule41 extends MyxoRule {

    private Membrane neighbourToMoveTo = null;

    public Rule41(Membrane environmentMembrane) {
        super.membrane = environmentMembrane;
        super.defineNeighbours();
    }

    @Override
    public double getStochasticValue() {
        return 0.8;
    }

    @Override
    public void membraneOfInterest(Membrane membraneOfInterest) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule(Membrane membraneOfInterest) {
        super.bacteriaMembrane = membraneOfInterest;

        String bacteriaFacing = bacteriaMembrane.getDirection();
        if(facingBoundary(bacteriaFacing)) {
            return false;
        }

        neighbourToMoveTo = super.getNeighbourToUse(bacteriaFacing);
        if(neighbourToMoveTo.isEmpty()) {
            return true;
        }

        System.out.println("I want to execute rule 41");

        return false;
    }

    @Override
    public int getOffSet(int totalInvasion, int invadingPopulation) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList executeRule(ArrayList<Membrane> occupiedList) throws Exception {
        boolean isTaggedNeighbour = false;

        membrane.removeMembrane(bacteriaMembrane.getID());
        if(membrane.isEmpty()) {
            occupiedList.remove(membrane);
        }
        if(!occupiedList.contains(neighbourToMoveTo)) {
            occupiedList.add(neighbourToMoveTo);
        }
        neighbourToMoveTo.addMembrane(bacteriaMembrane);

        //do {
        lookForTaggedNeighbour(membrane, bacteriaMembrane.getID(), occupiedList);
        //} while(isTaggedNeighbour);

        return occupiedList;
    }

    private ArrayList<Membrane> lookForTaggedNeighbour(Membrane environmentMembrane, float lookupTag, ArrayList<Membrane> occupiedList) {
        ArrayList<NeighbourMembrane> neighbourListArray = environmentMembrane.getNeighbourhood();
        for(int i=0; i<neighbourList.size(); i++) {
            NeighbourMembrane neighbour = neighbourListArray.get(i);
            Membrane envNeighbourMembrane = neighbour.getMembrane();

            ArrayList<Membrane> internalMembrane = envNeighbourMembrane.getMembraneList();
            for(int n=0; n<internalMembrane.size(); n++) {
                Membrane internalBacteriaMembrane = internalMembrane.get(n);
                float taggedID = internalBacteriaMembrane.getBoundToID();
                if(taggedID == lookupTag) {
                    //remove the membrane from the neighbour
                    envNeighbourMembrane.removeMembrane(internalBacteriaMembrane.getID());
                    if(envNeighbourMembrane.isEmpty()) {
                        if(occupiedList.contains(envNeighbourMembrane)) {
                            occupiedList.remove(envNeighbourMembrane);
                        }
                    }
                    //add it into the last env membrane

                    environmentMembrane.addMembrane(internalBacteriaMembrane);
                    if(!occupiedList.contains(environmentMembrane)) {
                        occupiedList.add(environmentMembrane);
                    }
                    occupiedList = lookForTaggedNeighbour(envNeighbourMembrane, taggedID, occupiedList);
                }
            }
        }
        return occupiedList;
    }

}
