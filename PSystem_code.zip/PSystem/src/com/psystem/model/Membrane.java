/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import com.psystem.common.RuleList;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;

/**
 *
 * @author Anthony
 */
public class Membrane {

    private String name = null;

    private float boundToID=0;
    private float id;

//    private boolean multisetHasChanged = false;
//    private boolean internalMembraneHasChanged = false;
//    private boolean ruleListHasChanged = false;

    private ArrayList<Rule> ruleList = new ArrayList<Rule>();
//    private ArrayList<Rule> tempRuleList = new ArrayList<Rule>();
//    private ArrayList<Rule> backTempRuleList = new ArrayList<Rule>();

    private ArrayList<Membrane> internalEcoli = new ArrayList<Membrane>();

    private ArrayList<Membrane> internalMembranes = new ArrayList<Membrane>();
    private ArrayList<Membrane> tempInternalMembranes = new ArrayList<Membrane>();
//    private ArrayList<Membrane> backTempInternalMembranes = new ArrayList<Membrane>();
    //private ArrayList<Membrane> collisionInternalMembranes = new ArrayList<Membrane>();

    private ArrayList<MultiSetObject> multiset;
//    private ArrayList<MultiSetObject> tempMultiset;
//    private ArrayList<MultiSetObject> backTempMultiset;

    private Hashtable<String,MultiSetObject> multisetHashtable = new Hashtable<String,MultiSetObject>();
    private Hashtable<String,MultiSetObject> tempMultiSetHashtable = new Hashtable<String,MultiSetObject>();
//    private Hashtable<String,MultiSetObject> backTempMultiSetHashtable = new Hashtable<String,MultiSetObject>();
//    private Hashtable<String,MultiSetObject> collisionMultiSetHashtable = new Hashtable<String,MultiSetObject>();

    private ArrayList<NeighbourMembrane> neighbourhood = null;
//    private boolean isFirstTime = true;

    private int maxCells = 400;
//    private boolean wasOccupied = false;
//    private boolean wasEmpty = false;

    private Membrane parentMembrane = null;
    private Membrane tempParentMembrane = null;

    public void setParentMembrane(Membrane parentMembrane) {
        this.parentMembrane = parentMembrane;
    }

    /**
     * this must be set to zero if the link is broken...
     * Everything is starting at zero
     * @param boundToID
     */
    public void setBoundToID(float boundToID) {
        this.boundToID = boundToID;
    }

    public float getBoundToID() {
        return boundToID;
    }

    public boolean isEcoliEmpty() {
        return internalEcoli.isEmpty();
    }

    public ArrayList<Membrane> getInternalEcoli() {
        return this.internalEcoli;
    }

//    public boolean isCellOccupied() {
//        return wasOccupied;
//    }
//
//    public boolean isCellEmpty() {
//        return wasEmpty;
//    }
//
//    public void wasCellOccupied() {
//        wasEmpty = false;
//        wasOccupied = true;
//    }
//
//    public void wasCellEmpty() {
//        wasOccupied = false;
//        wasEmpty = true;
//    }

    public Membrane getParentMembrane() {
        return parentMembrane;
    }

    public void setTempParentMembrane(Membrane tempParentMembrane) {
        this.tempParentMembrane = tempParentMembrane;
    }

    public Membrane getTempParentMembrane() {
        return this.tempParentMembrane;
    }

    public synchronized float calculateDensity() {
        int totalPopulation = 0;
        for(int i=0; i<internalMembranes.size(); i++) {
            totalPopulation += (Integer)internalMembranes.get(i).getMultiSetObject(RuleList.POPULATION).getObject();
        }
        
        float blueColorF = (float)totalPopulation/maxCells;
        if(blueColorF > 1) {
            System.out.println("Painting");
            for(int i=0; i<internalMembranes.size(); i++) {
                Membrane mem = internalMembranes.get(i);
                System.out.println(mem.getID());
            }
            //System.out.println("Trying to paint over 400, environment cell: " + getID());
//            System.out.println("Greater than 1 in the colour");
//            System.out.println(Thread.currentThread().getName());
//            System.out.println("Number of Membranes: " + internalMembranes.size());
//            System.out.println("total population: " + totalPopulation);
//            for(int i=0; i<internalMembranes.size(); i++) {
//                System.out.println(internalMembranes.get(i).getMultiSetObject("POPULATION").getObject());
//            }
        }
        return blueColorF;
    }

    public void killEcoli() {
        this.internalEcoli = null;
        this.internalEcoli = new ArrayList<Membrane>();
    }

    public Membrane() {
        Random rand = new Random();
        id = rand.nextFloat();
    }

    public float getID() {
        return id;
    }

    public boolean isEmpty() {
        if(internalMembranes.isEmpty() && internalEcoli.isEmpty()) {
            return true;
        }
        return false;
    }

    public boolean isInternalMembraneEmpty() {
        if(internalMembranes.isEmpty()) {
            return true;
        }
        return false;
    }

    public boolean isInternalEcoliEmpty() {
        if(internalEcoli.isEmpty()) {
            return true;
        }
        return false;
    }

    //******MEMBRANE NEIGHBOURS********//
    //this is only for membranes being treated as an environmental structure
    public ArrayList<NeighbourMembrane> getNeighbourhood() {
        return neighbourhood;
    }

    public void addNeighbours(ArrayList<NeighbourMembrane> neighbourhood) {
        this.neighbourhood = neighbourhood;
    }

    //******INTERNAL MEMBRANES**********

//    public void mergeInternalMembranes() {
//        Hashtable<String, Membrane> condenseTable = new Hashtable<String, Membrane>();
//        for(int i=0; i<this.tempInternalMembranes.size(); i++) {
//            Membrane tempMembrane = tempInternalMembranes.get(i);
//            String direction = (String)tempMembrane.getTempMultiSetObject(RuleList.DIRECTION).getObject();
//            Integer population = (Integer)tempMembrane.getTempMultiSetObject(RuleList.POPULATION).getObject();
//            if(condenseTable.containsKey(direction)) {
//                Membrane updateMembrane = condenseTable.get(direction);
//                Integer existingPopulation = (Integer)updateMembrane.getTempMultiSetObject(RuleList.POPULATION).getObject();
//                existingPopulation += population;
//                MultiSetObject newPopObject = new MultiSetObject();
//                newPopObject.setObject(existingPopulation);
//                updateMembrane.addTempMultiSetObject(RuleList.POPULATION, newPopObject);
//                condenseTable.put(direction,updateMembrane);
//            } else {
//                condenseTable.put(direction, tempMembrane);
//            }
//        }
//        ArrayList<Membrane> newList = new ArrayList<Membrane>(condenseTable.size());
//        Enumeration tableEnum = condenseTable.elements();
//        while(tableEnum.hasMoreElements()) {
//            newList.add((Membrane)tableEnum.nextElement());
//        }
//        tempInternalMembranes = null;
//        tempInternalMembranes = newList;
//    }

    public void mergeInternalMembranes() {
        Hashtable<String, Membrane> condenseTable = new Hashtable<String, Membrane>();
        for(int i=0; i<this.internalMembranes.size(); i++) {
//            String direction = null;
            Membrane membrane = internalMembranes.get(i);
//            try {
//                MultiSetObject dirObj = membrane.getMultiSetObject(RuleList.DIRECTION);
//                direction = (String)dirObj.getObject();
            String direction = membrane.getDirection();
            //direction = (String)membrane.getMultiSetObject(RuleList.DIRECTION).getObject();
//            } catch(ClassCastException exp ) {
//                exp.printStackTrace();
//            }
            //Integer population = (Integer)membrane.getMultiSetObject(RuleList.POPULATION).getObject();
            int population = membrane.getPopulation();
//            String motility = (String)membrane.getMultiSetObject(RuleList.MOTILITY).getObject();
         
            if(condenseTable.containsKey(direction)) {

                Membrane updateMembrane = condenseTable.get(direction);
                if(updateMembrane.getBoundToID() == 0) {
                    updateMembrane.setBoundToID(membrane.getBoundToID());                      
                }
                Integer existingPopulation = (Integer)updateMembrane.getMultiSetObject(RuleList.POPULATION).getObject();
//                String existingMotility = (String)updateMembrane.getMultiSetObject(RuleList.MOTILITY).getObject();

                //put in the new population level
                existingPopulation += population;
                MultiSetObject newPopObject = new MultiSetObject();
                newPopObject.setObject(existingPopulation);
                updateMembrane.removeMultiSetObject(RuleList.POPULATION);
                updateMembrane.addMultiSetObject(RuleList.POPULATION, newPopObject);

                //put in the new motility
//                String newMotility = "ERROR!";
//                if(!existingMotility.equals(motility)) {
//                    newMotility = calculateMergedMotility(existingPopulation);
//                    MultiSetObject newMotilityObj = new MultiSetObject();
//                    updateMembrane.removeMultiSetObject(RuleList.MOTILITY);
//                    newMotilityObj.setObject(newMotility);
//                    updateMembrane.addMultiSetObject(RuleList.MOTILITY, newMotilityObj);
//                }
                
                condenseTable.put(direction,updateMembrane);
            } else {
                condenseTable.put(direction, membrane);
            }
        }
        ArrayList<Membrane> newList = new ArrayList<Membrane>(condenseTable.size());
        Enumeration tableEnum = condenseTable.elements();
        while(tableEnum.hasMoreElements()) {
            newList.add((Membrane)tableEnum.nextElement());
        }
        internalMembranes = null;
        internalMembranes = newList;
    }

//    private String calculateMergedMotility(int totalConcentration) {
//        String motility = null;
//        //value for amotility to s motility
//        double unbind = 0.4;
//        double bind = 0.05;
//        double bound = 0.2;
//        double vMax = 1;
//        double kM = (unbind + bound)/(bind);
//        double aToS = (vMax*(totalConcentration))/(kM + totalConcentration);
//
//        //value for smotility to a motility
//        double sToA = 1/(1+Math.exp((totalConcentration/2)-10));
//        sToA += aToS;
//
//        Random rand = new Random();
//        double randomRoll = rand.nextDouble();
//
//        if(randomRoll <= aToS) {
//            motility = RuleList.S_MOTILITY;
//        } else {
//            motility = RuleList.A_MOTILITY;
//        }
//
//        return motility;
//    }

    public void updateInternalMembranes(ArrayList<Membrane> membraneList) {
        //internalMembranes = membraneList;
        //for(int i=0; i<internalMembranes.size(); i++) {
        //    internalMembranes.set(i, membraneList.get(i));
        //}
        for(int i=0; i<internalMembranes.size(); i++) {
            internalMembranes.remove(i);
        }
        internalMembranes.trimToSize();
        for(int i=0; i<membraneList.size(); i++) {
            internalMembranes.add(membraneList.get(i));
        }
    }

    //----------------------------------------------------------------------

    /*public void addCollisionMembrane(Membrane membrane) {
        collisionInternalMembranes.add(membrane);
    }

    public Membrane getCollisionMembrane(int index) {
        if(collisionInternalMembranes.isEmpty()) {
            return null;
        }
        return collisionInternalMembranes.get(index);
    }

    public ArrayList<Membrane> getCollisionMembraneList() {
        return collisionInternalMembranes;
    }

    public void removeCollisionMembrane(float id) {
        for(int i=0; i<collisionInternalMembranes.size(); i++) {
            float tempId = collisionInternalMembranes.get(i).getID();
            if(tempId == id) {
                collisionInternalMembranes.remove(i);
                break;
            }
        }
    }

    public void removeCollisionMembrane(int index) {
        if (collisionInternalMembranes != null) {
            collisionInternalMembranes.remove(index);
        }
    }

    public Hashtable<String,MultiSetObject> getCollisionMultiSetObjectList() {
        return collisionMultiSetHashtable;
    }

    public MultiSetObject getCollisionMultiSetObject(String objectName) {
        return (MultiSetObject)collisionMultiSetHashtable.get(objectName);
    }

    public void addCollisionMultiSetObject(String objectName, MultiSetObject multiSetObject) {
        if(objectName.equals("POPULATION")) {
            //check the population is not excessive
            Integer pop = (Integer)multiSetObject.getObject();
        }
        collisionMultiSetHashtable.put(objectName, multiSetObject);
    }

    public void removeCollisionMultiSetObjct(String objectName) {
        collisionMultiSetHashtable.remove(objectName);
    }
    //----------------------------------------------------------------------
*/
    public void addMembraneSetup(Membrane membrane) {
        internalMembranes.add(membrane);
        //i think this is needed initially
        //addTempMembrane(membrane);
  //      addCollisionMembrane(membrane);
    }

    public void addMembrane(Membrane membrane) {
        internalMembranes.add(membrane);
    }

    public void addEcoli(Membrane membrane) {
        internalEcoli.add(membrane);
    }

//    public void addTempMembrane(Membrane membrane) {
//        tempInternalMembranes.add(membrane);
//
//        int totalPop = 0;
//        for(int i=0; i<tempInternalMembranes.size(); i++) {
//            Membrane mem = tempInternalMembranes.get(i);
//            totalPop += (Integer)mem.getTempMultiSetObject("POPULATION").getObject();
//        }
//        if(totalPop > 400) {
//            System.out.println("Why?");
//        }
//
//    }
    
    public ArrayList<Membrane> getMembraneList() {
        return internalMembranes;
    }
//
//    public ArrayList<Membrane> getTempMembraneList() {
//        return tempInternalMembranes;
//    }

    public Hashtable<String,MultiSetObject> getMultiSetList() {
        return this.multisetHashtable;
    }
    
    public Membrane getMembrane(int index) {
        if(internalMembranes.isEmpty()) {
            return null;
        }
        return internalMembranes.get(index);
    }
//
//    public Membrane getTempMembrane(int index) {
//        if(tempInternalMembranes.isEmpty()) {
//            return null;
//        }
//        return tempInternalMembranes.get(index);
//    }
    
    //it must be null, as we are using the position in the array as the index
    public void removeMembrane(int index) {
        if (internalMembranes != null) {
            //internalMembranes.set(index, null);
            internalMembranes.remove(index);
        }
    }

    public void removeMembrane(float id) {
        for(int i=0; i<internalMembranes.size(); i++) {
            float tempId = internalMembranes.get(i).getID();
            if(tempId == id) {
                internalMembranes.remove(i);
                break;
            }
        }
    }
//
//    public void removeTempMembrane(float id) {
//        for(int i=0; i<tempInternalMembranes.size(); i++) {
//            float tempId = tempInternalMembranes.get(i).getID();
//            if(tempId == id) {
//                tempInternalMembranes.remove(i);
//                break;
//            }
//        }
//    }
//
//    //it must be null, as we are using the position in the array as the index
//    public void removeTempMembrane(int index) {
//        if (tempInternalMembranes != null) {
//            tempInternalMembranes.remove(index);
////            tempInternalMembranes.set(index, null);
//        }
//    }

    //******MULTISET OBJECTS************

    //I may not use an array list idea
    //***NEEDS TO BE SETUP UP FOR THE TIME DELAY
    public void addMultiSetObject(MultiSetObject multiSetObject) {
        multiset.add(multiSetObject);
    }
//
//    public Hashtable<String,MultiSetObject> getTempMultiSetObjectList() {
//        return tempMultiSetHashtable;
//    }
    
    public ArrayList<MultiSetObject> getMultiSetObjectList() {
        return multiset;
    }

    public MultiSetObject getMultiSetObject(String objectName) {
        return (MultiSetObject)multisetHashtable.get(objectName);
    }
//
//    public MultiSetObject getTempMultiSetObject(String objectName) {
//        return (MultiSetObject)tempMultiSetHashtable.get(objectName);
//    }

    public void addMultiSetObject(String objectName, MultiSetObject multiSetObject) {
        if(objectName.equals("POPULATION")) {
            //check the population is not excessive
            Integer pop = (Integer)multiSetObject.getObject();
//            if(pop > 400) {
//                System.out.println("Seriously! Why?");
//            }
        }
        multisetHashtable.put(objectName, multiSetObject);
    }
    
    public void removeMultiSetObject(String objectName) {
        multisetHashtable.remove(objectName);
    }
//
//    public void addTempMultiSetObject(String objectName, MultiSetObject multiSetObject) {
//        if(objectName.equals("POPULATION")) {
//            //check the population is not excessive
//            Integer pop = (Integer)multiSetObject.getObject();
////            if(pop > 400) {
////                System.out.println("Seriously! Why?");
////            }
//        }
//        tempMultiSetHashtable.put(objectName, multiSetObject);
//    }
//
//    public void removeTempMultiSetObjct(String objectName) {
//        tempMultiSetHashtable.remove(objectName);
//    }
//
    //******RULES***********************

    public void addRule(Rule rule) {
        ruleList.add(rule);
    }

    public void addRuleList(ArrayList<Rule> ruleList) {
        for(int i=0; i<ruleList.size(); i++) {
            Rule rule = ((Rule)ruleList.get(i));
            this.addRule(rule);
        }
    }

    public ArrayList<Rule> getRuleList() {
        return this.ruleList;
    }

    public Rule getRule(int index) {
        return ruleList.get(index);
    }

    public void executeRules(ArrayList<Membrane> occupiedList) throws Exception {
        for(int i=0; i<ruleList.size(); i++) {
                ruleList.get(i).executeRule(occupiedList);
        }
        for(int i=0; i<internalMembranes.size(); i++) {
            internalMembranes.get(i).executeRules(occupiedList);
        }
    }
//
//    public void internalMembraneHasChanged() {
//        this.internalMembraneHasChanged = true;
//    }
//
//    public void ruleListHasChanged() {
//        this.ruleListHasChanged = true;
//    }
//
//    public void multisetHasChanged() {
//        this.multisetHasChanged = true;
//    }

    //this doesn't work
    //I have a problem - the temp membranes are never being empties
    public void updateMembrane() throws Exception {
        //should I be calling update on the non tempInternal Membranes?!?!?

        //for(int i=0; i<tempInternalMembranes.size(); i++) {
        for(int i=0; i<internalMembranes.size(); i++) {
            //tempInternalMembranes.get(i).updateMembrane();
            internalMembranes.get(i).updateMembrane();          //VERY WORRIED ABOUT THIS
        }
//        if(multisetHasChanged) {
            //multisetHashtable = tempMultiSetHashtable;
            
            Enumeration keyEnum = tempMultiSetHashtable.keys();
            while(keyEnum.hasMoreElements()) {

                String key = (String)keyEnum.nextElement();
                MultiSetObject object = (MultiSetObject)tempMultiSetHashtable.get(key);
                multisetHashtable.put(key, object);
            }
             
//            backTempMultiSetHashtable = tempMultiSetHashtable;
//            multisetHashtable = tempMultiSetHashtable;
//            tempMultiSetHashtable = backTempMultiSetHashtable;

//            backTempMultiset = multiset;
//            multiset = tempMultiset;
//            tempMultiset = backTempMultiset;
//            multisetHasChanged = false;
//        }

//        if(ruleListHasChanged) {
//            backTempRuleList = ruleList;
//            ruleList = tempRuleList;
//            tempRuleList = backTempRuleList;
//            ruleListHasChanged = false;
//        }

//        if(internalMembraneHasChanged) {
            //internalMembranes = tempInternalMembranes;
           
            ArrayList<Membrane> swapList = new ArrayList<Membrane>();
            for(int i=0; i<swapList.size(); i++) {
                swapList.add(tempInternalMembranes.get(i));
            }
            for(int i=0; i<swapList.size(); i++) {
                internalMembranes.set(i, swapList.get(i));
            }
//            backTempInternalMembranes = tempInternalMembranes;
//            internalMembranes = tempInternalMembranes;
//            tempInternalMembranes = backTempInternalMembranes;

//            internalMembraneHasChanged = false;
//        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setInternalMembraneList(ArrayList<Membrane> list) {
        this.internalMembranes = list;
    }
//
//    public void setTempInternalMembraneList(ArrayList<Membrane> list) {
//        this.tempInternalMembranes = list;
//    }
    public String getDirection() {
        return (String)this.getMultiSetObject(RuleList.DIRECTION).getObject();
    }

    public int getPopulation() {
        return (Integer)this.getMultiSetObject(RuleList.POPULATION).getObject();
    }

    public boolean hasSlime() {
        MultiSetObject slimeObject = this.getMultiSetObject(RuleList.SLIME);
        if(slimeObject == null) {
            return false;
        }
        return true;
    }

    public void leaveSlime() {
        MultiSetObject slimeObject = new MultiSetObject();
        slimeObject.setObject(RuleList.SLIME);
        this.addMultiSetObject(RuleList.SLIME, slimeObject);
    }

    public void changeDirection(String newDirection) {
        MultiSetObject currentDirection = this.getMultiSetObject(RuleList.DIRECTION);
        if(currentDirection != null) {
            this.removeMultiSetObject(RuleList.DIRECTION);
        }
        MultiSetObject newDirectionObject = new MultiSetObject();
        newDirectionObject.setObject(newDirection);
        this.addMultiSetObject(RuleList.DIRECTION, newDirectionObject);
    }

    public void changePopulation(int population) {
        MultiSetObject currentPopulation = this.getMultiSetObject(RuleList.POPULATION);
        if(currentPopulation != null) {
            this.removeMultiSetObject(RuleList.POPULATION);
        }
        MultiSetObject newPopulation = new MultiSetObject();
        newPopulation.setObject(population);
        this.addMultiSetObject(RuleList.POPULATION, newPopulation);
    }

    private double positionValue = 0;

    public void updatePositionValue() {
        int currentPopulation = 0;
        if(!this.isEmpty()) {
            for(int i=0; i<internalMembranes.size(); i++) {
                Membrane tempMembrane = internalMembranes.get(i);
                currentPopulation += tempMembrane.getPopulation();
            }
            positionValue += (double)currentPopulation/400;
        }
        if(!this.isEcoliEmpty()) {
            for(int i=0; i<internalEcoli.size(); i++) {
                Membrane tempMembrane = internalEcoli.get(i);
                currentPopulation += tempMembrane.getPopulation();
            }
            positionValue += (double)currentPopulation/400;
        }
    }

    public double getPositionValue() {
        return positionValue;
    }

}
