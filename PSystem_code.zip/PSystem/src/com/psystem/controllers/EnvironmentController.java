/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.controllers;

import com.psystem.common.RuleList;
import com.psystem.common.UIUtilities;
import com.psystem.entities.EnvironmentObject;
import com.psystem.entities.InitialData;
import com.psystem.entities.JustMyxo;
import com.psystem.model.EnvironmentModel;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.NeighbourMembrane;
import com.psystem.model.RandomMovementRule;
import com.psystem.model.Rule;
import com.psystem.model.justmyxo.*;
import com.psystem.model.singleswarm.Rule40;
import com.psystem.model.singleswarm.Rule41;
import com.psystem.ui.EnvironmentWindow;
import com.psystem.ui.MyxoPaintPanel;
import com.psystem.ui.PaintPanel;
import com.psystem.ui.RandomMovementPaintPanel;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;

/**
 *
 * @author Anthony
 */
public class EnvironmentController {

    public static final int MULTIENVIRONMENT = 0;
    public static final int MYXO_PETRI = 1;

    private EnvironmentModel environmentModel;
    private EnvironmentObject eObject;
    private EnvironmentWindow frame;
    private EnvironmentPaintThread thread;
    private PaintPanel paintPanel;
    //private Hashtable<Membrane, Integer> occupiedTable = new Hashtable<Membrane, Integer>();
    private ArrayList<Membrane> occupiedList = new ArrayList<Membrane>();
    //private JFrame frame;

    private int width;
    private int height;

    //private boolean displayGUI;

    public EnvironmentController(boolean displayGUI) {
        if(displayGUI) {
            frame = new EnvironmentWindow();
        }
        //frame.setBackground(Color.BLACK);
    }
    public EnvironmentController(int dimension, int population, boolean displayGUI) {
        
        environmentModel = new EnvironmentModel(dimension, dimension, dimension*dimension);
        this.width = dimension;
        this.height = dimension;
        if(displayGUI) {
            frame = new EnvironmentWindow();
            frame.setSize(dimension, dimension);
            Dimension position = UIUtilities.getCenter(frame, UIUtilities.HALF);
            frame.setLocation(((int)position.getWidth()), ((int)position.getHeight()));
            frame.setTitle("Myxo Colony");
        }
        generateMyxoEnvironmentStructure();
        setupMyxoEnvironmentColony(population);
        if(displayGUI) {
            paintPanel = new MyxoPaintPanel();
            paintPanel.setSize(width, height);
            frame.setVisible(true);
            frame.addPaintPanel(paintPanel);
            thread = new EnvironmentPaintThread(environmentModel, frame);
        } else {
            thread = new EnvironmentPaintThread(environmentModel, null);
        }
        //thread.initiliase(displayGUI);
    }

    public void generateNewEnvironment(EnvironmentObject eObject) {
        this.eObject = eObject;
        this.width = this.eObject.getWidth();
        this.height = this.eObject.getHeight();
        environmentModel = new EnvironmentModel(width, height, width*height);

        frame.setSize(width*5, height*5);
        Dimension position = UIUtilities.getCenter(frame, UIUtilities.HALF);
        frame.setLocation(((int)position.getWidth()), ((int)position.getHeight()));

        frame.setTitle(this.eObject.getTitle());

        switch(this.eObject.getEnvironmentType()) {
            case EnvironmentController.MULTIENVIRONMENT: 
                generateMultiEnvironmentStructure();
                break;
            case EnvironmentController.MYXO_PETRI:
                generateMyxoEnvironmentStructure();
                break;
            default: System.out.println("Unknown environment to set up");
        }

        frame.setVisible(true);
    }

    /**
     *
     */
    private void generateMyxoEnvironmentStructure() {
        //you add the structure of the environment membranes to the environmentmodel object
        //from within this method
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {
                //construct a membrane
                Membrane membrane = new Membrane();
                environmentModel.addEnvironmentMembrane(membrane, x, y);
            }
        }
        //generate the neighbourhood associations
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {
                ArrayList<NeighbourMembrane>neighbours = getMooreNeighbours(x,y,EnvironmentObject.CLOSED_BOUNDS);
                Membrane membrane = environmentModel.getEnvironmentMembrane(x, y);
                membrane.addNeighbours(neighbours);
            }
        }
    }

    /**
     *
     */
    private void generateMultiEnvironmentStructure() {
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {
                //i need the diffusion rates
                //i need the neighbourhoods
                Hashtable<String,Double> directionProbabilities = new Hashtable<String,Double>();
                directionProbabilities.put(RuleList.getDirection(RuleList.NORTH),new Double(eObject.getNProbability()));
                directionProbabilities.put(RuleList.getDirection(RuleList.SOUTH),new Double(eObject.getSProbability()));
                directionProbabilities.put(RuleList.getDirection(RuleList.EAST),new Double(eObject.getEProbability()));
                directionProbabilities.put(RuleList.getDirection(RuleList.WEST),new Double(eObject.getWProbability()));
                if(eObject.getNeighbourhood() == EnvironmentObject.MOORE_NEIGHBOURHOOD) {
                    directionProbabilities.put(RuleList.getDirection(RuleList.NORTH_WEST),new Double(eObject.getNWProbability()));
                    directionProbabilities.put(RuleList.getDirection(RuleList.NORTH_EAST),new Double(eObject.getNEProbability()));
                    directionProbabilities.put(RuleList.getDirection(RuleList.SOUTH_EAST),new Double(eObject.getSEProbability()));
                    directionProbabilities.put(RuleList.getDirection(RuleList.SOUTH_WEST),new Double(eObject.getSWProbability()));
                }
                //the random rules now needs to populate these membranes with rules
                //and diffusion values as taken down from the UI
                Membrane membrane = new Membrane();
                //these are the multienvironment membrane, so I must make and insert the rules here
                Rule randomMovementRule = new RandomMovementRule(membrane);
                //taken out rule neighbour define
                randomMovementRule.setDiffusionProbabilities(directionProbabilities);
                membrane.addRule(randomMovementRule);
                environmentModel.addEnvironmentMembrane(membrane, x, y);
            }
        }
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {

                //get this membrane's neighbours and add it to the rule
                ArrayList<NeighbourMembrane> neighbours = null;
                if(eObject.getNeighbourhood() == EnvironmentObject.MOORE_NEIGHBOURHOOD) {
                    //neighbours = getMooreNeighbours(x,y,eObject.getEnvironmentType());
                    neighbours = getMooreNeighbours(x,y,eObject.getBounds());
                } else {
                    //neighbours = getNeummanNeighbours(x,y,eObject.getEnvironmentType());
                    neighbours = getNeummanNeighbours(x,y,eObject.getBounds());
                }
                Membrane membrane = environmentModel.getEnvironmentMembrane(x, y);
                membrane.addNeighbours(neighbours);
                Rule randomMovementRule = membrane.getRule(0);
                randomMovementRule.defineNeighbours();
                
            }
        }
    }


    /**
     *
     * I am trying to collect a neighbourhood when one hasn't been laid down yet!!!!
     *
     * @param x
     * @param y
     * @return
     */
    private ArrayList<NeighbourMembrane> getMooreNeighbours(int x, int y, int environmentType) {
        //I must take into account the boundary conditions
        //what happens in the cases of
        //1. Closed
        //2. Open
        //3. Infinity
        ArrayList<NeighbourMembrane> neighbours = new ArrayList<NeighbourMembrane>();

        switch(environmentType) {
            case EnvironmentObject.CLOSED_BOUNDS:
                //consider the case where it is not on ANY boundaries
                //if(x != 0 && x != width && y != 0 && y != width) {
                int index = (x*width)+y;
                if( (index >= width) && (index % width != 0) && ((index+1) % width != 0 ) && ( index < (width*height)-width) ) {
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),RuleList.getDirection(RuleList.NORTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),RuleList.getDirection(RuleList.NORTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),RuleList.getDirection(RuleList.NORTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),RuleList.getDirection(RuleList.EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),RuleList.getDirection(RuleList.SOUTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),RuleList.getDirection(RuleList.SOUTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),RuleList.getDirection(RuleList.SOUTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),RuleList.getDirection(RuleList.WEST)));
                }

                //consider the case where the main cell is in a corner
                //topleft - correct
                if(x==0 && y==0) {
//                    System.out.println("index:= " + index + " top left corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),RuleList.getDirection(RuleList.EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),RuleList.getDirection(RuleList.SOUTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),RuleList.getDirection(RuleList.SOUTH)));

                }
                //top right - CORRECT WRONG
                //BOTTOM LEFT
                if((x==0) && (y==(height-1))) {
//                    System.out.println("index:= " + index + " top right corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),RuleList.getDirection(RuleList.NORTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),RuleList.getDirection(RuleList.NORTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),RuleList.getDirection(RuleList.EAST)));
                }
                //bottom right
                if(x==(width-1) && y==(height-1)) {
//                    System.out.println("index:= " + index + " bottom right corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),RuleList.getDirection(RuleList.NORTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),RuleList.getDirection(RuleList.NORTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),RuleList.getDirection(RuleList.WEST)));
                }
                //botton left
                //TOP RIGHT
                if(x==(width-1) && y==0) {
//                    System.out.println("index:= " + index + " bottom left corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),RuleList.getDirection(RuleList.SOUTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),RuleList.getDirection(RuleList.SOUTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),RuleList.getDirection(RuleList.WEST)));
                }


                //consider the case where the main cell is on an edge, but not a corner
                //LEFT SIDE
                //TOP SIDE
                if((y == 0 && x != 0) && (y == 0 && x != (width-1))) {
//                    System.out.println("index:= " + index + " left side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),RuleList.getDirection(RuleList.SOUTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),RuleList.getDirection(RuleList.SOUTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),RuleList.getDirection(RuleList.EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),RuleList.getDirection(RuleList.SOUTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),RuleList.getDirection(RuleList.WEST)));
                }
                //RIGHT SIDE
                //BOTTOM SIDE
                if((y == (height-1) && x != 0) && (y == (height-1) && x != (width-1))) {
//                    System.out.println("index:= " + index + " right side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),RuleList.getDirection(RuleList.NORTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),RuleList.getDirection(RuleList.NORTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),RuleList.getDirection(RuleList.WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),RuleList.getDirection(RuleList.NORTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),RuleList.getDirection(RuleList.EAST)));
                }
                //TOP SIDE
                //LEFT SIDE
                if((x == 0 && y != 0) && (x == 0 && y != (height-1))) {
//                    System.out.println("index:= " + index + " top side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),RuleList.getDirection(RuleList.NORTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),RuleList.getDirection(RuleList.NORTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),RuleList.getDirection(RuleList.EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),RuleList.getDirection(RuleList.SOUTH_EAST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),RuleList.getDirection(RuleList.SOUTH)));
                }
                //BOTTOM SIDE
                //RIGHT SIDE
                if((x == (width-1) && y != 0) && ( x == (width-1) && y != (height-1))) {
//                    System.out.println("index:= " + index + " bottom side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),RuleList.getDirection(RuleList.NORTH)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),RuleList.getDirection(RuleList.NORTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),RuleList.getDirection(RuleList.WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),RuleList.getDirection(RuleList.SOUTH_WEST)));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),RuleList.getDirection(RuleList.SOUTH)));
                }
                break;
            case EnvironmentObject.OPEN_BOUNDS:
                System.out.println("No rules for open bounds yet");
                break;
            case EnvironmentObject.INFINITE_BOUNDS:
                System.out.println("No rules for infinite bounds yet");
                break;
        }

        return neighbours;
    }

    /**
     * Don't implement straight away
     * @param x
     * @param y
     * @return
     */
    private ArrayList<NeighbourMembrane> getNeummanNeighbours(int x, int y, int environmentType) {
        return null;
    }

    public void loadModel(int ruleToImplement, InitialData initialData) throws Exception {
        //this should be a little like a factory class generator
        //RuleModel model = null;
        switch(ruleToImplement) {
            case RuleList.RANDOM_WALK:
                paintPanel = new RandomMovementPaintPanel();
                paintPanel.setSize(width*5, height*5);
                //put in initial particle to move around randomly
                //the particle membrane has no rules
                Membrane particleMembrane = new Membrane();
                //we add the particle to the center of the environment
                environmentModel.getEnvironmentMembrane(width/2, height/2).addMembraneSetup(particleMembrane);
                
                //in other models you might consider making initial population dispersion here
                break;
            case RuleList.JUST_MYXO:
                paintPanel = new MyxoPaintPanel();
                paintPanel.setSize(width*5, height*5);
                //
                //do initialization here for myxo bacterium..... it should be a combo box in rule panel
                //yet the rule panel needs to be created
                int numberOfCells = Integer.parseInt(initialData.getMetaData(JustMyxo.NUMBER_OF_CELLS));
                //int initialConfiguration = Integer.parseInt(initialData.getMetaData(JustMyxo.INITIAL_CONFIGURATION));
                //setupMyxoEnvironment(numberOfCells,initialConfiguration,paintPanel);
                //setupMyxoEnvironmentColony(numberOfCells);
                //setupTestColony(numberOfCells);   //<---- this works fine
                setupMyxoEnvironmentCircularColony(numberOfCells); //  <------what is this???? I don't think this caters for a variation in cell numbers.
                break;
            case RuleList.JUST_ECOLI:
                System.out.println("Just Ecoli rules are not yet implemented");
                break;
            case RuleList.MYXO_PRED_PREY:
                System.out.println("Pred Prey rules are not yet implemented");
                break;
            default: System.out.println("Unknown rule set");
                throw new Exception("Crazy! Unknown rules.");
        }
        //the loadModel method should now call for initiliase of the painting
        frame.addPaintPanel(paintPanel);
        thread = new EnvironmentPaintThread(environmentModel, frame);
        thread.initiliase(true);
    }

    private void setupMyxoEnvironmentCircularColony(int numberOfCells) {
        int environmentSize = width*height;

        int centre = environmentSize/2;
        centre = centre + (width/2);

        Random rand = new Random();

        //int possiblePopsize = 799;
        
        for(int position=0; position<environmentSize; position++) {
            int randValue = rand.nextInt(numberOfCells)+1;
            if(position == centre-(width*11) || position == centre-(width*10)) {
                makeNewMembrane(RuleList.WEST_STR, position, randValue);
                continue;
            }
            if((position <= centre-(width*9) &&  position >= centre-(width*9)-1) || (position <= centre-(width*8) && position >= centre-(width*8)-1)) {
                makeNewMembrane(RuleList.WEST_STR, position, randValue);
                continue;
            }
            if((position <= centre-(width*7) &&  position >= centre-(width*7)-2) || (position <= centre-(width*6) && position >= centre-(width*6)-2)) {
                makeNewMembrane(RuleList.NORTH_WEST_STR, position, randValue);
                continue;
            }
            if((position <= centre-(width*5) &&  position >= centre-(width*5)-3) || (position <= centre-(width*4) && position >= centre-(width*4)-3)) {
                makeNewMembrane(RuleList.NORTH_WEST_STR, position, randValue);
                continue;
            }
            if((position <= centre-(width*3) &&  position >= centre-(width*3)-4) || (position <= centre-(width*2) && position >= centre-(width*2)-4)) {
                makeNewMembrane(RuleList.NORTH_STR, position, randValue);
                continue;
            }
            if((position <= centre-(width*1) &&  position >= centre-(width*1)-5) || (position <= centre-(width*0) && position >= centre-(width*0)-5)) {
                makeNewMembrane(RuleList.NORTH_STR, position, randValue);
                continue;
            }

            //finished all of the upper left hand side
            if(position == centre+(width*11) || position == centre+(width*10)) {
                makeNewMembrane(RuleList.EAST_STR, position, randValue);
                continue;
            }
            if((position <= centre+(width*9) &&  position >= centre+(width*9)-1) || (position <= centre+(width*8) && position >= centre+(width*8)-1)) {
                makeNewMembrane(RuleList.EAST_STR, position, randValue);
                continue;
            }
            if((position <= centre+(width*7) &&  position >= centre+(width*7)-2) || (position <= centre+(width*6) && position >= centre+(width*6)-2)) {
                makeNewMembrane(RuleList.NORTH_EAST_STR, position, randValue);
                continue;
            }
            if((position <= centre+(width*5) &&  position >= centre+(width*5)-3) || (position <= centre+(width*4) && position >= centre+(width*4)-3)) {
                makeNewMembrane(RuleList.NORTH_EAST_STR, position, randValue);
                continue;
            }
            if((position <= centre+(width*3) &&  position >= centre+(width*3)-4) || (position <= centre+(width*2) && position >= centre+(width*2)-4)) {
                makeNewMembrane(RuleList.NORTH_STR, position, randValue);
                continue;
            }
            if((position <= centre+(width*1) &&  position >= centre+(width*1)-5) || (position <= centre+(width*0) && position >= centre+(width*0)-5)) {
                makeNewMembrane(RuleList.NORTH_STR, position, randValue);
                continue;
            }
            //finished all of the lower left


            
            if((position >= centre+(width*1) &&  position <= centre+(width*1)+5) || (position >= centre+(width*0) && position <= centre+(width*0)+5)) {
                makeNewMembrane(RuleList.SOUTH_STR, position, randValue);
                continue;
            }
            if((position >= centre+(width*2) &&  position <= centre+(width*2)+4) || (position >= centre+(width*3) && position <= centre+(width*3)+4)) {
                makeNewMembrane(RuleList.SOUTH_STR, position, randValue);
                continue;
            }
            if((position >= centre+(width*4) &&  position <= centre+(width*4)+3) || (position >= centre+(width*5) && position <= centre+(width*5)+3)) {
                makeNewMembrane(RuleList.SOUTH_EAST_STR, position, randValue);
                continue;
            }
            if((position >= centre+(width*6) &&  position <= centre+(width*6)+2) || (position >= centre+(width*7) && position <= centre+(width*7)+2)) {
                makeNewMembrane(RuleList.SOUTH_EAST_STR, position, randValue);
                continue;
            }
            if((position >= centre+(width*8) &&  position <= centre+(width*8)+1) || (position >= centre+(width*9) && position <= centre+(width*9)+1)) {
                makeNewMembrane(RuleList.EAST_STR, position, randValue);
                continue;
            }
             if((position >= centre+(width*10) &&  position <= centre+(width*10)+1) || (position >= centre+(width*11) && position <= centre+(width*11)+1)) {
                makeNewMembrane(RuleList.EAST_STR, position, randValue);
                continue;
            }
           
//           -----------

            if((position >= centre-(width*1) &&  position <= centre-(width*1)+5) || (position >= centre-(width*0) && position <= centre-(width*0)+5)) {
                makeNewMembrane(RuleList.SOUTH_STR, position, randValue);
                continue;
            }
            if((position >= centre-(width*2) &&  position <= centre-(width*2)+4) || (position >= centre-(width*3) && position <= centre-(width*3)+4)) {
                makeNewMembrane(RuleList.SOUTH_STR, position, randValue);
                continue;
            }
            if((position >= centre-(width*4) &&  position <= centre-(width*4)+3) || (position >= centre-(width*5) && position <= centre-(width*5)+3)) {
                makeNewMembrane(RuleList.SOUTH_WEST_STR, position, randValue);
                continue;
            }
            if((position >= centre-(width*6) &&  position <= centre-(width*6)+2) || (position >= centre-(width*7) && position <= centre-(width*7)+2)) {
                makeNewMembrane(RuleList.SOUTH_WEST_STR, position, randValue);
                continue;
            }
            if((position >= centre-(width*8) &&  position <= centre-(width*8)+1) || (position >= centre-(width*9) && position <= centre-(width*9)+1)) {
                makeNewMembrane(RuleList.WEST_STR, position, randValue);
                continue;
            }
            if((position >= centre-(width*10) &&  position <= centre-(width*10)+1) || (position >= centre-(width*11) && position <= centre-(width*11)+1)) {
                makeNewMembrane(RuleList.WEST_STR, position, randValue);
                continue;
            }
        }

        for(int i=0; i<environmentSize; i++) {
            defineMyxoRules(environmentModel.getEnvironmentMembrane(i));
            environmentModel.getEnvironmentMembrane(i).setName("Environment Membrane");
            if(!environmentModel.getEnvironmentMembrane(i).isEmpty()) {
                occupiedList.add(environmentModel.getEnvironmentMembrane(i));
            }
        }
        environmentModel.setOccupiedList(occupiedList);
    }


    private void makeNewMembrane(String direction, int position, int population) {
        Membrane newMembrane = new Membrane();
        newMembrane.changePopulation(population);
        newMembrane.changeDirection(direction);
        environmentModel.getEnvironmentMembrane(position).addMembraneSetup(newMembrane);
    }

    /**
     *
     * @param numberOfCells
     */
    private void setupTestColony(int numberOfCells) {
        int environmentSize = width*height;

        try {
            if(numberOfCells > environmentSize) {
                throw new Exception("Number of cells is greater than the enviornment dimensions");
            }
        } catch(Exception exp) {
            exp.printStackTrace();
        }


        for(int i=0; i<numberOfCells; i++) {
            Membrane myxobacteria = new Membrane();
            myxobacteria.changeDirection(RuleList.EAST_STR);
            myxobacteria.changePopulation(1);
            environmentModel.getEnvironmentMembrane(i).addMembraneSetup(myxobacteria);
        }
        
        environmentModel.setRuleType(EnvironmentModel.STOCHASTIC);
        for(int i=0; i<environmentSize; i++) {

            defineMyxoRules(environmentModel.getEnvironmentMembrane(i));
            environmentModel.getEnvironmentMembrane(i).setName("Environment Membrane");
            if(!environmentModel.getEnvironmentMembrane(i).isEmpty()) {
                occupiedList.add(environmentModel.getEnvironmentMembrane(i));
            }
        }
        environmentModel.setOccupiedList(occupiedList);

    }

    private void setupMyxoEnvironmentColony(int numberOfCells) {
        System.out.println("If this is being EXECUTED STOP NOW - hardcoded variables\n");
        
        int environmentSize = width*height;

        int position = 0;
        while(numberOfCells > 0) {
            Random rand = new Random();
            int randValue = rand.nextInt(399)+1;
            if(numberOfCells - randValue <= 0) {
                randValue = numberOfCells;
            }
            Membrane myxoMembrane = new Membrane();
            MultiSetObject populationObject = new MultiSetObject();
            populationObject.setObject(randValue);
            myxoMembrane.addMultiSetObject(RuleList.POPULATION,populationObject);

//            int randDirection = rand.nextInt(8);
//            String direction = RuleList.getDirection(randDirection);
            MultiSetObject directionObject = new MultiSetObject();
//            if(position >= (numberOfCells-width)) {
//                directionObject.setObject(RuleList.getDirection(RuleList.NORTH));
//            } else {
//                directionObject.setObject(RuleList.getDirection(RuleList.EAST));
//            }
            directionObject.setObject(RuleList.getDirection(RuleList.EAST));
//            directionObject.setObject(direction);
            myxoMembrane.addMultiSetObject(RuleList.DIRECTION,directionObject);
//            MultiSetObject movementMode = new MultiSetObject();
//            movementMode.setObject(RuleList.S_MOTILITY);
//            myxoMembrane.addMultiSetObject(RuleList.MOTILITY, movementMode);
            environmentModel.setRuleType(EnvironmentModel.STOCHASTIC);
            myxoMembrane.setParentMembrane(environmentModel.getEnvironmentMembrane(position));
            myxoMembrane.setTempParentMembrane(environmentModel.getEnvironmentMembrane(position));
            environmentModel.getEnvironmentMembrane(position).addMembraneSetup(myxoMembrane);

            numberOfCells = numberOfCells - randValue;
            position++;
        }

        for(int y=0; y<height; y++) {
            for(int i=0; i<width; i++) {
                if(i >= width-10) {
                    Membrane ecoli = new Membrane();
                    Random rand = new Random();
                    int population = rand.nextInt(399)+1;
                    ecoli.changePopulation(population);
                    ecoli.changeDirection(RuleList.WEST_STR);
                    ecoli.setName("Ecoli");
                    environmentModel.getEnvironmentMembrane(i, y).addEcoli(ecoli);
                }
            }
        }

        for(int i=0; i<environmentSize; i++) {

            defineMyxoRules(environmentModel.getEnvironmentMembrane(i));
            environmentModel.getEnvironmentMembrane(i).setName("Environment Membrane");
            if(!environmentModel.getEnvironmentMembrane(i).isEmpty()) {
                occupiedList.add(environmentModel.getEnvironmentMembrane(i));
            }
        }
        environmentModel.setOccupiedList(occupiedList);
    }

//    private void setupMyxoEnvironment(int numberOfCells, int initialConfiguration, PaintPanel paintPanel) {
//        switch(initialConfiguration) {
//            case 0: //random
//                //initialize all the cells so that they are unmarked
//                //ok, so I shouldn't be using the number of cells, instead it needs to be the number
//                //of environmental p system membranes (as the number of cells is the total bacterium
//                //population)
//                int environmentSize = width * height;
//                Hashtable<Integer,Boolean> cellTable = new Hashtable<Integer,Boolean>(environmentSize);
//                Hashtable<Integer,Integer> distributionTable = new Hashtable<Integer,Integer>(environmentSize);
//                for(int i=0; i<environmentSize; i++) {
//                    cellTable.put(i, Boolean.FALSE);
//                }
//                //loop for the total number of bacteria cells
//                while(numberOfCells > 0) {
//                    Random rand = new Random();
//                    int randomSelection = rand.nextInt(cellTable.size());
//
//                    int randValue = rand.nextInt(399)+1;
//                    //int randValue = 400;
//
//                    if(numberOfCells - randValue <= 0) {
//                        //int temp = numberOfCells - randValue;
//                        //randValue = randValue - temp;
//                        randValue = numberOfCells;
//                    }
//
//
//                    if(cellTable.get(randomSelection) == Boolean.FALSE) {
//                        cellTable.put(randomSelection, Boolean.TRUE);
//                        distributionTable.put(randomSelection, randValue);
//                        //only decrease the count if they are being used
//                        numberOfCells = numberOfCells - randValue;
//                    }
//                }
//                //having established how many cells to put in each multienvironment P System
//                //we now need to build the membranes and put in a direction
//                for(int i=0; i<cellTable.size(); i++) {
//                    Boolean isUsed = (Boolean)cellTable.get(i);
//                    if(isUsed == Boolean.TRUE) {
//                        Integer cellPopulation = (Integer)distributionTable.get(i);
//                        if(cellPopulation == 0){
//                            System.out.println("Prevented making a cell with 0 population");
//                            continue;
//                        }
//                        Membrane myxoMembrane = new Membrane();
//                        MultiSetObject populationObject = new MultiSetObject();
//                        populationObject.setObject(cellPopulation);
//                        //myxoMembrane.addMultiSetObject(populationObject);
//                        myxoMembrane.addMultiSetObject(RuleList.POPULATION,populationObject);
//                        //myxoMembrane.addTempMultiSetObject(RuleList.POPULATION, populationObject);
//                        //myxoMembrane.addCollisionMultiSetObject(RuleList.POPULATION, populationObject);
//
//                        //now we need to do a random direction
//                        Random rand = new Random();
//                        int randDirection = rand.nextInt(8);
//                        String direction = RuleList.getDirection(randDirection);
//                        MultiSetObject directionObject = new MultiSetObject();
//                        directionObject.setObject(direction);
////                        directionObject.setObject(RuleList.getDirection(RuleList.EAST));
//                        myxoMembrane.addMultiSetObject(RuleList.DIRECTION,directionObject);
//                        //myxoMembrane.addTempMultiSetObject(RuleList.DIRECTION,directionObject);
//                        //myxoMembrane.addCollisionMultiSetObject(RuleList.DIRECTION,directionObject);
//
//                        MultiSetObject movementMode = new MultiSetObject();
//                        movementMode.setObject(RuleList.A_MOTILITY);
//                        myxoMembrane.addMultiSetObject(RuleList.MOTILITY, movementMode);
//                        //myxoMembrane.addTempMultiSetObject(RuleList.MOTILITY, movementMode);
//                        //myxoMembrane.addCollisionMultiSetObject(RuleList.MOTILITY, movementMode);
//
//                        environmentModel.setRuleType(EnvironmentModel.STOCHASTIC);
//                        myxoMembrane.setParentMembrane(environmentModel.getEnvironmentMembrane(i));
//                        myxoMembrane.setTempParentMembrane(environmentModel.getEnvironmentMembrane(i));
//                        environmentModel.getEnvironmentMembrane(i).addMembraneSetup(myxoMembrane);
//                        //environmentModel.getEnvironmentMembrane(i).wasCellOccupied();
//                        //occupiedTable.put(i,environmentModel.getEnvironmentMembrane(i));
//                    } //else {
//                        //environmentModel.getEnvironmentMembrane(i).wasCellEmpty();
//                    //}
//
//                }
//
//                //put rules into every multienvironment P System
//
//                for(int i=0; i<environmentSize; i++) {
//                    defineMyxoRules(environmentModel.getEnvironmentMembrane(i));
//                    environmentModel.getEnvironmentMembrane(i).setName("Environment Membrane");
//                    if(!environmentModel.getEnvironmentMembrane(i).isEmpty()) {
//                        occupiedList.add(environmentModel.getEnvironmentMembrane(i));
//                    }
//                }
//                environmentModel.setOccupiedList(occupiedList);
//                //now I need to make the membranes in each respective enironment cell
//                //populate them and assign a random direction
//            break;
//            default: System.out.println("This should not happen!");
//        }
//    }

    private void defineMyxoRules(Membrane environmentMembrane) {
        Rule1 rule1 = new Rule1(environmentMembrane);
//        environmentMembrane.addRule(rule1);
        Rule2 rule2 = new Rule2(environmentMembrane);
//        environmentMembrane.addRule(rule2);
        Rule3a rule3a = new Rule3a(environmentMembrane);
//        environmentMembrane.addRule(rule3a);
        Rule3b rule3b = new Rule3b(environmentMembrane);
//        environmentMembrane.addRule(rule3b);
        Rule3c rule3c = new Rule3c(environmentMembrane);
//        environmentMembrane.addRule(rule3c);
        Rule4a rule4a = new Rule4a(environmentMembrane);
//        environmentMembrane.addRule(rule4a);
        Rule4b rule4b = new Rule4b(environmentMembrane);
//        environmentMembrane.addRule(rule4b);
        Rule4c rule4c = new Rule4c(environmentMembrane);
//        environmentMembrane.addRule(rule4c);
        Rule5 rule5 = new Rule5(environmentMembrane);
//        environmentMembrane.addRule(rule5);
        Rule9 rule9 = new Rule9(environmentMembrane);
//        environmentMembrane.addRule(rule9);
        Rule10 rule10 = new Rule10(environmentMembrane);
//        environmentMembrane.addRule(rule10);
        Rule11 rule11 = new Rule11(environmentMembrane);
//        environmentMembrane.addRule(rule11);
        Rule12 rule12 = new Rule12(environmentMembrane);
//        environmentMembrane.addRule(rule12);
        Rule15a rule15a = new Rule15a(environmentMembrane);
//        environmentMembrane.addRule(rule15a);
        Rule15b rule15b = new Rule15b(environmentMembrane);
//        environmentMembrane.addRule(rule15b);
        Rule15c rule15c = new Rule15c(environmentMembrane);
//        environmentMembrane.addRule(rule15c);
        Rule16a rule16a = new Rule16a(environmentMembrane);
//        environmentMembrane.addRule(rule16a);
        Rule16b rule16b = new Rule16b(environmentMembrane);
//        environmentMembrane.addRule(rule16b);
        Rule16c rule16c = new Rule16c(environmentMembrane);
//        environmentMembrane.addRule(rule16c);
        Rule17a rule17a = new Rule17a(environmentMembrane);
//        environmentMembrane.addRule(rule17a);
        Rule17b rule17b = new Rule17b(environmentMembrane);
//        environmentMembrane.addRule(rule17b);
        Rule17c rule17c = new Rule17c(environmentMembrane);
//        environmentMembrane.addRule(rule17c);
        Rule18a rule18a = new Rule18a(environmentMembrane);
//        environmentMembrane.addRule(rule18a);
        Rule18b rule18b = new Rule18b(environmentMembrane);
//        environmentMembrane.addRule(rule18b);
        Rule18c rule18c = new Rule18c(environmentMembrane);
//        environmentMembrane.addRule(rule18c);
        ///////////////////////----------------------------

        //s-motility
        Rule20a rule20a = new Rule20a(environmentMembrane);
        environmentMembrane.addRule(rule20a);                   //making a tag in front
        Rule20b rule20b = new Rule20b(environmentMembrane);
        environmentMembrane.addRule(rule20b);
        Rule20c rule20c = new Rule20c(environmentMembrane);
        environmentMembrane.addRule(rule20c);
        Rule21 rule21 = new Rule21(environmentMembrane);
        environmentMembrane.addRule(rule21);                    //fixing tags (must be high)
        
        Rule22 rule22 = new Rule22(environmentMembrane);
        environmentMembrane.addRule(rule22);                    //moving into empty space when you have no tag
        Rule23 rule23 = new Rule23(environmentMembrane);
        environmentMembrane.addRule(rule23);                    //spontaneous reversal

        Rule24a rule24a = new Rule24a(environmentMembrane);
        environmentMembrane.addRule(rule24a);                   //moving into your tag's space

        //a-motility
        Rule25a rule25a = new Rule25a(environmentMembrane);
        //environmentMembrane.addRule(rule25a);                   //move forward into empty cell where there is slime
        Rule25b rule25b = new Rule25b(environmentMembrane);
        //environmentMembrane.addRule(rule25b);
        Rule25c rule25c = new Rule25c(environmentMembrane);
        //environmentMembrane.addRule(rule25c);

        Rule30 rule30 = new Rule30(environmentMembrane);
        environmentMembrane.addRule(rule30);
        Rule31 rule31 = new Rule31(environmentMembrane);
        environmentMembrane.addRule(rule31);

        Rule40 rule40 = new Rule40(environmentMembrane);
//        environmentMembrane.addRule(rule40);
        Rule41 rule41 = new Rule41(environmentMembrane);
//        environmentMembrane.addRule(rule41);
    }

    public void runModel() {    
        thread.start();
    }

    public void closeEnvironment() {
        frame.setVisible(false);
        frame = new EnvironmentWindow();
        //frame.setBackground(Color.BLACK);
    }

}
