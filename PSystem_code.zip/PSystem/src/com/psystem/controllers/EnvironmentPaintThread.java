/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.controllers;

import com.psystem.model.EnvironmentModel;
import com.psystem.ui.EnvironmentWindow;
import com.psystem.ui.MyxoPaintPanel;
import com.psystem.ui.PaintPanel;
import java.awt.BorderLayout;

/**
 *
 * @author Anthony
 */
public class EnvironmentPaintThread extends Thread {

    private boolean displayGUI = true;
    private boolean recordHeatMap = true;
    private EnvironmentModel environmentModel;
    private EnvironmentWindow environmentWindow;
    private PaintPanel paintPanel;
    
    //private boolean isInitial = true;

    public EnvironmentPaintThread(EnvironmentModel environmentModel, EnvironmentWindow environmentWindow) {
        this.environmentModel = environmentModel;
        this.environmentWindow = environmentWindow;
        
        paintPanel = this.environmentWindow.getPaintPanel(); //<-----I added this

        //paintPanel = new PaintPanel();
        //paintPanel = new MyxoPaintPanel();    //<----- I added this, but I don't know if this is right. 
        environmentWindow.add(paintPanel,BorderLayout.CENTER);
    }

    public void initiliase(boolean displayGUI) {
        this.displayGUI = displayGUI;
        if(!displayGUI) {
            return;
        }
        paintPanel = environmentWindow.getPaintPanel();
        paintPanel.setEnvironmentModel(environmentModel);

        //this.start(); // <---- I added this
        //do all the initial repainting here.....
        //add in the paintrules into repaint for membranes
    }

    @Override
    public void run() {
        //if(isInitial) {
        //    paintPanel.repaint();
        //    isInitial = false;
        //}
       // paintPanel.repaint();
        //for(int i=0; i<2; i++) {
        
        //boolean isRunning = true;
        int count = 0;
        int fileCount = 0;
        while(true) {
            try {

                environmentModel.executeRules();
                if(displayGUI) {
                    paintPanel.repaint();
                }
                if(recordHeatMap) {
                    
                    if(count == 10) {
                        environmentModel.recordPositions(fileCount);
                        count = 0;
                        fileCount++;
                    }
                    count++;
                }

         //       Thread.sleep(1000);
            } catch(Exception exp) {
                exp.printStackTrace();
           //     isRunning = false;
            }
            
        }
        //each time step I look at the environment membrane - i check to see if anything is in there
        //if an environment membrane contains another membrane then it will
        //a) execute the inner membrane's possible rules by iterating through the inner structure
        //b) execute its own rule e.g., move the present membrane in a random direction
    }

}
