/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem;

import com.psystem.controllers.MainUIController;

/**
 *
 * @author Anthony
 */
public class PSystemMain {

    public PSystemMain(int dimension, int population, boolean displayGUI) {
        MainUIController mainUIController = new MainUIController();
       //MainUIController mainUIController = new MainUIController(dimension, population, displayGUI);
    }

    public static void main(String args[]) {
        int dimension = Integer.valueOf(args[0]);
        int population = Integer.valueOf(args[1]);
        boolean displayGUI = Boolean.parseBoolean(args[2]);
        PSystemMain startMain = new PSystemMain(dimension, population, displayGUI);
    }

}
