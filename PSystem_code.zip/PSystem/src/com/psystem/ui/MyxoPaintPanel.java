/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import com.psystem.common.RuleList;
import com.psystem.model.EnvironmentModel;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class MyxoPaintPanel extends PaintPanel {

    private int sleepTime = 30;
    private int maxCells = 10000;
    private static boolean readyToPaint = false;

    public static void setReadyToPaint(boolean state) {
        MyxoPaintPanel.readyToPaint = state;
        //System.out.println("setting MyxoPaintPanel to " + state);
    }

    @Override
    public void paintComponent(Graphics g) {

        while(readyToPaint == false) {
            try {
                //System.out.println("MyxoPaintPanel is sleeping");
                Thread.currentThread().sleep(30);
            } catch(Exception exp) {
                exp.printStackTrace();
            }
        }

        //System.out.println("I am painting " + Thread.currentThread().getName());

        for(int x=0; x<super.width; x++) {
            for(int y=0; y<super.width; y++) {
//                int totalColor = 0;
                Membrane currentMembrane = super.environmentModel.getEnvironmentMembrane(x, y);
                MultiSetObject slimeObject = currentMembrane.getMultiSetObject(RuleList.SLIME);
                if (!currentMembrane.isEmpty()) {
//                    ArrayList<Membrane> myxoMembraneList = currentMembrane.getMembraneList();
//                    for(int colorIndex = 0; colorIndex<myxoMembraneList.size(); colorIndex++) {
//                        Membrane myxoMembrane = myxoMembraneList.get(colorIndex);
//                        MultiSetObject populationObject = myxoMembrane.getMultiSetObject("POPULATION");
//                        Integer populationInteger = (Integer)populationObject.getObject();
//                        if(populationInteger == 0) {
//                            System.out.println("Should never get here");
//                        }
//                        int populationInt = populationInteger;
//                        totalColor = totalColor + populationInteger;
                        
//                    }
//                    if(totalColor>400) {
//                        System.out.println("*********************************");
//                        System.out.println("Total population in envo_cell: " + totalColor);
//                        for(int n=0; n<myxoMembraneList.size(); n++) {
//                            Integer pop = (Integer)myxoMembraneList.get(n).getMultiSetObject("POPULATION").getObject();
//                            System.out.println(pop);
//                        }
//                    }
//                    float blueColorF = (float)totalColor/maxCells;
                    int east=0;
                    int west=0;
                    int northSouth=0;
                    ArrayList<Membrane> myxoMembraneList = currentMembrane.getMembraneList();
                    int total = 0;
                    for(int i=0; i<myxoMembraneList.size(); i++) {
                        Membrane myxoMembrane = myxoMembraneList.get(i);
                        MultiSetObject populationObject = myxoMembrane.getMultiSetObject("POPULATION");
                        MultiSetObject directionObject = myxoMembrane.getMultiSetObject(RuleList.DIRECTION);
                        String direction = (String)directionObject.getObject();
                        total += (Integer)populationObject.getObject();
                        if(direction.equals("EAST") || direction.equals("NORTH_EAST") || direction.equals("SOUTH_EAST")) {
                            east += (Integer)populationObject.getObject();
                        }
                        if(direction.equals("WEST") || direction.equals("NORTH_WEST") || direction.equals("SOUTH_WEST")) {
                            west += (Integer)populationObject.getObject();
                        }
                        if(direction.equals("SOUTH") || direction.equals("NORTH")) {
                            northSouth += (Integer)populationObject.getObject();
                        }
                    }

                    //why is this 400?
                    float red = (float)east/maxCells;
                    float blue = (float)west/maxCells;
                    float green = (float)northSouth/maxCells;




                    //float blueColorF = currentMembrane.calculateDensity();
//                    if(blueColorF > 1) {
//                        System.out.println("Oh dear!");
//                    }
                    Color blueColor = null;
                    try {
//                        blueColor = new Color(0.0f, 0.0f, blueColorF);
                        blueColor = new Color(red, green, blue);
//                        totalColor = 0;
                    } catch(IllegalArgumentException exp) {
                        //exp.printStackTrace();
                        //System.out.println("Blue color is: " + blueColorF);
                        blueColor = new Color(1.0f,0.0f,0.0f);
                    }
                    g.setColor(blueColor);
                } else if(slimeObject != null) {
                    Color slimeColor = new Color(153,255,153);
                    g.setColor(slimeColor);
                } else if(!currentMembrane.isEcoliEmpty()) {
                    Membrane ecoliMembrane = currentMembrane.getInternalEcoli().get(0);
                    float green = (float)ecoliMembrane.getPopulation()/maxCells;
                    Color greenColor = new Color(0.0f,green,0.0f);
                    g.setColor(greenColor);
                }
                else {
                    g.setColor(Color.WHITE);
                }

                g.fillRect(x*5, y*5, 5, 5);

            }
        }
        synchronized(this) {
            EnvironmentModel.setReadyToUpdate(true);
            MyxoPaintPanel.setReadyToPaint(false);
        }

    }

    @Override
    public void setEnvironmentModel(EnvironmentModel environmentModel) {
        this.environmentModel = environmentModel;
        this.height = environmentModel.getHeight();
        this.width = environmentModel.getWidth();
    }

}
