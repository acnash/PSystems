/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import com.psystem.model.EnvironmentModel;
import javax.swing.JPanel;

/**
 *
 * @author Anthony
 */
public abstract class PaintPanel extends JPanel {

    protected int width;
    protected int height;
    protected EnvironmentModel environmentModel;

    public abstract void setEnvironmentModel(EnvironmentModel environmentModel);

}
