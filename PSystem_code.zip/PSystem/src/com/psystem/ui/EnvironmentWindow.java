/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Anthony
 */
public class EnvironmentWindow extends JFrame {

    private PaintPanel paintPanel;

    public EnvironmentWindow() {
        this.setLayout(new BorderLayout());
    }

    public void addPaintPanel(PaintPanel paintPanel) {
        this.add(paintPanel, BorderLayout.CENTER);
        this.paintPanel = paintPanel;
    }

    public PaintPanel getPaintPanel() {
        return paintPanel;
    }

}
