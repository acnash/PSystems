/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import com.psystem.common.UIUtilities;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Anthony
 */
public class JustMyxoFrame extends JFrame {

    public static final int RANDOM = 0;

    private String[] list = {"Random"};
    private JTextField numberOfCellsField = new JTextField(4);
    private JComboBox startupComboBox;
    private JButton okButton = new JButton("Ok");
    private JButton cancelButton = new JButton("Cancel");

    public JustMyxoFrame() {
        this.setSize(200,200);
        this.setTitle("Myxobacteria Rules");
        Dimension centre = UIUtilities.getCenter(this, UIUtilities.HALF);
        this.setLocation(((int)centre.getWidth()), ((int)centre.getHeight()));

        startupComboBox = new JComboBox(list);

        FlowLayout layout = new FlowLayout();
        layout.setAlignment(FlowLayout.LEFT);

        JPanel northPanel = new JPanel(layout);
        northPanel.add(new JLabel("Number of Cells"));
        northPanel.add(this.numberOfCellsField);

        JPanel centrePanel = new JPanel(new BorderLayout());
        centrePanel.add(BorderLayout.NORTH, new JLabel("Initial Positions"));
        centrePanel.add(BorderLayout.SOUTH, startupComboBox);

        JPanel southPanel = new JPanel();
        southPanel.add(okButton);
        southPanel.add(cancelButton);

        this.add(BorderLayout.NORTH, northPanel);
        this.add(BorderLayout.CENTER, centrePanel);
        this.add(BorderLayout.SOUTH, southPanel);
    }

    public void setVisible(boolean state) {
        super.setVisible(state);
    }

    public int getNumberOfCells() {
        return Integer.parseInt(numberOfCellsField.getText());
    }

    public int getInitialization() {
        return startupComboBox.getSelectedIndex();
    }

    public void setOKAL(ActionListener al) {
        okButton.addActionListener(al);
    }

    public void setCancelAL(ActionListener al) {
        cancelButton.addActionListener(al);
    }
    
}
