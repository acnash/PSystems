/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import com.psystem.common.RuleList;
import com.psystem.common.UIUtilities;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Anthony
 */
public class MyxoPetriFrame extends JFrame {

    private static List ruleList = new ArrayList();
    static {
        ruleList.add(String.valueOf(RuleList.JUST_MYXO));
        ruleList.add(String.valueOf(RuleList.JUST_ECOLI));
        ruleList.add(String.valueOf(RuleList.MYXO_PRED_PREY));
    }

    private JButton okButton = new JButton("Ok");
    private JButton cancelButton = new JButton("Cancel");
    private JTextField widthTextField = null;
    private JTextField heightTextField = null;

    private String TITLE = "Petri Dish P System";

    public MyxoPetriFrame() {
        this.setLayout(new BorderLayout());
        this.setSize(300,260);
        Dimension screenDimension = UIUtilities.getCenter(this,UIUtilities.HALF);
        this.setLocation(((int)screenDimension.getWidth()),((int)screenDimension.getHeight()));

        widthTextField = new JTextField("0",4);
        heightTextField = new JTextField("0",4);

        FlowLayout leftLayout = new FlowLayout();
        leftLayout.setAlignment(FlowLayout.LEFT);
        JPanel dimensionPanel = new JPanel(leftLayout);
        dimensionPanel.setBorder(BorderFactory.createTitledBorder("Environment Dimensions"));
        JPanel widthPanel = new JPanel(leftLayout);
        JPanel heightPanel = new JPanel(leftLayout);
        widthPanel.add(new JLabel("Width: "));
        heightPanel.add(new JLabel("Height:"));
        widthPanel.add(widthTextField);
        heightPanel.add(heightTextField);
        dimensionPanel.add(widthPanel);
        dimensionPanel.add(heightPanel);

        JPanel northPanel = new JPanel();
        JPanel southPanel = getControlPanel();
        northPanel.add(dimensionPanel);

        this.add(BorderLayout.NORTH, northPanel);
        this.add(BorderLayout.SOUTH, southPanel);

    }

    private JPanel getControlPanel() {
        JPanel centerPanel = new JPanel(new BorderLayout());
        JPanel gridPanel = new JPanel(new GridLayout(1,2));
        okButton = new JButton("OK");
        JPanel okPanel = new JPanel();
        okPanel.add(okButton);
        cancelButton = new JButton("Cancel");
        JPanel cancelPanel = new JPanel();
        cancelPanel.add(cancelButton);
        gridPanel.add(okPanel);
        gridPanel.add(cancelPanel);

        centerPanel.add(gridPanel,BorderLayout.CENTER);

        return centerPanel;
    }

    public String getEnvironmentTitle() {
        return this.TITLE;
    }

    public int getEnvironmentHeight() {
        return Integer.parseInt(heightTextField.getText());
    }

    public int getEnvironmentWidth() {
        return Integer.parseInt(widthTextField.getText());
    }


    public void setOKAL(ActionListener al) {
        okButton.addActionListener(al);
    }

    public void setCancelAL(ActionListener al) {
        cancelButton.addActionListener(al);
    }

    public void setEnvironmentVisible(boolean state) {
        super.setVisible(state);
    }

    public List getRuleList() {
        return MyxoPetriFrame.ruleList;
    }

}
