/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import com.psystem.model.EnvironmentModel;
import com.psystem.model.Membrane;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Anthony
 */
public class RandomMovementPaintPanel extends PaintPanel{


    @Override
    public void paintComponent(Graphics g) {
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {
                Membrane membrane = environmentModel.getEnvironmentMembrane(x, y);
                Membrane particleMembrane = membrane.getMembrane(0);
                //Membrane particleMembrane = membrane.getTempMembrane(0);
                if(particleMembrane != null) {
                    g.setColor(Color.green);
                    g.fillRect(x*5, y*5, 5, 5);
                } else {
                    g.setColor(Color.black);
                    g.fillRect(x*5, y*5, 5, 5);
                }
            }
        }
    }

    @Override
    public void setEnvironmentModel(EnvironmentModel environmentModel) {
        this.environmentModel = environmentModel;
        this.height = environmentModel.getHeight();
        this.width = environmentModel.getWidth();

    }

}
