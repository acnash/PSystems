/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author Anthony
 */
public class MainMenuBar extends JMenuBar {

    private JMenu fileMenu;
    private JMenuItem closeItem;
    private JMenuItem exitItem;
    private JMenuItem basicBox;
    private JMenuItem fromFile;

    private JMenu ruleMenu;
    private JMenuItem randomWalkItem;
    private JMenuItem justMyxoItem;
    private JMenuItem myxoPetri;
    private JMenuItem justEColiItem;
    private JMenuItem myxoPredPreyItem;

    public MainMenuBar() {
        fileMenu = new JMenu("File");
        closeItem = new JMenuItem("Close Environment");
        exitItem = new JMenuItem("Exit");
        basicBox = new JMenuItem("MultiEnvironment P System");
        fromFile = new JMenuItem("From File");
        myxoPetri = new JMenuItem("Myxo Petri");


        JMenu openMenu = new JMenu("Open Environment");
        openMenu.add(basicBox);
        openMenu.add(myxoPetri);
        openMenu.addSeparator();
        openMenu.add(fromFile);

        fileMenu.add(openMenu);
        fileMenu.add(closeItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        ruleMenu = new JMenu("Rules");
        randomWalkItem = new JMenuItem("Random Walk");
        randomWalkItem.setEnabled(false);
        justMyxoItem = new JMenuItem("Just Myxo");
        justMyxoItem.setEnabled(false);
        justEColiItem = new JMenuItem("Just E. coli");
        justEColiItem.setEnabled(false);
        myxoPredPreyItem = new JMenuItem("Myxo Predator-Prey");
        myxoPredPreyItem.setEnabled(false);

        ruleMenu.add(randomWalkItem);
        ruleMenu.add(justMyxoItem);
        ruleMenu.add(justEColiItem);
        ruleMenu.add(myxoPredPreyItem);

        this.add(fileMenu);
        this.add(ruleMenu);
    }

    public void setCloseAL(ActionListener al) {
        closeItem.addActionListener(al);
    }

    public void setOpenAL(ActionListener al) {
        fromFile.addActionListener(al);
    }

    public void setExitAL(ActionListener al) {
        exitItem.addActionListener(al);
    }

    public void enableClose(boolean state) {
        closeItem.setEnabled(state);
    }

    public void setBasicBoxAL(ActionListener al) {
        basicBox.addActionListener(al);
    }

    public void setMyxoPetri(ActionListener al) {
        myxoPetri.addActionListener(al);
    }

    public void enableRandomWalk(boolean state) {
        randomWalkItem.setEnabled(state);
    }

    public void enableJustMyxo(boolean state) {
        justMyxoItem.setEnabled(state);
    }

    public void enableJustEColi(boolean state) {
        justEColiItem.setEnabled(state);
    }

    public void enableMyxoPredPrey(boolean state) {
        myxoPredPreyItem.setEnabled(state);
    }

    public void setRandomWalkAL(ActionListener al) {
        randomWalkItem.addActionListener(al);
    }

    public void setJustMyxoAL(ActionListener al) {
        justMyxoItem.addActionListener(al);
    }

    public void setJustEColiAL(ActionListener al) {
        justEColiItem.addActionListener(al);
    }

    public void setMyxoPredPreyAL(ActionListener al) {
        myxoPredPreyItem.addActionListener(al);
    }
}
