/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import com.psystem.common.RuleList;
import com.psystem.common.UIUtilities;
import com.psystem.controllers.EnvironmentController;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/**
 *
 * @author Anthony
 */
public class BasicBoxOptionsFrame extends JFrame {

    private static List ruleList = new ArrayList();
    static {
        ruleList.add(String.valueOf(RuleList.RANDOM_WALK));
    }

    private String TITLE = "MultiEnvironment P System";

    private JTextField nTextField;
    private JTextField neTextField;
    private JTextField eTextField;
    private JTextField seTextField;
    private JTextField sTextField;
    private JTextField swTextField;
    private JTextField wTextField;
    private JTextField nwTextField;

    private JButton okButton;
    private JButton cancelButton;

    private JTextField widthTextField;
    private JTextField heightTextField;
    private JComboBox boundsComboBox;
    private String[] boundsList;
    private String[] neighbourhoodList;
    private JComboBox neighbourhoodComboBox;

    public BasicBoxOptionsFrame() {
        this.setLayout(new BorderLayout());
        this.setSize(300,460);
        Dimension screenDimension = UIUtilities.getCenter(this,UIUtilities.HALF);
        this.setLocation(((int)screenDimension.getWidth()),((int)screenDimension.getHeight()));

        JPanel northPanel = new JPanel(new GridLayout(3,1));

        boundsList = new String[]{"Infinite Bounds","Open Bounds","Closed Bounds"};
        neighbourhoodList = new String[]{"Moore","von Neumman"};

        widthTextField = new JTextField("0",4);
        heightTextField = new JTextField("0",4);
        boundsComboBox = new JComboBox(boundsList);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        FlowLayout leftLayout = new FlowLayout();
        leftLayout.setAlignment(FlowLayout.LEFT);
        JPanel dimensionPanel = new JPanel(leftLayout);
        dimensionPanel.setBorder(BorderFactory.createTitledBorder("Environment Dimensions"));
        JPanel widthPanel = new JPanel(leftLayout);
        JPanel heightPanel = new JPanel(leftLayout);
        widthPanel.add(new JLabel("Width: "));
        heightPanel.add(new JLabel("Height:"));
        widthPanel.add(widthTextField);
        heightPanel.add(heightTextField);
        dimensionPanel.add(widthPanel);
        dimensionPanel.add(heightPanel);
        northPanel.add(dimensionPanel);
        
        JPanel boundsPanel = new JPanel(leftLayout);
        boundsPanel.setBorder(BorderFactory.createTitledBorder("Environment Bounds"));
        boundsPanel.add(boundsComboBox);
        northPanel.add(boundsPanel);


        JPanel neighbourhoodPanel = new JPanel(leftLayout);
        neighbourhoodPanel.setBorder(BorderFactory.createTitledBorder("Neighbourhood"));
        neighbourhoodComboBox = new JComboBox(neighbourhoodList);
        neighbourhoodPanel.add(neighbourhoodComboBox);
        neighbourhoodComboBox.addActionListener(getNeighbourhoodAL());
        northPanel.add(neighbourhoodPanel);

        JPanel probabilityPanel = new JPanel(new BorderLayout());
        probabilityPanel.setBorder(BorderFactory.createTitledBorder("Diffusion Probability"));
        probabilityPanel.add(getMooreProbabilityPanel(),BorderLayout.CENTER);

        mainPanel.add(northPanel,BorderLayout.NORTH);
        mainPanel.add(probabilityPanel,BorderLayout.CENTER);
        mainPanel.add(getControlPanel(),BorderLayout.SOUTH);

        this.add(mainPanel,BorderLayout.CENTER);

        
    }

    private JPanel getNeummanProbabilityPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        FlowLayout layout = new FlowLayout();
        layout.setAlignment(FlowLayout.LEFT);
        JPanel firstPanel = new JPanel(new GridLayout(1,4));

        JPanel nPanel = new JPanel(layout);
        nTextField = new JTextField("0.25",3);
        nPanel.add(new JLabel("North: "));
        nPanel.add(nTextField);

        JPanel ePanel = new JPanel(layout);
        eTextField = new JTextField("0.25",3);
        ePanel.add(new JLabel("East: "));
        ePanel.add(eTextField);

        JPanel sPanel = new JPanel(layout);
        sTextField = new JTextField("0.25",3);
        sPanel.add(new JLabel("South: "));
        sPanel.add(sTextField);

        JPanel wPanel = new JPanel(layout);
        wTextField = new JTextField("0.25",3);
        wPanel.add(new JLabel("West: "));
        wPanel.add(wTextField);

        firstPanel.add(nPanel);
        firstPanel.add(ePanel);
        firstPanel.add(sPanel);
        firstPanel.add(wPanel);

        mainPanel.add(firstPanel,BorderLayout.CENTER);

        return mainPanel;
    }

    private JPanel getMooreProbabilityPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        FlowLayout layout = new FlowLayout();
        layout.setAlignment(FlowLayout.LEFT);
        JPanel firstPanel = new JPanel(new GridLayout(4,1));
        JPanel secondPanel = new JPanel(new GridLayout(4,1));

        JPanel nPanel = new JPanel(layout);
        nTextField = new JTextField("0.125",3);
        nPanel.add(new JLabel("North: "));
        nPanel.add(nTextField);

        JPanel ePanel = new JPanel(layout);
        eTextField = new JTextField("0.125",3);
        ePanel.add(new JLabel("East: "));
        ePanel.add(eTextField);

        JPanel sPanel = new JPanel(layout);
        sTextField = new JTextField("0.125",3);
        sPanel.add(new JLabel("South: "));
        sPanel.add(sTextField);

        JPanel wPanel = new JPanel(layout);
        wTextField = new JTextField("0.125",3);
        wPanel.add(new JLabel("West: "));
        wPanel.add(wTextField);

        firstPanel.add(nPanel);
        firstPanel.add(ePanel);
        firstPanel.add(sPanel);
        firstPanel.add(wPanel);

        JPanel nePanel = new JPanel(layout);
        neTextField = new JTextField("0.125",3);
        nePanel.add(new JLabel("North East: "));
        nePanel.add(neTextField);

        JPanel sePanel = new JPanel(layout);
        seTextField = new JTextField("0.125",3);
        sePanel.add(new JLabel("South East: "));
        sePanel.add(seTextField);

        JPanel swPanel = new JPanel(layout);
        swTextField = new JTextField("0.125",3);
        swPanel.add(new JLabel("South West: "));
        swPanel.add(swTextField);

        JPanel nwPanel = new JPanel(layout);
        nwTextField = new JTextField("0.125",3);
        nwPanel.add(new JLabel("North West: "));
        nwPanel.add(nwTextField);

        secondPanel.add(nePanel);
        secondPanel.add(sePanel);
        secondPanel.add(swPanel);
        secondPanel.add(nwPanel);

        mainPanel.add(firstPanel,BorderLayout.WEST);
        mainPanel.add(secondPanel,BorderLayout.EAST);
        return mainPanel;
    }

    private ActionListener getNeighbourhoodAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                JComboBox comboBox = ((JComboBox)event.getSource());
                int selectedIndex = comboBox.getSelectedIndex();
                if(selectedIndex == 1) {
                    //handle neumman
                    System.out.println(selectedIndex);
                } else {
                    //handle moore
                    System.out.println(selectedIndex);
                }
            }
        };
    }

    private JPanel getControlPanel() {
        JPanel centerPanel = new JPanel(new BorderLayout());
        JPanel gridPanel = new JPanel(new GridLayout(1,2));
        okButton = new JButton("OK");
        JPanel okPanel = new JPanel();
        okPanel.add(okButton);
        cancelButton = new JButton("Cancel");
        JPanel cancelPanel = new JPanel();
        cancelPanel.add(cancelButton);
        gridPanel.add(okPanel);
        gridPanel.add(cancelPanel);

        centerPanel.add(gridPanel,BorderLayout.CENTER);

        return centerPanel;
    }
    
    public void setOKAL(ActionListener al) {
        okButton.addActionListener(al);
    }
    
    public void setCancelAL(ActionListener al) {
        cancelButton.addActionListener(al);
    }

    public int getEnvironmentWidth() throws ClassCastException {
        int value = Integer.parseInt(this.widthTextField.getText());
        return value;
    }

    public int getEnvironmentHeight() throws ClassCastException {
        int value = Integer.parseInt(this.heightTextField.getText());
        return value;
    }

    public int getEnvironmentBounds() {
        return this.boundsComboBox.getSelectedIndex();
    }

    public int getNeighbourSelection() {
        return this.neighbourhoodComboBox.getSelectedIndex();
    }

    public double getNProbability() throws ClassCastException {
        double value = Double.parseDouble(nTextField.getText());
        return value;
    }

    public double getNEProbability() throws ClassCastException {
        double value = Double.parseDouble(neTextField.getText());
        return value;
    }

    public double getEProbability() throws ClassCastException {
        double value = Double.parseDouble(eTextField.getText());
        return value;
    }

    public double getSEProbability() throws ClassCastException {
        double value = Double.parseDouble(seTextField.getText());
        return value;
    }

    public double getSProbability() throws ClassCastException {
        double value = Double.parseDouble(sTextField.getText());
        return value;
    }

    public double getSWProbability() throws ClassCastException {
        double value = Double.parseDouble(swTextField.getText());
        return value;
    }

    public double getWProbability() throws ClassCastException {
        double value = Double.parseDouble(wTextField.getText());
        return value;
    }

    public double getNWProbability() throws ClassCastException {
        double value = Double.parseDouble(nwTextField.getText());
        return value;
    }

    public String getEnvironmentTitle() {
        return this.TITLE;
    }

    public List getRuleList() {
        return BasicBoxOptionsFrame.ruleList;
    }

    public int getEnvironmentType() {
        return EnvironmentController.MULTIENVIRONMENT;
    }

    public void setEnvironmentVisible(boolean state) {
        super.setVisible(state);
    }

}
