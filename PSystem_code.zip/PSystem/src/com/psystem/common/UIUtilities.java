/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.common;

import java.awt.Dimension;
import javax.swing.JFrame;

/**
 *
 * @author Anthony
 */
public class UIUtilities {

    public static final int QUARTER = 4;
    public static final int HALF = 2;

    public static Dimension getCenter(JFrame component, int offsetSize) {
        Dimension screenDimension = component.getToolkit().getScreenSize();
        Dimension size = component.getSize();

        int width = ((int)size.getWidth())/offsetSize;
        int height = ((int)size.getHeight())/offsetSize;
        int locationX = ((int)screenDimension.getWidth())/offsetSize;
        int locationY = ((int)screenDimension.getHeight())/offsetSize;

        return new Dimension(locationX-width, locationY-height);
    }

}
