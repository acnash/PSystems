/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.common;

import com.psystem.model.Rule;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class BubbleSort {

    private ArrayList<Rule> ruleList;
    private ArrayList<Double> stochasticValues;


    public BubbleSort() {

    }

    public void sort() {
        boolean swapped = true;
        int n=0;
        while(swapped) {
            swapped = false;
            n++;
            for(int i=0; i<ruleList.size()-n; i++) {
                if(stochasticValues.get(i) > stochasticValues.get(i+1)) {
                    double temp = stochasticValues.get(i+1);
                    stochasticValues.set(i+1,stochasticValues.get(i));
                    stochasticValues.set(i,temp);
                    Rule tempRule = ruleList.get(i+1);
                    ruleList.set(i+1,ruleList.get(i));
                    ruleList.set(i,tempRule);
                    swapped = true;
                }
            }
        }
    }

    public void setRuleList(ArrayList<Rule> ruleList) {
        this.ruleList = ruleList;
    }

    public void setStochasticList(ArrayList<Double> stochasticValues) {
        this.stochasticValues = stochasticValues;
    }

    public ArrayList<Rule> getRuleList() {
        return ruleList;
    }

    public ArrayList<Double> getStochasticList() {
        return stochasticValues;
    }

    public void displayLists() {
        for(int i=0; i<ruleList.size(); i++) {
            System.out.println(ruleList.get(i) + " " + stochasticValues.get(i));
        }
    }

    public static void main(String agrs[]) {
        BubbleSort bs = new BubbleSort();
        System.out.println("Before sort");
        bs.displayLists();
        bs.sort();
        bs.displayLists();
        System.out.println("After sort");
    }

}


