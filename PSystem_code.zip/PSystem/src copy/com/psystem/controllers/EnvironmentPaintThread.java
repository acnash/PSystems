/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.controllers;

import com.psystem.model.EnvironmentModel;
import com.psystem.ui.EnvironmentWindow;
import com.psystem.ui.PaintPanel;

/**
 *
 * @author Anthony
 */
public class EnvironmentPaintThread extends Thread {

    private EnvironmentModel environmentModel;
    private EnvironmentWindow environmentWindow;
    private PaintPanel paintPanel;
    //private boolean isInitial = true;

    public EnvironmentPaintThread(EnvironmentModel environmentModel, EnvironmentWindow environmentWindow) {
        this.environmentModel = environmentModel;
        this.environmentWindow = environmentWindow;
        //paintPanel = new PaintPanel();
        //environmentWindow.add(paintPanel,BorderLayout.CENTER);
    }

    public void initiliase() {
        paintPanel = environmentWindow.getPaintPanel();
        paintPanel.setEnvironmentModel(environmentModel);

        //this.start();
        //do all the initial repainting here.....
        //add in the paintrules into repaint for membranes
    }

    public void run() {
        //if(isInitial) {
        //    paintPanel.repaint();
        //    isInitial = false;
        //}
        paintPanel.repaint();
        //for(int i=0; i<2000; i++) {
        boolean isRunning = true;
        while(isRunning) {
            try {
                Thread.sleep(150);
            } catch(InterruptedException exp) {
                exp.printStackTrace();
            }
            try {
                environmentModel.executeRules();
                paintPanel.repaint();
            } catch(Exception exp) {
                exp.printStackTrace();
                isRunning = false;
            }
        }
        //each time step I look at the environment membrane - i check to see if anything is in there
        //if an environment membrane contains another membrane then it will
        //a) execute the inner membrane's possible rules by iterating through the inner structure
        //b) execute its own rule e.g., move the present membrane in a random direction
    }

}
