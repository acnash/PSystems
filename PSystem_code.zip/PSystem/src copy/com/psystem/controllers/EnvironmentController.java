/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.controllers;

import com.psystem.common.RuleList;
import com.psystem.common.UIUtilities;
import com.psystem.entities.EnvironmentObject;
import com.psystem.entities.InitialData;
import com.psystem.entities.JustMyxo;
import com.psystem.model.EnvironmentModel;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.NeighbourMembrane;
import com.psystem.model.RandomMovementRule;
import com.psystem.model.Rule;
import com.psystem.model.RuleModel;
import com.psystem.model.justmyxo.Rule1;
import com.psystem.model.justmyxo.Rule10;
import com.psystem.model.justmyxo.Rule11;
import com.psystem.model.justmyxo.Rule2;
import com.psystem.model.justmyxo.Rule9;
import com.psystem.ui.EnvironmentWindow;
import com.psystem.ui.MyxoPaintPanel;
import com.psystem.ui.PaintPanel;
import com.psystem.ui.RandomMovementPaintPanel;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;

/**
 *
 * @author Anthony
 */
public class EnvironmentController {

    public static final int MULTIENVIRONMENT = 0;
    public static final int MYXO_PETRI = 1;

    private EnvironmentModel environmentModel;
    private EnvironmentObject eObject;
    private EnvironmentWindow frame;
    private EnvironmentPaintThread thread;
    private PaintPanel paintPanel;
    //private JFrame frame;

    private int width;
    private int height;

    public EnvironmentController() {
        frame = new EnvironmentWindow();
        //frame.setBackground(Color.BLACK);
    }

    public void generateNewEnvironment(EnvironmentObject eObject) {
        this.eObject = eObject;
        this.width = this.eObject.getWidth();
        this.height = this.eObject.getHeight();
        environmentModel = new EnvironmentModel(width, height, width*height);

        frame.setSize(width*5, height*5);
        Dimension position = UIUtilities.getCenter(frame, UIUtilities.HALF);
        frame.setLocation(((int)position.getWidth()), ((int)position.getHeight()));

        frame.setTitle(this.eObject.getTitle());

        switch(this.eObject.getEnvironmentType()) {
            case EnvironmentController.MULTIENVIRONMENT: 
                generateMultiEnvironmentStructure();
                break;
            case EnvironmentController.MYXO_PETRI:
                generateMyxoEnvironmentStructure();
            default: System.out.println("Unknown environment to set up");
        }

        frame.setVisible(true);
    }

    /**
     *
     */
    private void generateMyxoEnvironmentStructure() {
        //you add the structure of the environment membranes to the environmentmodel object
        //from within this method
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {
                //construct a membrane
                Membrane membrane = new Membrane();
                //For the moment the environment has no rules, it is just blank spaces
                //but all movement rules should be in here (for the bacteria moving through
                //the environment
                environmentModel.addEnvironmentMembrane(membrane, x, y);
            }
        }
        //generate the neighbourhood associations
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {
                ArrayList<NeighbourMembrane>neighbours = getMooreNeighbours(x,y,EnvironmentObject.CLOSED_BOUNDS);
                Membrane membrane = environmentModel.getEnvironmentMembrane(x, y);
                membrane.addNeighbours(neighbours);
            }
        }
    }

    /**
     *
     */
    private void generateMultiEnvironmentStructure() {
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {
                //i need the diffusion rates
                //i need the neighbourhoods
                Hashtable<String,Double> directionProbabilities = new Hashtable<String,Double>();
                directionProbabilities.put(NeighbourMembrane.NORTH,new Double(eObject.getNProbability()));
                directionProbabilities.put(NeighbourMembrane.SOUTH,new Double(eObject.getSProbability()));
                directionProbabilities.put(NeighbourMembrane.EAST,new Double(eObject.getEProbability()));
                directionProbabilities.put(NeighbourMembrane.WEST,new Double(eObject.getWProbability()));
                if(eObject.getNeighbourhood() == EnvironmentObject.MOORE_NEIGHBOURHOOD) {
                    directionProbabilities.put(NeighbourMembrane.NORTH_WEST,new Double(eObject.getNWProbability()));
                    directionProbabilities.put(NeighbourMembrane.NORTH_EAST,new Double(eObject.getNEProbability()));
                    directionProbabilities.put(NeighbourMembrane.SOUTH_EAST,new Double(eObject.getSEProbability()));
                    directionProbabilities.put(NeighbourMembrane.SOUTH_WEST,new Double(eObject.getSWProbability()));           
                }
                //the random rules now needs to populate these membranes with rules
                //and diffusion values as taken down from the UI
                Membrane membrane = new Membrane();
                //these are the multienvironment membrane, so I must make and insert the rules here
                Rule randomMovementRule = new RandomMovementRule(membrane);
                //taken out rule neighbour define
                randomMovementRule.setDiffusionProbabilities(directionProbabilities);
                membrane.addRule(randomMovementRule);
                environmentModel.addEnvironmentMembrane(membrane, x, y);
            }
        }
        for(int x=0; x<width; x++) {
            for(int y=0; y<height; y++) {

                //get this membrane's neighbours and add it to the rule
                ArrayList<NeighbourMembrane> neighbours = null;
                if(eObject.getNeighbourhood() == EnvironmentObject.MOORE_NEIGHBOURHOOD) {
                    //neighbours = getMooreNeighbours(x,y,eObject.getEnvironmentType());
                    neighbours = getMooreNeighbours(x,y,eObject.getBounds());
                } else {
                    //neighbours = getNeummanNeighbours(x,y,eObject.getEnvironmentType());
                    neighbours = getNeummanNeighbours(x,y,eObject.getBounds());
                }
                Membrane membrane = environmentModel.getEnvironmentMembrane(x, y);
                membrane.addNeighbours(neighbours);
                Rule randomMovementRule = membrane.getRule(0);
                randomMovementRule.defineNeighbours();
                
            }
        }
    }


    /**
     *
     * I am trying to collect a neighbourhood when one hasn't been laid down yet!!!!
     *
     * @param x
     * @param y
     * @return
     */
    private ArrayList<NeighbourMembrane> getMooreNeighbours(int x, int y, int environmentType) {
        //I must take into account the boundary conditions
        //what happens in the cases of
        //1. Closed
        //2. Open
        //3. Infinity
        ArrayList<NeighbourMembrane> neighbours = new ArrayList<NeighbourMembrane>();

        switch(environmentType) {
            case EnvironmentObject.CLOSED_BOUNDS:
                //consider the case where it is not on ANY boundaries
                //if(x != 0 && x != width && y != 0 && y != width) {
                int index = (x*width)+y;
                if( (index >= width) && (index % width != 0) && ((index+1) % width != 0 ) && ( index < (width*height)-width) ) {
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.NORTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.NORTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.SOUTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.WEST));
                }

                //consider the case where the main cell is in a corner
                //topleft - correct
                if(x==0 && y==0) {
//                    System.out.println("index:= " + index + " top left corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.SOUTH));

                }
                //top right - CORRECT WRONG
                //BOTTOM LEFT
                if((x==0) && (y==(height-1))) {
//                    System.out.println("index:= " + index + " top right corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.NORTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.NORTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.EAST));
                }
                //bottom right
                if(x==(width-1) && y==(height-1)) {
//                    System.out.println("index:= " + index + " bottom right corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.NORTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.WEST));
                }
                //botton left
                //TOP RIGHT
                if(x==(width-1) && y==0) {
//                    System.out.println("index:= " + index + " bottom left corner");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.SOUTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.WEST));
                }


                //consider the case where the main cell is on an edge, but not a corner
                //LEFT SIDE
                //TOP SIDE
                if((y == 0 && x != 0) && (y == 0 && x != (width-1))) {
//                    System.out.println("index:= " + index + " left side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.SOUTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.WEST));
                }
                //RIGHT SIDE
                //BOTTOM SIDE
                if((y == (height-1) && x != 0) && (y == (height-1) && x != (width-1))) {
//                    System.out.println("index:= " + index + " right side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.NORTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.NORTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.EAST));
                }
                //TOP SIDE
                //LEFT SIDE
                if((x == 0 && y != 0) && (x == 0 && y != (height-1))) {
//                    System.out.println("index:= " + index + " top side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.SOUTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.SOUTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.NORTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y-1),NeighbourMembrane.NORTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x+1,y+1),NeighbourMembrane.SOUTH_EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.SOUTH));
                }
                //BOTTOM SIDE
                //RIGHT SIDE
                if((x == (width-1) && y != 0) && ( x == (width-1) && y != (height-1))) {
//                    System.out.println("index:= " + index + " bottom side");
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.NORTH));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.NORTH_EAST));
//                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.EAST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y-1),NeighbourMembrane.NORTH));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y-1),NeighbourMembrane.NORTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y),NeighbourMembrane.WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x-1,y+1),NeighbourMembrane.SOUTH_WEST));
                    neighbours.add(new NeighbourMembrane(environmentModel.getEnvironmentMembrane(x,y+1),NeighbourMembrane.SOUTH));
                }
                break;
            case EnvironmentObject.OPEN_BOUNDS:
                System.out.println("No rules for open bounds yet");
                break;
            case EnvironmentObject.INFINITE_BOUNDS:
                System.out.println("No rules for infinite bounds yet");
                break;
        }

        return neighbours;
    }

    /**
     * Don't implement straight away
     * @param x
     * @param y
     * @return
     */
    private ArrayList<NeighbourMembrane> getNeummanNeighbours(int x, int y, int environmentType) {
        return null;
    }

    public void loadModel(int ruleToImplement, InitialData initialData) throws Exception {
        //this should be a little like a factory class generator
        RuleModel model = null;
        switch(ruleToImplement) {
            case RuleList.RANDOM_WALK:
                paintPanel = new RandomMovementPaintPanel();
                paintPanel.setSize(width*5, height*5);
                //put in initial particle to move around randomly
                //the particle membrane has no rules
                Membrane particleMembrane = new Membrane();
                //we add the particle to the center of the environment
                environmentModel.getEnvironmentMembrane(width/2, height/2).addMembrane(particleMembrane);
                
                //in other models you might consider making initial population dispersion here
                break;
            case RuleList.JUST_MYXO:
                paintPanel = new MyxoPaintPanel();
                paintPanel.setSize(width*5, height*5);
                //
                //do initialization here for myxo bacterium..... it should be a combo box in rule panel
                //yet the rule panel needs to be created
                int numberOfCells = Integer.parseInt(initialData.getMetaData(JustMyxo.NUMBER_OF_CELLS));
                int initialConfiguration = Integer.parseInt(initialData.getMetaData(JustMyxo.INITIAL_CONFIGURATION));
                setupMyxoEnvironment(numberOfCells,initialConfiguration,paintPanel);
                break;
            case RuleList.JUST_ECOLI:
                System.out.println("Just Ecoli rules are not yet implemented");
                break;
            case RuleList.MYXO_PRED_PREY:
                System.out.println("Pred Prey rules are not yet implemented");
                break;
            default: System.out.println("Unknown rule set");
                throw new Exception("Crazy! Unknown rules.");
        }
        //the loadModel method should now call for initiliase of the painting
        frame.addPaintPanel(paintPanel);
        thread = new EnvironmentPaintThread(environmentModel, frame);
        thread.initiliase();
    }

    private void setupMyxoEnvironment(int numberOfCells, int initialConfiguration, PaintPanel paintPanel) {
        switch(initialConfiguration) {
            case 0: //random
                //initialize all the cells so that they are unmarked
                //ok, so I shouldn't be using the number of cells, instead it needs to be the number
                //of environmental p system membranes (as the number of cells is the total bacterium
                //population)
                int environmentSize = width * height;
                Hashtable<Integer,Boolean> cellTable = new Hashtable<Integer,Boolean>(environmentSize);
                Hashtable<Integer,Integer> distributionTable = new Hashtable<Integer,Integer>(environmentSize);
                for(int i=0; i<environmentSize; i++) {
                    cellTable.put(i, Boolean.FALSE);
                }
                while(numberOfCells > 0) {
                    Random rand = new Random();
                    int randValue = rand.nextInt(49)+1;

                    if(numberOfCells - randValue < 0) {
                        int temp = numberOfCells - randValue;
                        randValue = randValue - temp;
                    }
                    numberOfCells = numberOfCells - randValue;

                    int randomSelection = rand.nextInt(cellTable.size());
                    if(cellTable.get(randomSelection) == Boolean.FALSE) {
                        cellTable.put(randomSelection, Boolean.TRUE);
                        distributionTable.put(randomSelection, randValue);
                    }
                }
                //having established how many cells to put in each multienvironment P System
                //we now need to build the membranes and put in a direction
                for(int i=0; i<cellTable.size(); i++) {
                    Boolean isUsed = (Boolean)cellTable.get(i);
                    if(isUsed == Boolean.TRUE) {
                        Integer cellPopulation = (Integer)distributionTable.get(i);
                        Membrane myxoMembrane = new Membrane();
                        MultiSetObject populationObject = new MultiSetObject();
                        populationObject.setObject(cellPopulation);
                        //myxoMembrane.addMultiSetObject(populationObject);
                        myxoMembrane.addMultiSetObject(RuleList.POPULATION,populationObject);
                        //now we need to do a random direction
                        Random rand = new Random();
                        int randDirection = rand.nextInt(8);
                        String direction = RuleList.getDirection(randDirection);
                        MultiSetObject directionObject = new MultiSetObject();
                        directionObject.setObject(direction);
                        myxoMembrane.addMultiSetObject(RuleList.DIRECTION,directionObject);

                        MultiSetObject movementMode = new MultiSetObject();
                        movementMode.setObject(RuleList.A_MOTILITY);
                        myxoMembrane.addMultiSetObject(RuleList.MOTILITY, movementMode);

                        defineMyxoRules(environmentModel.getEnvironmentMembrane(i));

                        environmentModel.getEnvironmentMembrane(i).addMembrane(myxoMembrane);
                    }
                }
                //now I need to make the membranes in each respective enironment cell
                //populate them and assign a random direction
            break;
            default: System.out.println("This should not happen!");
        }
    }

    private void defineMyxoRules(Membrane environmentMembrane) {
        Rule1 rule1 = new Rule1(environmentMembrane);
        rule1.defineNeighbours();
        Rule2 rule2 = new Rule2(environmentMembrane);
        rule2.defineNeighbours();
        Rule9 rule9 = new Rule9(environmentMembrane);
        rule9.defineNeighbours();
        Rule10 rule10 = new Rule10(environmentMembrane);
        rule10.defineNeighbours();
        Rule11 rule11 = new Rule11(environmentMembrane);
        rule11.defineNeighbours();
        environmentMembrane.addRule(rule1);
        environmentMembrane.addRule(rule2);
        environmentMembrane.addRule(rule9);
        environmentMembrane.addRule(rule10);
        environmentMembrane.addRule(rule11);
    }

    public void runModel() {    
        thread.start();
    }

    public void closeEnvironment() {
        frame.setVisible(false);
        frame = new EnvironmentWindow();
        //frame.setBackground(Color.BLACK);
    }

}
