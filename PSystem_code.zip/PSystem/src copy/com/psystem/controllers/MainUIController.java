/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.controllers;

import com.psystem.common.RuleList;
import com.psystem.common.UIUtilities;
import com.psystem.entities.EnvironmentObject;
import com.psystem.entities.JustMyxo;
import com.psystem.ui.BasicBoxOptionsFrame;
import com.psystem.ui.JustMyxoFrame;
import com.psystem.ui.MainMenuBar;
import com.psystem.ui.MyxoPetriFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Anthony
 */
public class MainUIController {
    private boolean isOpen = false;

    private JustMyxoFrame justMyxoFrame = null;
    private EnvironmentController environmentController = null;
    private MainMenuBar mainMenuBar = null;
    private JFrame mainFrame = null;
    private BasicBoxOptionsFrame basicBoxOptionsFrame = null;
    private MyxoPetriFrame myxoPetriFrame = null;

    public MainUIController() {
        environmentController = new EnvironmentController();
        mainMenuBar = new MainMenuBar();

        basicBoxOptionsFrame = new BasicBoxOptionsFrame();
        basicBoxOptionsFrame.setCancelAL(this.getMultiEnvironmentCancelAL());
        basicBoxOptionsFrame.setOKAL(this.getMultiEnvironmentOKAL());

        myxoPetriFrame = new MyxoPetriFrame();
        myxoPetriFrame.setOKAL(this.getMyxoPetriOKAL());
        myxoPetriFrame.setCancelAL(this.getMyxoPetriCancelAL());

        justMyxoFrame = new JustMyxoFrame();
        justMyxoFrame.setOKAL(this.getJustMyxoOKAL());
        justMyxoFrame.setCancelAL(this.getJustMyxoCancelAL());

        mainFrame = new JFrame("P System Toolkit");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainMenuBar.setCloseAL(getCloseAL());
        mainMenuBar.setOpenAL(getOpenAL());
        mainMenuBar.setExitAL(getExitAL());
        mainMenuBar.setBasicBoxAL(getBasicBoxAL());
        mainMenuBar.setRandomWalkAL(getRandomWalkAL());
        mainMenuBar.setMyxoPetri(this.getMyxoPetriAL());
        mainMenuBar.setJustEColiAL(this.getJustEColiAL());
        mainMenuBar.setJustMyxoAL(this.getJustMyxoAL());
        mainMenuBar.setMyxoPredPreyAL(this.getMyxoPredPreyAL());

        if(!isOpen) {
            mainMenuBar.enableClose(false);
        }

        JPanel buttonPanel = defineRunControls();
        mainFrame.add(buttonPanel,BorderLayout.NORTH);

        mainFrame.setJMenuBar(mainMenuBar);
        Dimension screenDimension = UIUtilities.getCenter(mainFrame,UIUtilities.QUARTER);
        mainFrame.setLocation(((int)screenDimension.getWidth()),((int)screenDimension.getHeight()));
        mainFrame.setVisible(true);
        mainFrame.setSize(400,100);
    }

    private JPanel defineRunControls() {
        FlowLayout leftLayout = new FlowLayout();
        leftLayout.setAlignment(FlowLayout.LEFT);
        JPanel buttonPanel = new JPanel(leftLayout);
        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        String playPath = "../common/play.png";
        java.net.URL playImgURL = MainUIController.class.getResource(playPath);
        String reloadPath = "../common/reload.png";
        java.net.URL reloadImgURL = MainUIController.class.getResource(reloadPath);
        String pausePath = "../common/bluepause.png";
        java.net.URL pauseImgURL = MainUIController.class.getResource(pausePath);

        ImageIcon playImage = new ImageIcon(playImgURL);
        JButton playButton = new JButton(playImage);
        ImageIcon pauseImage = new ImageIcon(pauseImgURL);
        JButton pauseButton = new JButton(pauseImage);
        ImageIcon reloadImage = new ImageIcon(reloadImgURL);
        JButton reloadButton = new JButton(reloadImage);

        playButton.addActionListener(getPlayAL());

        buttonPanel.add(playButton);
        buttonPanel.add(pauseButton);
        buttonPanel.add(reloadButton);

        return buttonPanel;
    }


    private ActionListener getPlayAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                environmentController.runModel();
            }
        };
    }


    //****** MAIN MENU BAR FILE OPTIONS ACTIONLISTENERS
    private ActionListener getOpenAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                JFileChooser fc = new JFileChooser();
                int result = fc.showOpenDialog(null);
                if(result == JFileChooser.APPROVE_OPTION) {
                    File environmentFile = fc.getSelectedFile();
                    try {
                        //environmentController.handleEnvironmentFile(environmentFile);
                        System.out.println("Currently not working with files");
                    } catch(Exception exp) {
                        JOptionPane.showMessageDialog(null, "Error in loading file");
                        exp.printStackTrace();
                    }
                    isOpen = true;
                    mainMenuBar.enableClose(true);
                }
            }
        };
    }

    private ActionListener getBasicBoxAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                basicBoxOptionsFrame.setEnvironmentVisible(true);
            }
        };
    }

    /**
     * This is for the main menu item
     * @return
     */
    private ActionListener getJustMyxoAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                justMyxoFrame.setVisible(true);
            }
        };
    }
    
    /**
     * this is for the JustMyxoFrame cancel button
     * @return
     */
    private ActionListener getJustMyxoCancelAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                justMyxoFrame.setVisible(false);
            }
        };
    }

    /**
     * this is for the justMyxoFrame ok Button
     * @return
     */
    private ActionListener getJustMyxoOKAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                try {
                    JustMyxo justMyxoInitialData = new JustMyxo();
                    String numberOfCells = String.valueOf(justMyxoFrame.getNumberOfCells());
                    justMyxoInitialData.addMetaData(JustMyxo.NUMBER_OF_CELLS, numberOfCells);
                    String initialConfiguration = String.valueOf(justMyxoFrame.getInitialization());
                    justMyxoInitialData.addMetaData(JustMyxo.INITIAL_CONFIGURATION, initialConfiguration);
                    //I some how must pass in how many cells go in here
                    environmentController.loadModel(RuleList.JUST_MYXO, justMyxoInitialData);
                } catch(Exception exp) {
                    exp.printStackTrace();
                }
            }
        };
    }

    private ActionListener getJustEColiAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {

            }
        };
    }

    private ActionListener getMyxoPredPreyAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {

            }
        };
    }

    private ActionListener getRandomWalkAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                try {
                    environmentController.loadModel(RuleList.RANDOM_WALK, null);
                } catch(Exception exp) {
                    exp.printStackTrace();
                }
            }
        };
    }

    private ActionListener getCloseAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if(isOpen) {
                    int result = JOptionPane.showConfirmDialog(mainFrame, "Environment is open, do you want to quit?","Close",JOptionPane.YES_NO_OPTION);
                    if(result == JOptionPane.OK_OPTION) {
                        resetParameters();
                        environmentController.closeEnvironment();
                        mainMenuBar.enableRandomWalk(false);
                    }
                }
                isOpen = false;
                mainMenuBar.enableClose(false);
            }
        };
    }

    private ActionListener getExitAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if(isOpen) {
                    int result = JOptionPane.showConfirmDialog(mainFrame, "Environment is open, do you want to quit?","Quit",JOptionPane.YES_NO_OPTION);
                    if(result == JOptionPane.OK_OPTION) {
                        mainFrame.setVisible(false);
                        System.exit(0);
                    }
                } else {
                    mainFrame.setVisible(false);
                    System.exit(0);
                }
            }
        };
    }

    /**
     * This opens up the UI for petri dish
     * @return
     */
    private ActionListener getMyxoPetriAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                myxoPetriFrame.setEnvironmentVisible(true);
            }
        };
    }

    /**
     * This is executed via the OK button on the Myxo petri dish GUI option
     * @return
     */
    private ActionListener getMyxoPetriOKAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                EnvironmentObject eObject = new EnvironmentObject();


                //get everything from the MyxoPetriFrame to put into the eObject
                eObject.setRuleList(myxoPetriFrame.getRuleList());
                eObject.setHeight(myxoPetriFrame.getEnvironmentHeight());
                eObject.setWidth(myxoPetriFrame.getEnvironmentWidth());
                eObject.setBounds(EnvironmentObject.CLOSED_BOUNDS);
                eObject.setTitle(myxoPetriFrame.getEnvironmentTitle());
                eObject.setNeighbourhood(EnvironmentObject.MOORE_NEIGHBOURHOOD);

                determineAcceptableRules(eObject.getRuleList());
                environmentController.generateNewEnvironment(eObject);
                myxoPetriFrame.setVisible(false);

                isOpen = true;
                mainMenuBar.enableClose(true);
            }
        };
    }


    private ActionListener getMultiEnvironmentOKAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                EnvironmentObject eObject = new EnvironmentObject();
                //we need to get all the details out of the frame
                //then store them in a special object which is used to set up
                //the environment
                try {
                    int neighbourhoodSelection = basicBoxOptionsFrame.getNeighbourSelection();
                    eObject.setHeight(basicBoxOptionsFrame.getEnvironmentHeight());
                    eObject.setWidth(basicBoxOptionsFrame.getEnvironmentWidth());
                    eObject.setBounds(basicBoxOptionsFrame.getEnvironmentBounds());
                    eObject.setTitle(basicBoxOptionsFrame.getEnvironmentTitle());
                    eObject.setRuleList(basicBoxOptionsFrame.getRuleList());
                    eObject.setEnvironmentType(basicBoxOptionsFrame.getEnvironmentType());

                    if(neighbourhoodSelection == EnvironmentObject.MOORE_NEIGHBOURHOOD) {
                        eObject.setNProbability(basicBoxOptionsFrame.getNProbability());
                        eObject.setNEProbability(basicBoxOptionsFrame.getNEProbability());
                        eObject.setEProbability(basicBoxOptionsFrame.getEProbability());
                        eObject.setSEProbability(basicBoxOptionsFrame.getSEProbability());
                        eObject.setSProbability(basicBoxOptionsFrame.getSProbability());
                        eObject.setSWProbability(basicBoxOptionsFrame.getSWProbability());
                        eObject.setWProbability(basicBoxOptionsFrame.getWProbability());
                        eObject.setNWProbability(basicBoxOptionsFrame.getNWProbability());
                    } else {
                        eObject.setNProbability(basicBoxOptionsFrame.getNProbability());
                        eObject.setEProbability(basicBoxOptionsFrame.getEProbability());
                        eObject.setSProbability(basicBoxOptionsFrame.getSProbability());
                        eObject.setWProbability(basicBoxOptionsFrame.getWProbability());
                    }
                    determineAcceptableRules(eObject.getRuleList());
                    environmentController.generateNewEnvironment(eObject);
                    basicBoxOptionsFrame.setEnvironmentVisible(false);

                    isOpen = true;
                    mainMenuBar.enableClose(true);
                } catch(ClassCastException exp) {
                    exp.printStackTrace();
                }
            }
        };
    }

    private void determineAcceptableRules(List ruleList) {
        for(int i=0; i<ruleList.size(); i++) {
            int entry = Integer.parseInt(((String)ruleList.get(i)));
            switch(entry) {
                case RuleList.RANDOM_WALK:
                    mainMenuBar.enableRandomWalk(true);
                    break;
                case RuleList.JUST_MYXO:
                    mainMenuBar.enableJustMyxo(true);
                    break;
                case RuleList.JUST_ECOLI:
                    mainMenuBar.enableJustEColi(true);
                    break;
                case RuleList.MYXO_PRED_PREY:
                    mainMenuBar.enableMyxoPredPrey(true);
                    break;
            }
        }
    }

    private ActionListener getMyxoPetriCancelAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                myxoPetriFrame.setVisible(false);
            }
        };
    }

    private ActionListener getMultiEnvironmentCancelAL() {
        return new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                basicBoxOptionsFrame.setVisible(false);
            }
        };
    }

    private void resetParameters() {

    }

}
