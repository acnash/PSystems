/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.ui;

import com.psystem.model.EnvironmentModel;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class MyxoPaintPanel extends PaintPanel {

    private int maxCells = 400;

    @Override
    public void paintComponent(Graphics g) {
        for(int x=0; x<super.width; x++) {
            for(int y=0; y<super.width; y++) {
                int totalColor = 0;
                Membrane currentMembrane = super.environmentModel.getEnvironmentMembrane(x, y);
                if (!currentMembrane.isEmpty()) {
                    ArrayList<Membrane> myxoMembraneList = currentMembrane.getMembraneList();
                    for(int colorIndex = 0; colorIndex<myxoMembraneList.size(); colorIndex++) {
                        Membrane myxoMembrane = myxoMembraneList.get(colorIndex);
                        MultiSetObject populationObject = myxoMembrane.getMultiSetObject("POPULATION");
                        Integer populationInteger = (Integer)populationObject.getObject();
                        int populationInt = populationInteger;
                        totalColor += populationInt;
                    }
                    float blueColorF = (float)totalColor/maxCells;
                    Color blueColor = new Color(0.0f, 0.0f, blueColorF);
                    g.setColor(blueColor);
                } else {
                    g.setColor(Color.BLACK);
                }

                g.fillRect(x*5, y*5, 5, 5);
            }
        }

    }

    @Override
    public void setEnvironmentModel(EnvironmentModel environmentModel) {
        this.environmentModel = environmentModel;
        this.height = environmentModel.getHeight();
        this.width = environmentModel.getWidth();
    }

}
