/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.common;

/**
 *
 * @author Anthony
 */
public class RuleList {

    public static final int RANDOM_WALK = 1;
    public static final int JUST_MYXO = 2;
    public static final int JUST_ECOLI = 3;
    public static final int MYXO_PRED_PREY = 4;

    public static final int NORTH = 0;
    public static final int NORTH_EAST = 1;
    public static final int EAST = 2;
    public static final int SOUTH_EAST = 3;
    public static final int SOUTH = 4;
    public static final int SOUTH_WEST = 5;
    public static final int WEST = 6;
    public static final int NORTH_WEST = 7;

    public static final String POPULATION = "POPULATION";
    public static final String DIRECTION = "Direction";
    public static final String MOTILITY = "Motility";
    public static final String A_MOTILITY = "A_MOTILITY";
    public static final String S_MOTILITY = "S_MOTILITY";
    public static final String SLIME = "SLIME";

    public static String getDirection(int direction) {
        String directionString = null;
        switch(direction) {
            case NORTH: directionString = "NORTH";
            break;
            case NORTH_EAST: directionString = "NORTH_EAST";
            break;
            case EAST: directionString = "EAST";
            break;
            case SOUTH_EAST: directionString = "SOUTH_EAST";
            break;
            case SOUTH: directionString = "SOUTH";
            break;
            case SOUTH_WEST: directionString = "SOUTH_WEST";
            break;
            case WEST: directionString = "WEST";
            break;
            case NORTH_WEST: directionString = "NORTH_WEST";
            break;
        }
        return directionString;
    }

}
