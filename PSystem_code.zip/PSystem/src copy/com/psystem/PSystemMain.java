/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem;

import com.psystem.controllers.MainUIController;

/**
 *
 * @author Anthony
 */
public class PSystemMain {

    public PSystemMain() {
        MainUIController mainUIController = new MainUIController();
    }

    public static void main(String args[]) {
        PSystemMain startMain = new PSystemMain();
    }

}
