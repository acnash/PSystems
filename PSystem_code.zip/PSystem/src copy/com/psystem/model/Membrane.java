/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author Anthony
 */
public class Membrane {

    private boolean multisetHasChanged = false;
    private boolean internalMembraneHasChanged = false;
    private boolean ruleListHasChanged = false;

    private ArrayList<Rule> ruleList = new ArrayList<Rule>();
    private ArrayList<Rule> tempRuleList = new ArrayList<Rule>();
    private ArrayList<Rule> backTempRuleList = new ArrayList<Rule>();

    private ArrayList<Membrane> internalMembranes = new ArrayList<Membrane>();
    private ArrayList<Membrane> tempInternalMembranes = new ArrayList<Membrane>();
    private ArrayList<Membrane> backTempInternalMembranes = new ArrayList<Membrane>();

    private ArrayList<MultiSetObject> multiset;
    private ArrayList<MultiSetObject> tempMultiset;
    private ArrayList<MultiSetObject> backTempMultiset;

    private Hashtable<String,MultiSetObject> multisetHashtable = new Hashtable<String,MultiSetObject>();

    private ArrayList<NeighbourMembrane> neighbourhood = null;
    private boolean isFirstTime = true;


    public boolean isEmpty() {
        if(internalMembranes.isEmpty()) {
            return true;
        }
        return false;
    }

    //******MEMBRANE NEIGHBOURS********//
    //this is only for membranes being treated as an environmental structure
    public ArrayList<NeighbourMembrane> getNeighbourhood() {
        return neighbourhood;
    }

    public void addNeighbours(ArrayList<NeighbourMembrane> neighbourhood) {
        this.neighbourhood = neighbourhood;
    }

    //******INTERNAL MEMBRANES**********
    
    public void addMembrane(Membrane membrane) {
        internalMembranes.add(membrane);
        //i think this is needed initially
        addTempMembrane(membrane);
    }

    public void addTempMembrane(Membrane membrane) {
        tempInternalMembranes.add(membrane);
    }
    
    public ArrayList<Membrane> getMembraneList() {
        return internalMembranes;
    }

    public ArrayList<Membrane> getTempMembraneList() {
        return tempInternalMembranes;
    }
    
    public Membrane getMembrane(int index) {
        if(internalMembranes.isEmpty()) {
            return null;
        }
        return internalMembranes.get(index);
    }

    public Membrane getTempMembrane(int index) {
        if(tempInternalMembranes.isEmpty()) {
            return null;
        }
        return tempInternalMembranes.get(index);
    }
    
    //it must be null, as we are using the position in the array as the index
    public void removeMembrane(int index) {
        if (internalMembranes != null) {
            //internalMembranes.set(index, null);
            internalMembranes.remove(index);
        }
    }

    //it must be null, as we are using the position in the array as the index
    public void removeTempMembrane(int index) {
        if (tempInternalMembranes != null) {
            tempInternalMembranes.remove(index);
//            tempInternalMembranes.set(index, null);
        }
    }

    //******MULTISET OBJECTS************

    //I may not use an array list idea
    //***NEEDS TO BE SETUP UP FOR THE TIME DELAY
    public void addMultiSetObject(MultiSetObject multiSetObject) {
        multiset.add(multiSetObject);
    } 
    
    public ArrayList<MultiSetObject> getMultiSetObjectList() {
        return multiset;
    }

    public MultiSetObject getMultiSetObject(String objectName) {
        return (MultiSetObject)multisetHashtable.get(objectName);
    }

    public void addMultiSetObject(String objectName, MultiSetObject multiSetObject) {
        multisetHashtable.put(objectName, multiSetObject);
    }
    
    //******RULES***********************

    public void addRule(Rule rule) {
        ruleList.add(rule);
    }

    public void addRuleList(ArrayList<Rule> ruleList) {
        for(int i=0; i<ruleList.size(); i++) {
            Rule rule = ((Rule)ruleList.get(i));
            this.addRule(rule);
        }
    }

    public ArrayList<Rule> getRuleList() {
        return this.ruleList;
    }

    public Rule getRule(int index) {
        return ruleList.get(index);
    }

    public void executeRules() throws Exception {
        for(int i=0; i<ruleList.size(); i++) {
                ruleList.get(i).executeRule();
        }
        for(int i=0; i<internalMembranes.size(); i++) {
            internalMembranes.get(i).executeRules();
        }
    }

    public void internalMembraneHasChanged() {
        this.internalMembraneHasChanged = true;
    }

    public void ruleListHasChanged() {
        this.ruleListHasChanged = true;
    }

    public void multisetHasChanged() {
        this.multisetHasChanged = true;
    }

    //this doesn't work
    //I have a problem - the temp membranes are never being empties
    public void updateMembrane() throws Exception {
        //should I be calling update on the non tempInternal Membranes?!?!?
        for(int i=0; i<tempInternalMembranes.size(); i++) {
            tempInternalMembranes.get(i).updateMembrane();
        }
        if(multisetHasChanged) {
            backTempMultiset = multiset;
            multiset = tempMultiset;
            tempMultiset = backTempMultiset;
            multisetHasChanged = false;
        }

        if(ruleListHasChanged) {
            backTempRuleList = ruleList;
            ruleList = tempRuleList;
            tempRuleList = backTempRuleList;
            ruleListHasChanged = false;
        }

        if(internalMembraneHasChanged) {
            internalMembranes = tempInternalMembranes;
            //backTempInternalMembranes = internalMembranes;
            //internalMembranes = tempInternalMembranes;
            //tempInternalMembranes = backTempInternalMembranes;
            internalMembraneHasChanged = false;
        }
    }

}
