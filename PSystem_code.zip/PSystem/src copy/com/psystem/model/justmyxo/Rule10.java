/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.model.Membrane;
import com.psystem.model.MyxoRule;
import java.util.Hashtable;

/**
 *
 * @author Anthony
 */
public class Rule10 extends MyxoRule {

    public Rule10(Membrane membrane) {
        this.membrane = membrane;
    }

    

    @Override
    public void executeRule() throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public double getStochasticValue() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkRule() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
