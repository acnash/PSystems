/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model.justmyxo;

import com.psystem.common.RuleList;
import com.psystem.model.Membrane;
import com.psystem.model.MultiSetObject;
import com.psystem.model.MyxoRule;

/**
 *
 * @author Anthony
 */
public class Rule11 extends MyxoRule {

    public Rule11(Membrane membrane) {
        this.membrane = membrane;
    }

    

    @Override
    public void executeRule() throws Exception {
        MultiSetObject directionObject = this.membrane.getMultiSetObject(RuleList.DIRECTION);
        String direction = (String)directionObject.getObject();

        MultiSetObject newDirectionObject = new MultiSetObject();

        if(direction.equals(RuleList.NORTH)) {

        }
        if(direction.equals(RuleList.NORTH_EAST)) {

        }
        if(direction.equals(RuleList.EAST)) {

        }
        if(direction.equals(RuleList.SOUTH_EAST)) {

        }
        if(direction.equals(RuleList.SOUTH)) {

        }
        if(direction.equals(RuleList.SOUTH_WEST)) {

        }
        if(direction.equals(RuleList.WEST)) {

        }
        if(direction.equls(RuleList.NORTH_WEST)) {

    }

    @Override
    public double getStochasticValue() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * This rule will always return true.
     * @return
     */
    @Override
    public boolean checkRule() {
        return true;
    }

}
