/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class EnvironmentModel {

    private ArrayList<Membrane> environmentStructure;
    private int maxX;
    private int totalCells;
    private ArrayList<String> environmentData = new ArrayList<String>();
    private int environmentHeight;
    private int environmentWidth;


    public EnvironmentModel(int environmentWidth, int environmentHeight, int totalCells) {
        this.maxX = environmentWidth;
        this.totalCells = totalCells;
        environmentStructure = new ArrayList<Membrane>(this.totalCells);
        this.environmentWidth = environmentWidth;
        this.environmentHeight = environmentHeight;

    }

    public int getHeight() {
        return environmentHeight;
    }

    public int getWidth() {
        return environmentWidth;
    }

    public void addEnvironmentData(String data) {
        environmentData.add(data);
    }

    public ArrayList<String> getEnvironmentData() {
        return environmentData;
    }

    public void addEnvironmentRules(ArrayList<Rule> ruleList) {
        for(int i=0; i<environmentStructure.size(); i++) {
            ((Membrane)environmentStructure.get(i)).addRuleList(ruleList);
        }
    }

    
    public void addEnvironmentMembrane(Membrane membrane, int x, int y) {
        int index = (x*maxX) + y;
        environmentStructure.add(index,membrane);
    }

    /**
     * This is also being used to get the neighbourhood membranes, which is why
     * when in debug mode it does not return the membranes in a sequential order.
     * @param x
     * @param y
     * @return
     */
    public Membrane getEnvironmentMembrane(int x, int y) {
        int index = (x*maxX) + y;
        try {
            return environmentStructure.get(index);
        } catch(IndexOutOfBoundsException exp) {
            exp.printStackTrace();
            //System.out.println(index);
            //System.out.println("x:=" + x);
            //System.out.println("y:=" + y);
        }
        return null;
    }

    public Membrane getEnvironmentMembrane(int index) {
        return environmentStructure.get(index);
    }

    public void executeRules() throws Exception {
        //in every membrane there should be a method which executes its own rules
        //and then calls its inner membranes to call their rules
        int size = environmentStructure.size();
        for(int i=0; i<size; i++) {
            System.out.println("In index: " + i);
            environmentStructure.get(i).executeRules();
        }
        for(int i=0; i<size; i++) {
            updateAllMembranes(i);
        }
    }

    private void updateAllMembranes(int index) throws Exception {
        //the membrane structure needs changing
        //the multisets needs changing
        environmentStructure.get(index).updateMembrane();
    }
}
