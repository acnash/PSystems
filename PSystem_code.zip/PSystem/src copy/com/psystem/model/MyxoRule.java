/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psystem.model;

import java.util.Hashtable;

/**
 *
 * @author Anthony
 */
public abstract class MyxoRule extends Rule {

    public abstract double getStochasticValue();

    public abstract boolean checkRule();

    @Override
    public void defineNeighbours() {
        neighbourList = this.membrane.getNeighbourhood();
        for(int i=0; i<neighbourList.size(); i++) {
            neighbourTable.put(neighbourList.get(i).getRelativePosition(), neighbourList.get(i).getMembrane());
        }
    }

    @Override
    public void setDiffusionProbabilities(Hashtable<String, Double> diffusionProbabilities) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
